if(window._common == null) var _common = {};

/**
 * 유틸리티 객체 입니다.
 */
_common = {
	/**
	 * <pre>
	 * Ajax Wrapper 입니다. (Method : POST)
	 *
	 * 필수) _URL - 전송 URL (String)
	 * 필수) _PARAMETERS - 전송 파라미터 (object or String)
	 * 필수) _CALLBACK - 콜백함수 (function)
	 * 선택) _async - 동기화 여부 (boolean : 미지정시 true)
	 * 선택) _errorMsg - 전송 실패시 메시지 (String)
	 *
	 * </pre>
	 */
	callAjax : function(_URL, _PARAMETERS, _CALLBACK){
		if(_URL != null){

			var _async = arguments[3];
			if(!_common.utils.validObject(arguments[3], "boolean")){
				_async = true;
			}

			var _errorMsg = arguments[4];

			$.ajax({
				type    : "POST",
				url     : _URL,
				data    : _PARAMETERS,
				async   : _async,
				success : function(json){
					if(json.error != null){
						if(json.notSession != null){
							location.href = "/user/signOut.do";
						}
						alert(json.error);
						return false;
					}
					_CALLBACK(json);
				},
				error   : function(){
					if(_common.utils.validObject(_errorMsg, "string")){
						alert(_errorMsg);
					}else{
						alert("서버에 요청중 문제가 발생했습니다.\n관리자에게 문의하여 주십시오.");
					}
				}
			});
		}else{
			alert("올바른 요청이 아닙니다.");
			return false;
		}
	},
	/**
	 * <pre>
	 * jQuery ajaxForm Wrapper 입니다. (imgFileUpload Validation)
	 * 이미지 객체를 체크합니다.
	 *
	 * 필수) $_SELECTOR - 폼 객체 (object)
	 * 필수) _CALLBACK - 콜백함수 (function)
	 *
	 * </pre>
	 */
	imgFileValidation : function($_SELECTOR, _CALLBACK){
		$_SELECTOR.attr("action", "/imgFileValidation.json").ajaxForm({
			dataType : "json",
			success: function(json){
				_CALLBACK(json);
			},
			error: function(){
				alert("파일 분석에 실패하였습니다.\n시스템 관리자에게 문의해주세요.");
				return false;
			}
		}).submit();
	},
	/**
	 * <pre>
	 * jQuery ajaxForm Wrapper 입니다. (FileUpload Validation)
	 * 알려진 확장자 (압축, 문서 등) 객체를 체크합니다.
	 *
	 * 필수) $_SELECTOR - 폼 객체 (object)
	 * 필수) _CALLBACK - 콜백함수 (function)
	 *
	 * </pre>
	 */
	dataFileValidation : function($_SELECTOR, _CALLBACK){
		$(".fileNm").css("background", "url('./img/progress.gif')").attr("sync", "sync");
		$_SELECTOR.attr("action", "./XML/dataFileValidation.jsp").ajaxForm({
			//dataType : "json",
			success: function(json){
				$(".fileNm").css("background", "white").removeAttr("sync", "sync");
				_CALLBACK($.parseJSON(json));
			},
			error: function(){
				$(".fileNm").css("background", "white").removeAttr("sync", "sync");
				alert("파일 분석에 실패하였습니다.\n시스템 관리자에게 문의해주세요.");
				return false;
			}
		}).submit();
	},
	/**
	 * <pre>
	 * jQuery ajaxForm Wrapper 입니다. (imgFileUpload)
	 *
	 * 필수) _URL	- URL (string)
	 * 필수) $_SELECTOR - 폼 객체 (object)
	 * 필수) _CALLBACK - 콜백함수 (function)
	 *
	 * </pre>
	 */
	formSubmit : function(_URL, $_SELECTOR, _CALLBACK){
		if($(".fileNm").attr("sync") == "sync"){
			alert("파일 분석이 완료 된 후 저장할 수 있습니다.\n잠시만 기다려 주세요.");
			return false;
		}
		$(".fileNm").css("background", "url('./img/progress.gif')").attr("sync", "sync");
		$_SELECTOR.attr("action", _URL).ajaxForm({
			//dataType : "json",
			success: function(json){
				$(".fileNm").css("background", "white").removeAttr("sync", "sync");
				_CALLBACK($.parseJSON(json));
			},
			error: function(){
				$(".fileNm").css("background", "white").removeAttr("sync", "sync");
				alert("파일 업로드를 실패하였습니다.\n시스템 관리자에게 문의해주세요.");
				return false;
			}
		}).submit();
	},
	/**
	 * <pre>
	 * 폼으로 파라미터를 전달합니다.
	 * </pre>
	 */
	postForm : {
		form : null,
		window : null,
		/**
		 * 일반 POST 서브밋 행동을 취합니다.
		 * 다운로드 등의 기능에 사용됩니다.
		 *
		 * 필수) _URL - 전송 URL (String)
		 * 필수) _PARAMETERS - 전송 파라미터 (object or String)
		 */
		submit : function(_URL, _PARAMETERS){
			if(_URL != null){
				$("#postForm").remove();

				var str = "";
				str += "<form action='" + _URL + "' method='POST' name='postForm' id='postForm'>";

				for(var prop in _PARAMETERS){
					str += "<input type='hidden' name='" + prop + "' value='" + _PARAMETERS[prop] + "'>";
				}

				str += "</form>";

				$(str).appendTo("body").submit().remove();
			}else{
				alert("올바른 요청이 아닙니다.");
				return false;
			}
		},
		/**
		 * 새창 POST 서브밋 행동을 취합니다.
		 *
		 * 필수) _URL - 전송 URL (String)
		 * 필수) _PARAMETERS - 전송 파라미터 (object or String)
		 */
		open : function(_URL, _PARAMETERS){
			if(_URL != null){
				$("#postForm").remove();

				var str = "";
				str += "<form name='postForm' id='postForm'>";

				for(var prop in _PARAMETERS){
					str += "<input type='hidden' name='" + prop + "' value='" + _PARAMETERS[prop] + "'>";
				}

				str += "</form>";

				$("body").append(str);
				this.window = window.open("", "newWindow");
				this.form = document.getElementById("postForm");
				this.form.action = _URL;
				this.form.target = "newWindow";
				this.form.method = "POST";
				this.form.submit();
			}else{
				alert("올바른 요청이 아닙니다.");
				return false;
			}
		}
	}

};
_common.utils = {
	/**
	 * <pre>
	 * .sendData의 클래스명을 가진 엘리먼트의 값을 취합합니다.
	 * jQuery.fn.serialize() 와 비슷한 기능을 수행합니다.
	 * </pre>
	 *
	 * 선택) _selector - 기준 엘리먼트 텍스트 (string)
	 * @returns sendData - 전송용 객체 (object)
	 */
	collectSendData : function(){
		var sendData = {};

		var target = arguments[0];

		if(_common.utils.validObject(target, "string")){
			$(target).find(".sendData").each(function(){
				sendData[$(this).attr("id")] = $(this).val();
			});
		}else{
			$(document).find(".sendData").each(function(){
				sendData[$(this).attr("id")] = $(this).val();
			});
		}

		return sendData;
	},

	/**
	 * <pre>
	 * 객체를 검증합니다.
	 * null, "", undefined, typeof 를 검증합니다.
	 * 결과값이 false 일 경우 정상적이지 않은 데이터 입니다.
	 * </pre>
	 *
	 * @param _OBJECT - 검증용 객체 (object)
	 * @param _TYPE - 검증 객체 타입
	 * @returns {Boolean - true : 정상 데이터 / false : 이상 데이터}
	 */
	validObject : function(_OBJECT, _TYPE){
		var bool = false;

		if(_OBJECT !== null && _OBJECT !== "" && _OBJECT !== "관측소명" && _OBJECT !== "아이디" && _OBJECT !== undefined && typeof _OBJECT === _TYPE){
			bool = true;
		}

		return bool;
	},

	/**
	 * <pre>
	 * Null 문자열을 검증합니다.
	 * </pre>
	 *
	 * @param _STRING - 검증용 객체 (object)
	 * @returns {"" or string}
	 */
	validNull : function(_STRING){
		if(_STRING == null || _STRING == undefined || _STRING == "null"){
			_STRING = "";
		}

		return _STRING;
	},

	/**
	 * <pre>
	 * 올바른 숫자인지 검사합니다.
	 * </pre>
	 *
	 * @param _STRING
	 * @returns {Boolean - true : 정상 데이터 / false : 이상 데이터}
	 */
	validNaN : function(_OBJECT){
		var bool = false;

		if(_OBJECT !== null && _OBJECT !== "" && _OBJECT !== undefined && Number(_OBJECT) !== "number"){
			bool = true;
		}

		return bool;
	},

	/**
	 * <pre>
	 * 숫자인지 검사합니다.
	 * </pre>
	 *
	 * @param _STRING
	 * @returns {Boolean - true : 정상 데이터 / false : 이상 데이터}
	 */
	isNumber : function(value){
		if(arguments[1]){
			value = Number(value);
		}
		return typeof value === "number" && isFinite(value);
	},

	/**
	 * <pre>
	 * Random Utils 입니다.
	 * </pre>
	 *
	 * @deprecated
	 */
	Random : {
		randomNumber : function(){
			return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
		},
		getGUID : function(){
			return this.randomNumber() + this.randomNumber() + '-' + this.randomNumber()+ '-' + this.randomNumber()
			+ '-' + this.randomNumber() + '-' + this.randomNumber() + this.randomNumber() + this.randomNumber();
		},
		getGUID12 : function(){
			return this.randomNumber() + this.randomNumber() + this.randomNumber();
		},
		getRandomExtention : function(){
			return _common.utils.Random.getGUID12()+"_"+_common.utils.Random.getGUID12();
		}
	},

	/**
	 * <pre>
	 * 이미지 확장자가 맞는지 확인합니다.
	 * </pre>
	 *
	 * @param $_SELECTOR
	 * @returns {Boolean}
	 */
	isImageExtension : function($_SELECTOR){
		var index = $("." + $_SELECTOR.attr("class")).index($_SELECTOR) + 1;
		if("" == $_SELECTOR.val()){
			$("#pic" + index).val("");
			$_SELECTOR.val("");
			return false;
		}
		var file = $_SELECTOR.val().replace(/.*(\/|\\)/, '');
		var pathpoint = file.lastIndexOf('.');
		var filepoint = file.substring(pathpoint + 1, file.length);
		var filetype = filepoint.toLowerCase();

		if(filetype == 'gif'|| filetype == 'jpg' || filetype == 'jpeg' || filetype == 'png'){
			$("#pic" + index).val($_SELECTOR.val().replace(/.*(\/|\\)/, ''));
			return true;
		}else{
			alert(filetype + " 확장자는 첨부할 수 없습니다.");
			$("#pic" + index).val("");
			$_SELECTOR.val("");
			return false;
		}
	},

	/**
	 * <pre>
	 * 허용된 확장자가 맞는지 확인합니다.
	 * </pre>
	 *
	 * @param $_SELECTOR
	 * @returns {Boolean}
	 */
	isDataExtension : function($_SELECTOR){
		var ALLOW_ARRAY = [
           "gif", "jpg", "jpeg", "png",
           "txt", "hwp", "docx", "doc",
           "pdf", "ppt", "pptx", "xls", "xlsx",
           "alz", "gz", "rar", "tar", "tgz", "z", "zip"
        ];

		var index = $("." + $_SELECTOR.attr("class")).index($_SELECTOR) + 1;
		if("" == $_SELECTOR.val()){
			$("#fnmOrg").val("");
			$_SELECTOR.val("");
			return false;
		}
		var file = $_SELECTOR.val().replace(/.*(\/|\\)/, '');
		var pathpoint = file.lastIndexOf('.');
		var filepoint = file.substring(pathpoint + 1, file.length);
		var filetype = filepoint.toLowerCase();

		var bool = false;
		for(var i=0; i<ALLOW_ARRAY.length; i++){
			if(filetype == ALLOW_ARRAY[i]){
				bool = true;
			}
		}
		if(bool){
			$("#fnmOrg").val($_SELECTOR.val().replace(/.*(\/|\\)/, ''));
			return true;
		}else{
			alert(filetype + " 확장자는 첨부할 수 없습니다.");
			$("#fnmOrg").val("");
			$_SELECTOR.val("");
			return false;
		}
	}
};