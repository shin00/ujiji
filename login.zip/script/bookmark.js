jQuery.fn.center = function () {
	this.css("margin-top", (jQuery(window).height() - this.outerHeight()) / 2 + jQuery(window).scrollTop() + "px");
	return this;
};

$("#input_purpose").keyup(function(e){
	if(e.which == 13){
		fnb.connect.purposeAdd();
	}
});

window.onFileResize = function(){
	$("#upload1").offset({
		top : $("#upload_btn1").offset().top,
		left : $("#upload_btn1").offset().left
	});
};

$(document).ready(function (){
	
	$("#input_purpose").focus();
	$("#wrap").center();
	
	if(session_id == "null"){
		alert("접속권한이 존재 하지 않습니다.\n로그인 페이지로 이동합니다.");
		window.location = "./login.jsp";
	}
	
	$(window).resize(function(){
		$("#wrap").center();
	});
	
	
	fnb.connect.favoritescreate(); //즐겨찾기생성
	_N.init.paging(0, 1);//공지사항을 불러온다.
	fnb.connect.provide(); //
	
	if(session_dept_yn == ""){
		fnb.connect.deptChangePOP();
	}
	
	$(".downBtn").click(function(){
		window.open($(this).attr("page"), "_blank");
	});
	
	$("#upload1").on("change", function(){
		var $_form = $(this).parent();
		if(_common.utils.isDataExtension($(this))){
			_common.dataFileValidation($_form, function(json){
				if(json.valid){
					$_form.parent().find(".tmpNm").val(json.tmpNm);
				}
			});
		}
	}).tooltipsy({
		delay: 0,
		offset: [0, -1],
		css: {
			'font-size' : '12px',
			'padding': '10px',
			'color': '#303030',
			'background-color': '#ffffff',
			'border': '2px solid #4893BA',
			'-moz-box-shadow': '0 0 10px rgba(0, 0, 0, .5)',
			'-webkit-box-shadow': '0 0 10px rgba(0, 0, 0, .5)',
			'box-shadow': '0 0 10px rgba(0, 0, 0, .5)',
			'text-shadow': 'none'
		}
	});

	$("#fnmOrg").on("click", function(){
		if($(this).val() != ""){
			if(confirm("첨부파일을 삭제하시겠습니까?")){
				$("#fnmOrg, #fnmSav, #upload1").val("");
				return false;
			}
		}
	});
	
	$("#saveBtn").on("click", function(){
		var mode = $(this).attr("mode");
		var param = _common.utils.collectSendData(".bpopup");
		for(var prop in param){
			if(param[prop] == null || param[prop] == ""){
				if(prop == "notcTyp"){
					alert("게시글 타입을 선택해 주세요.");
					return false;
				}else if(prop == "subTxt"){
					alert("제목을 입력해 주세요.");
					return false;
				}
			}
		}
		if(confirm("저장하시겠습니까?")){
			var _URL = "./XML/";

			if(mode == "save"){
				_URL += "noticeinsert.jsp";
			}else if(mode == "edit"){
				_URL += "noticeedit.jsp";
				param["view"] = "false";
			}
			if($("#upload1").val() != ""){
				_common.formSubmit("./XML/uploadDataFile.jsp", $("#upload1Form"), function(json){
					if(json.error != null){
						alert(json.error);
						return false;
					}
					_common.callAjax(_URL, param, function(json){
						if(json){
							$(".bpopup").bPopup().close();
							location.reload();
						}
					});
				});
			}else{
				_common.callAjax(_URL, param, function(json){
					if(json){
						$(".bpopup").bPopup().close();
						location.reload();
					}
				});
			}
		}
	});
	
	$("#closePop").on("click", function(){
		$(".bpopup").bPopup().close();
	});
	
});
