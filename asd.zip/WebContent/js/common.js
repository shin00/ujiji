/*
 * 파일명   : common.js
 * 파일설명 : 공통으로 사용하는 Script모음
 * 수정이력 : 
 *       2013.07.03  김경호  : 최초작성
 *       2013.08.07  이규하  : JsInclude-추가, secureSend-error처리 추가
 *       2013.08.13  이규하  : 함수 기능별로 파일로 분리
 *       2013.08.16  이규하  : getUrl 함수 추가, 함수 기능별로 파일로 분리
 */
///////////////////////////////////////////////////////////////////

/**
 * url을 webapp이름에 맞게 변경하여 반환한다.  
 * @param url
 *          URL
 * @returns url 문자열
 */
function getUrl(url) {
	var _root = "/kras";
	var _rtnUrl = url;
	if ( url.indexOf(_root) != 0 && url.charAt(0) == "/" ) {
		_rtnUrl = _root + url;
	}
	return _rtnUrl;
};

/**
 * js, css 파일 include 처리 객체 (head element load에 상관없이 작동)  
 * 
 */
var JsCss = {
	TYPE: {JS:0, CSS:1},
	_type: -1,
	// load 시 사용할 공통 경로, load 후 초기화
	_commonPath: './',
	/**
	 * 파일 종류 지정
	 * @param type
	 */
	setType: function(type) {
		this._type = type;
	},
	/**
	 * 공통 경로 지정
	 * @param _path
	 */
	setPath: function(path) {
		this._commonPath = path;
	},
	set: function(path, type) {
		this.setPath(path);
		this.setType(type);
	},
	/**
	 * js 파일 로딩
	 * @param arguments
	 * 				url, [url, url, ...]
	 */
	load: function() {
		if ( this._type == -1 ) return Error.out('파일 종류(js/css)가 지정되지 않았습니다.');
		var fList = arguments;
		for ( var i = 0; i < fList.length; i++ ) {
			var path = getUrl(this._commonPath);
			var fn = fList[i];
			if ( path.length == 0 ) fn = getUrl(fn);
			var tag = [
			           {h:('<s'+'cript type="text/javascript" s'+'rc="'), t:('"></s'+'cript>')},
			           {h:('<l'+'ink rel="stylesheet" type="text/css" hr'+'ef="'), t:('" />')}
			           ];
			document.write(tag[this._type].h+path+fn+tag[this._type].t);
		}
		
		this._type = -1;
		this._commonPath = './';
	},
	
	js: function() {
		this.setType(this.TYPE.JS);
		this.setPath("");
		this.load.apply(this, Array.prototype.slice.call(arguments));
	},
	
	css: function() {
		this.setType(this.TYPE.CSS);
		this.setPath("");
		this.load.apply(this, Array.prototype.slice.call(arguments));
	}
};

/**
 * 새창 띄우기
 * @param url
 *          페이지 url
 * @param winName
 *          새창이름
 * @param intWidth
 *          창너비
 * @param intHeight
 *          창높이
 * @param scroll
 *          스크롤 생성 유무(1 or 0)
 * @returns 새창 참조값
 */
function OpenWin0(url, winName, intWidth, intHeight, scroll) {
	return window.open(url, winName, "width=" + intWidth + ", height=" + intHeight + ", resizable=1, scrollbars=" + scroll + ", top=" + ((screen.height / 2 - intHeight / 2) - 30) + ", left=" + (screen.width / 2 - intWidth / 2)) ;
}

function OpenWin1(url, winName, intWidth, intHeight, scroll) {
	return window.open(url, winName, "width=" + intWidth + ", height=" + intHeight + ", resizable=1, scrollbars=" + scroll + ", top=" + ((screen.height / 2 - intHeight / 2) - 30) + ", left=" + (screen.width / 2 - intWidth / 2)) ;
}

function OpenPostWin(url, params, winName, intWidth, intHeight, scroll) {
	
    var win = OpenWin0('about:blank', winName, intWidth, intHeight, scroll);

    var $form = $('<form></form>');
	$form.attr('action', url);
	$form.attr('method', 'post');
    $form.attr('target', winName);
    for (var pk in params) {
        if ( params.hasOwnProperty(pk) ) {
            var $input = $('<input type="hidden" name="'+pk+'" value="'+params[pk]+'">');
            $form.append($input);
        }
    }
    $form.appendTo('body');
    
    $form.submit();
    $form.remove();
    
    return win;
}

/**
 * iframe popup post 전송
 * 
 * @param showup
 * 			popup창 id 및 class
 * @param url
 * 			페이지 url
 * @param params
 * @param target
 * 			target iframe name
 * */
function FramePopPostWin(showup, url, params, target) {
	
    var pop = $(showup).show();

    var $form = $('<form></form>');
	$form.attr('action', url);
	$form.attr('method', 'post');
    $form.attr('target', target);
    
    for (var pk in params) {
        if ( params.hasOwnProperty(pk) ) {
        	var $input = $("<input type='hidden' name='"+pk+"' value='"+params[pk]+"'>");
            $form.append($input);
        }
    }
    $form.appendTo('body');
    
    $form.submit();
    $form.remove();
}


function openWinChk(){
	var rtn = false;
	if ( opener ) rtn = true;
	return rtn;
}

// /////////////////////////////////////////////////////////////////////////////////////////////
// 로딩시 함수 호출
// /////////////////////////////////////////////////////////////////////////////////////////////
JsCss.setType(JsCss.TYPE.JS);
JsCss.setPath('/js/');
JsCss.load(
		// jquery
		'jquery/jquery-1.11.1.min.js',
		'jquery/jquery-migrate-1.2.1.min.js',
		'jquery/jquery.xml2json.js',
		// log, msg 관련
		'util/logger_n_msg.js',
		// Utility
		'util/jquery.xmlext.js',
		'util/inputmask.js',
		'util/placeholders.js',
		'util/json2.js',
		'util/string.js',
		'util/jquery.corner.js',
		'util/tools.js',
		'util/sender.js',
		'util/jquery.bpopup-0.5.1.min.js',
		'_var.js.jsp'
);

