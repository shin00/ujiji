
function ChartGen(tblId, k) {

	var _self = this;
	
	this._ct = "P";
	
	this._baseUrl = getUrl("/wsc/chartgen/");
	this._chartPath = this._baseUrl + "pie3d";

	this._tblId = tblId;
	
	this._k = "_gid";
	if ( k != undefined ) this._k = k;
	
	this._dataInfo = {};
	
	this.ready = function(ct) {
		
		if ( ct == "B" ) {
			_self._ct = ct;
			_self._chartPath = _self._baseUrl+"bar3d";
		}

		$.ajax({
			type: "GET",
			url: _self._chartPath+"/info",
			data: {
				tid : _self._tblId,
				k: _self._k
			},
			dataType: "json",
			async: false,
			success: function(json){
				if ( json.result == 1 ) {
					_self._dataInfo = json.di;
				}
			},
			beforeSend: function(){
			    
			},
			complete: function() {
			    
			},
			error: function(xhr, status, error) {
				alert("ChartGen.ready Error => " + error);
			}
		});

		return _self._dataInfo.kv_xy.length;
	};
	
	this.getUrl = function(i) {
		var sum = _self._dataInfo.sum;
		var kvXY = _self._dataInfo.kv_xy[i];
		var url;
		if ( _self._ct == "P" ) {
			url = ( _self._chartPath + "/" + _self._tblId + "/" + _self._k + "/" + kvXY.kv + "/" + kvXY.sum + "/" + sum.max + "/" + sum.min );
		} else {
			url = ( _self._chartPath + "/" + _self._tblId + "/" + _self._k + "/" + kvXY.kv + "/" + kvXY.min );	
		}
		return url;
	};

	this.getPoint = function(i) {
		var kvXY = _self._dataInfo.kv_xy[i];
		return { cx: kvXY.cx, cy: kvXY.cy };
	};

	this.getLegendUrl = function() {
		var url;
		if ( _self._ct == "P" ) {
			url = ( _self._chartPath + "/legend/" + _self._tblId );
		} else {
			url = ( _self._chartPath + "/legend/" + _self._tblId );	
		}
		return url;
	};

}
