function sender(url, ds, callback, async) {
	if ( async === undefined ) async = true;
	var errorView = function(em) {
		Error.out(em, location.reload);
	};
	
	$.ajax({
		type : "POST",
		url : getUrl(url),
		dataType : "text",
		data : {
			ds : ds
		},
		async : async,
		success : function(xml) {
			callback(xml);
		},
		beforeSend : function() {
		},
		complete : function() {
		},
		error : function(xhr, status, error) {
			Error.out('send error');
		}
	});
}

function send4xls(url, ds, fn) {
	
	$('body').append('<div style="width:0;height:0;"><iframe id="fra_xdl" name="fra_xdl" width="0" height="0" frameborder="0"></iframe><form id="frm_xdl" name="frm_xdl" action="'+getUrl(url)+'" method="post" target="fra_xdl"><input type="hidden" id="frm_xdl_ds" name="ds"><input type="hidden" id="frm_xdl_fn" name="fn"></form></div>');
	
	$('#frm_xdl_ds').val(ds);
	$('#frm_xdl_fn').val(fn);
	
	$('#frm_xdl').submit();

}

String.prototype.toJsonResult = function() {
    var json = {};

    var $resultXml = $.parseXML(this);

    $resultXml.children().each(function() {
    	var key = $(this)[0].nodeName;
    	var val = $(this).val();
    	json[key] = val;
    });
    return json;
};
