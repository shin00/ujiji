/*
 * 파일명   : logger_n_msg.js
 * 파일설명 : Logger 객체, 메세지 출력 객체
 * 수정이력 : 
 *       2013.08.16  이규하  : 최초작성 (파일로 분리)
 */
///////////////////////////////////////////////////////////////////
/**
 * console 출력을 위한 객체  
 */
var Logger = {
		// window.console이 없을 때 오류생기지 않도록 객체에 담아둔다
		_logger : new function() {
			if (Function.prototype.bind && window.console && typeof console == "object"){
			    [
			      "log","info","warn","error","assert","dir","clear","profile","profileEnd"
			    ].forEach(function (method) {
			        console[method] = this.bind(console[method], console);
			    }, Function.prototype.call);
			}
			this.con = (window.console != undefined) ? window.console : function(){};
			this.log = (this.con.log != undefined) ? this.con.log : function(){};
			this.info = (this.con.info != undefined) ? this.con.info : function(){};
			this.warn = (this.con.warn != undefined) ? this.con.warn : function(){};
			this.error = (this.con.error != undefined) ? this.con.error : function(){};
			this.assert = (this.con.assert != undefined) ? this.con.assert : function(){};
			this.trace = (this.con.trace != undefined) ? this.con.trace : function(){};
			this.clear = (this.con.clear != undefined) ? this.con.clear : function(){};
		},
		_printSwitch : new function() {
			this.debug = true;
			this.info = true;
			this.warn = true;
			this.error = true;
			this.assert = true;
			
			var agt = navigator.userAgent.toLowerCase();
			if (agt.indexOf("msie") != -1) {
				this.debug = false;
				this.info = false;
				this.warn = false;
				this.error = false;
				this.assert = false;
			}
		},
		debug : function() {
			if ( this._printSwitch.debug ) {
				var args = Array.prototype.slice.call(arguments);
				args.unshift("[Debug]");
				this._logger.log.apply(this._logger.con, args);
				this._logger.trace.apply(this._logger.con);
			}
		},
		info : function() {
			if ( this._printSwitch.info ) {
				var args = Array.prototype.slice.call(arguments);
				args.unshift("[Info]");
				this._logger.info.apply(this._logger.con, args);
			}
		},
		warn : function() {
			if ( this._printSwitch.warn ) {
				var args = Array.prototype.slice.call(arguments);
				args.unshift("[Warn]");
				this._logger.warn.apply(this._logger.con, args);
			}
		},
		error : function() {
			if ( this._printSwitch.error ) {
				var args = Array.prototype.slice.call(arguments);
				args.unshift("[Error]");
				this._logger.error.apply(this._logger.con, args);
			}
		},
		assert : function() {
			if ( this._printSwitch.assert ) {
				var args = Array.prototype.slice.call(arguments);
				args.unshift("[Assert]");
				this._logger.assert.apply(this._logger.con, args);
			}
		},
		clear : function() {
			this._logger.clear.apply(this._logger.con);
		}
};

//if ( window.console != undefined ) console.log = function(){};


/**
 * 메세지 출력과 action 처리 객체를 위한 함수
 * @param default_msg
 */
function _msg(default_msg) {
	this._msg = default_msg;
	this.JS = 0;
	this.URL = 1;
	this.out = function(msg, action, actionType) {
		if ( !msg ) msg = this._msg;
		
		if ( csActive() ) {
			if ( external ) external.csAlert(msg, action, actionType);
		} else {
			alert(msg);
			if ( action ) {
				if ( actionType == this.URL ) {
					location.href = action;
				} else {
					eval(action);
				}
			}
		}
		return false;
	};
}

// 메세지 출력과 action 처리를 위한 객체
var Msg = new _msg("Message!!!");

// error 발생시 메세지 출력과 action 처리를 위한 객체
var Err = new _msg("Error!!!");

