var titleLabel = {};
$(document).ready(function(){
	$.each(titleLabel, function(k, v) {
		if ( k == "main" ) document.title = v;
		$('#tl_'+k).append('<div><span>'+v+'</span></div>');
	});
});


var DateUtil = {
	str2Arr : function(dateStr) {
		var yy = dateStr.substr(0, 4);
		var mm = dateStr.substr(4, 2);
		var dd = dateStr.substr(6, 2);
		var hh = dateStr.substr(8, 2);
		var mi = dateStr.substr(10, 2);
		var ss = dateStr.substr(12, 2);
		return [yy, mm, dd, hh, mi, ss];
	},
	toTime : function(dateStr) {
		var dateArr = this.str2Arr(dateStr);
		return (dateArr[0]+"-"+dateArr[1]+"-"+dateArr[2]+" "+dateArr[3]+":"+dateArr[4]+":"+dateArr[5]);
	},
	toMin : function(dateStr) {
		return this.toTime(dateStr).substring(0, 16);
	},
	toDate : function(dateStr) {
		return this.toTime(dateStr).substring(0, 10);
	},
	getTime : function() {
		var d = new Date();
		return (d.getFullYear() + (d.getMonth() + 1) + d.getDate() + d.getHours() +  d.getMinutes() +  d.getSeconds());
	},
	convDate : function(dateStr) {
		return dateStr.replace(/(\.|\/)/gi, '-');
	}
};

Date.prototype.format = function(f) {
    if (!this.valueOf()) return " ";
 
    var weekName = ["일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일"];
    var d = this;
     
    return f.replace(/(yyyy|yy|MM|dd|E|hh|mm|ss|a\/p)/gi, function($1) {
        switch ($1) {
            case "yyyy": return d.getFullYear();
            case "yy": return (d.getFullYear() % 1000).zf(2);
            case "MM": return (d.getMonth() + 1).zf(2);
            case "dd": return d.getDate().zf(2);
            case "E": return weekName[d.getDay()];
            case "HH": return d.getHours().zf(2);
            case "hh": return ((h = d.getHours() % 12) ? h : 12).zf(2);
            case "mm": return d.getMinutes().zf(2);
            case "ss": return d.getSeconds().zf(2);
            case "a/p": return d.getHours() < 12 ? "오전" : "오후";
            default: return $1;
        }
    });
};
 
String.prototype.string = function(len){var s = '', i = 0; while (i++ < len) { s += this; } return s;};
String.prototype.zf = function(len){return "0".string(len - this.length) + this;};
Number.prototype.zf = function(len){return this.toString().zf(len);};



var UserAgent = {
		getName: function() {
			var agt = navigator.userAgent.toLowerCase();
			if (agt.indexOf("chrome") != -1) return 'Chrome'; 
			if (agt.indexOf("opera") != -1) return 'Opera'; 
			if (agt.indexOf("staroffice") != -1) return 'Star Office'; 
			if (agt.indexOf("webtv") != -1) return 'WebTV'; 
			if (agt.indexOf("beonex") != -1) return 'Beonex'; 
			if (agt.indexOf("chimera") != -1) return 'Chimera'; 
			if (agt.indexOf("netpositive") != -1) return 'NetPositive'; 
			if (agt.indexOf("phoenix") != -1) return 'Phoenix'; 
			if (agt.indexOf("firefox") != -1) return 'Firefox'; 
			if (agt.indexOf("safari") != -1) return 'Safari'; 
			if (agt.indexOf("skipstone") != -1) return 'SkipStone';
			/*
			MS의 렌더링 엔진은 Trident, IE7에서 처음 도입. 하지만 userAgent에 Trident가 명시되기 시작한건 IE8 부터.
			순정 IE7은 “MSIE 7″ 문자열은 포함하지만 “Trident”는 포함하지 않음.
			IE8 이상에서 호환성 보기를 전환하면 userAgent에 버전 정보가 MSIE 7로 표시가 되기 때문에, 두 가지 문자열을 다 포함.
			*/
			//if (agt.indexOf("msie") != -1) return 'Internet Explorer'; // * IE 10 이후 X  
			if ( agt.indexOf("msie") != -1 || agt.indexOf("trident") != -1 ) return 'Internet Explorer'; // * 버전 체크 참조 
			if (agt.indexOf("netscape") != -1) return 'Netscape'; 
			if (agt.indexOf("mozilla/5.0") != -1) return 'Mozilla'; 	
		}
};


function keepSession() {
	$.ajax({
		type : "POST",
		url : getUrl('/check/sess_chk.jsp'),
		success : function(rtn) {
		},
		error : function(xhr, status, error) {
			Logger.error('keepSession error');
			//Msg.out('keepSession error');
		}
	});
}

function fitWidth() {
//	$('#wrap').width($('body').width()-10);
}


var screenSize = {
	width : screen.availWidth,
	height : screen.availHeight 
};


var keepSess = setInterval(keepSession, 60000*5);

$(window).resize(function(){
    fitWidth();
});

$(document).ready(function(){
    fitWidth();
});





$.fn.rowspan = function(colIdx, baseColIdx) {
	if ( baseColIdx === undefined ) baseColIdx = colIdx;
	
    return this.each(function(){      
        var that;     
        $('tr', this).each(function(row) {      
            $('td:eq('+colIdx+')', this).filter(':visible').each(function(col) {
                
            	var $this = $(this);
            	var $that = $(that);
            	
            	for ( var i = 0; i < (colIdx - baseColIdx); i++ ) {
                	$this = $this.prev();
                	$that = $that.prev();
            	}
            	
            	Logger.debug("$(this), $(that)", $(this).html(), $(that).html());
            	Logger.debug("$this, $that", $this.html(), $that.html());
                if ( $(this).html() == $(that).html() && $this.html() == $that.html() ) {            
                    rowspan = $(that).attr("rowspan") || 1;
                    rowspan = Number(rowspan)+1;
 
                    $(that).attr("rowspan",rowspan);
                     
                    // do your action for the colspan cell here            
                    $(this).hide();
                     
                    //$(this).remove(); 
                    // do your action for the old cell here
                     
                } else {            
                    that = this;         
                }          
                 
                // set the that if not already set
                that = (that == null) ? this : that;      
            });     
        });    
    });  
};


/**
 * paging navigation 생성 함수
 * @param totalRows
 *          전체 레코드수
 * @param rowsPerPage
 *          페이지당 출력할 레코드 수
 * @param cPage
 *          현재 페이지 번호
 * @returns 페이지이동 링크 문자열
 */
function createPageList(totalRows, rowsPerPage, cPage, aType) {

	var pnsTmp = "";
	var pageNumsPerList = 10;
	var attrName = "href";
	if ( aType == "PM" ) attrName = "pn";

	var tPage = Math.floor((totalRows - 1) / rowsPerPage) + 1;
	if (tPage < 1) tPage = 1;
	if (cPage > tPage) cPage = tPage;

	var intStart = parseInt((cPage - 1) / pageNumsPerList) * pageNumsPerList + 1;
	var intEnd = parseInt(((cPage - 1) + pageNumsPerList) / pageNumsPerList) * pageNumsPerList;
	
	if (tPage < intEnd) intEnd = tPage;
	if (cPage > 10) {
		pnsTmp += '<a '+attrName+'="#1" id="pnFirst">1</a>';
		pnsTmp += '<a '+attrName+'="#'+(intStart-1)+'" href="#'+(intStart-1)+'" id="pnPre">&lt;&lt;</a>';
		//pnsTmp += '<a '+attrName+'="#'+(intStart-1)+'" id="pnPreImg"><img src="'+getUrl('/intra/img/prev.gif')+'" align="absmiddle" /></a>';
	}
	for (var inti = intStart; inti < intStart + pageNumsPerList; inti++) {
		if (inti > tPage) {
			break;
		} else {
			if (inti == cPage) {
				pnsTmp += '<span id="pnCpage">'+inti+'</span>';
				//pnsTmp += '<b>'+inti+'</b>';
			} else {
				pnsTmp += '<a '+attrName+'="#'+inti+'" class="pnGpage">'+inti+'</a>';
			}
			if ( inti < intEnd ) {
				//pnsTmp += '|';
			}
		}
	}
	if (tPage > intEnd) {
		//pnsTmp += '<a '+attrName+'="#'+(intEnd+1)+'" id="pnNextImg"><img src="'+getUrl('/intra/img/next.gif')+'" align="absmiddle" /></a>';
		pnsTmp += '<a '+attrName+'="#'+(intEnd+1)+'" id="pnNext">&gt;&gt;</a>';
		pnsTmp += '<a '+attrName+'="#'+tPage+'" id="pnLast">'+tPage+'</a>';
	}
	
	return pnsTmp;
}

/**
 * URL 파라미터 분리
 * @param url 
 * 		현재 지도의 레이어 dataset 값
 * */
function UrlParamsParse(url){
	var params = url.substr(url.indexOf("?")+1);
	var rtnVal = {};
	params = params.split("&");
	// split param and value into individual pieces
	for ( var i = 0; i < params.length; i++ ) {
		var temp = params[i].split("=");
		rtnVal[temp[0]] = temp[1];
	}
	return rtnVal;
}