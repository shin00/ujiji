JsCss.setType(JsCss.TYPE.JS);
JsCss.setPath('/js/util/inputmask/');
JsCss.load(
		'jquery.inputmask.js',
		'jquery.inputmask.numeric.extensions.js',
		'jquery.inputmask.date.extensions.js',
		'jquery.inputmask.regex.extensions.js',
		'jquery.inputmask.extensions.js'
);

var cmMask = {
	date: 'yyyy.mm.dd',
	dateTime: 'y.m.d h:s'
};