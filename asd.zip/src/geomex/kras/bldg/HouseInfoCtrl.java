﻿package geomex.kras.bldg;

import geomex.kras.ivo.*;
import geomex.kras.vo.*;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.FormParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;


@Path("/house_info")
public class HouseInfoCtrl {
	
	private HouseInfoService houseInfoSvc = new HouseInfoService();

	
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public HouseInfoDataSet getData(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu) {
		
		HouseInfoDataSet ds = houseInfoSvc.getData(pnu);
		
		return ds;
	}

	@GET
	@Path("/body")
	@Produces(MediaType.APPLICATION_XML)
	public HouseInfo getBody(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu) {
		
		HouseInfoDataSet ds = houseInfoSvc.getData(pnu);
		HouseInfo houseInfo = new HouseInfo();
		if ( ds != null && ds.getBody() != null ) houseInfo = new HouseInfo(ds.getBody().getHouseInfo());
		
		return houseInfo;
	}
}
