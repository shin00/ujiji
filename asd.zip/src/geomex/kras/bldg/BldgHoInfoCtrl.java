﻿package geomex.kras.bldg;

import geomex.kras.ivo.*;
import geomex.kras.vo.*;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.FormParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import java.util.ArrayList;


@Path("/bldg_ho_info")
public class BldgHoInfoCtrl {
	
	private BldgHoInfoService bldgHoInfoSvc = new BldgHoInfoService();

	
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public BldgHoInfoDataSet getData(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu, @QueryParam("bno") final String bno) {
		
		BldgHoInfoDataSet ds = bldgHoInfoSvc.getData(pnu, bno);
		
		return ds;
	}

	@GET
	@Path("/body")
	@Produces(MediaType.APPLICATION_XML)
	public ArrayList<BldgHoInfo> getBody(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu, @QueryParam("bno") final String bno) {
		
		BldgHoInfoDataSet ds = bldgHoInfoSvc.getData(pnu, bno);
		ArrayList<BldgHoInfo> bldgHoInfoList = new ArrayList<BldgHoInfo>();

		ArrayList<BldgHoInfo> tmp = new ArrayList<BldgHoInfo>();
		if ( ds != null && ds.getBody() != null ) tmp = ds.getBody().getBldgHoInfoList();
		
		for ( int i = 0; i < tmp.size(); i++ ) {
			bldgHoInfoList.add(new BldgHoInfo(tmp.get(i)));
		}
		
		return bldgHoInfoList;
	}
}
