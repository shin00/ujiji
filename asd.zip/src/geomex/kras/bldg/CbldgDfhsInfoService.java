﻿package geomex.kras.bldg;

import geomex.kras.ivo.*;
import geomex.kras.vo.*;


public class CbldgDfhsInfoService {

	private	CbldgDfhsInfoDao cbldgDfhsInfoDao = new CbldgDfhsInfoDao();

	
	public CbldgDfhsInfoDataSet getData(String pnu, String bno) {

		return cbldgDfhsInfoDao.getData(pnu, bno);
	
	}

}
