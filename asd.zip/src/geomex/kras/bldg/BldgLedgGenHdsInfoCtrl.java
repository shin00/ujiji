﻿package geomex.kras.bldg;

import geomex.kras.ivo.*;
import geomex.kras.vo.*;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.FormParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;


@Path("/bldg_ledg_gen_hds_info")
public class BldgLedgGenHdsInfoCtrl {
	
	private BldgLedgGenHdsInfoService bldgLedgGenHdsInfoSvc = new BldgLedgGenHdsInfoService();

	
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public BldgLedgGenHdsInfoDataSet getData(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu) {
		
		BldgLedgGenHdsInfoDataSet ds = bldgLedgGenHdsInfoSvc.getData(pnu);
		
		return ds;
	}

	@GET
	@Path("/body")
	@Produces(MediaType.APPLICATION_XML)
	public BldgLedgGenHdsInfo getBody(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu) {
		
		BldgLedgGenHdsInfoDataSet ds = bldgLedgGenHdsInfoSvc.getData(pnu);
		BldgLedgGenHdsInfo bldgLedgGenHdsInfo = new BldgLedgGenHdsInfo();
		if ( ds != null && ds.getBody() != null ) bldgLedgGenHdsInfo = new BldgLedgGenHdsInfo(ds.getBody().getBldgLedgGenHdsInfo());
		
		return bldgLedgGenHdsInfo;
	}
}
