﻿package geomex.kras.bldg;

import geomex.kras.ivo.*;
import geomex.kras.vo.*;


public class BldgLedgGenHdsInfoService {

	private	BldgLedgGenHdsInfoDao bldgLedgGenHdsInfoDao = new BldgLedgGenHdsInfoDao();

	
	public BldgLedgGenHdsInfoDataSet getData(String pnu) {

		return bldgLedgGenHdsInfoDao.getData(pnu);
	
	}

}
