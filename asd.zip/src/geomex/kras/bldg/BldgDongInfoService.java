﻿package geomex.kras.bldg;

import geomex.kras.ivo.*;
import geomex.kras.vo.*;


public class BldgDongInfoService {

	private	BldgDongInfoDao bldgDongInfoDao = new BldgDongInfoDao();

	
	public BldgDongInfoDataSet getData(String pnu) {

		return bldgDongInfoDao.getData(pnu);
	
	}

}
