﻿package geomex.kras.bldg;

import geomex.kras.ivo.*;
import geomex.kras.vo.*;


public class CbldgHdsInfoService {

	private	CbldgHdsInfoDao cbldgHdsInfoDao = new CbldgHdsInfoDao();

	
	public BldgHdsInfoDataSet getData(String pnu, String bno) {

		return cbldgHdsInfoDao.getData(pnu, bno);
	
	}

}
