package geomex.kras.bldg;

import geomex.kras.KrasConn;
import geomex.kras.ivo.*;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.io.IOUtils;

/**
 * 
* <PRE>
* 파일명   : CbldgDfhsInfoDao.java
* 파일설명 : 집합건축물(전유부) 조회 
* 수정이력 : 
*       2015. 6. 14.  이규하  : 최초작성
* </PRE>
*
* @author 이규하
*
 */
public class CbldgDfhsInfoDao {

	private static KrasConn krasConn = new KrasConn();

	
	public CbldgDfhsInfoDataSet getData(String pnu, String bno) {
		
		CbldgDfhsInfoDataSet cbldgDfhsInfoDataSet = new CbldgDfhsInfoDataSet();

		try {
			JAXBContext jc = JAXBContext.newInstance(CbldgDfhsInfoDataSet.class);

	        Unmarshaller unmarshaller = jc.createUnmarshaller();

	        String data = krasConn.getBldgData("KRAS000016", pnu, bno);
	        
	        if ( data != null ) {
	        	if ( data.equals("-1") ) {
	        		System.out.println("접속서버정보가 없음. PNU : " + pnu);
	        	} else {
	    	        cbldgDfhsInfoDataSet = (CbldgDfhsInfoDataSet) unmarshaller.unmarshal(IOUtils.toInputStream(data, "UTF-8"));
	        	}
	        }

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}
		
		return cbldgDfhsInfoDataSet;
	}

}
