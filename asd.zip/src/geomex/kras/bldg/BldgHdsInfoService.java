﻿package geomex.kras.bldg;

import geomex.kras.ivo.*;
import geomex.kras.vo.*;


public class BldgHdsInfoService {

	private	BldgHdsInfoDao bldgHdsInfoDao = new BldgHdsInfoDao();

	
	public BldgHdsInfoDataSet getData(String pnu, String bno) {

		return bldgHdsInfoDao.getData(pnu, bno);
	
	}

}
