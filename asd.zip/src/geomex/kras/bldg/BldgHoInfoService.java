﻿package geomex.kras.bldg;

import geomex.kras.ivo.*;
import geomex.kras.vo.*;


public class BldgHoInfoService {

	private	BldgHoInfoDao bldgHoInfoDao = new BldgHoInfoDao();

	
	public BldgHoInfoDataSet getData(String pnu, String bno) {

		return bldgHoInfoDao.getData(pnu, bno);
	
	}

}
