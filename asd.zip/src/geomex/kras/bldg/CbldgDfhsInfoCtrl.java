﻿package geomex.kras.bldg;

import geomex.kras.ivo.*;
import geomex.kras.vo.*;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.FormParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;


@Path("/cbldg_dfhs_info")
public class CbldgDfhsInfoCtrl {
	
	private CbldgDfhsInfoService cbldgDfhsInfoSvc = new CbldgDfhsInfoService();

	
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public CbldgDfhsInfoDataSet getData(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu, @QueryParam("bno") final String bno) {
		
		CbldgDfhsInfoDataSet ds = cbldgDfhsInfoSvc.getData(pnu, bno);
		
		return ds;
	}

	@GET
	@Path("/body")
	@Produces(MediaType.APPLICATION_XML)
	public CbldgDfhsInfo getBody(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu, @QueryParam("bno") final String bno) {
		
		CbldgDfhsInfoDataSet ds = cbldgDfhsInfoSvc.getData(pnu, bno);
		CbldgDfhsInfo cbldgDfhsInfo = new CbldgDfhsInfo();
		if ( ds != null && ds.getBody() != null ) cbldgDfhsInfo = new CbldgDfhsInfo(ds.getBody().getCbldgDfhsInfoSet().getCbldgDfhsInfo());
		
		return cbldgDfhsInfo;
	}
}
