﻿package geomex.kras.bldg;

import geomex.kras.ivo.*;
import geomex.kras.vo.*;


public class HouseInfoService {

	private	HouseInfoDao houseInfoDao = new HouseInfoDao();

	
	public HouseInfoDataSet getData(String pnu) {

		return houseInfoDao.getData(pnu);
	
	}

}
