﻿package geomex.kras.bldg;

import geomex.kras.ivo.*;
import geomex.kras.vo.*;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.FormParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import java.util.ArrayList;


@Path("/bldg_dong_info")
public class BldgDongInfoCtrl {
	
	private BldgDongInfoService bldgDongInfoSvc = new BldgDongInfoService();

	
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public BldgDongInfoDataSet getData(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu) {
		
		BldgDongInfoDataSet ds = bldgDongInfoSvc.getData(pnu);
		
		return ds;
	}

	@GET
	@Path("/body")
	@Produces(MediaType.APPLICATION_XML)
	public ArrayList<BldgDongInfo> getBody(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu) {
		
		BldgDongInfoDataSet ds = bldgDongInfoSvc.getData(pnu);
		ArrayList<BldgDongInfo> bldgDongInfoList = new ArrayList<BldgDongInfo>();
		
		ArrayList<BldgDongInfo> tmp = new ArrayList<BldgDongInfo>();
		if ( ds != null && ds.getBody() != null ) tmp = ds.getBody().getBldgDongInfoList();
		
		for ( int i = 0; i < tmp.size(); i++ ) {
			bldgDongInfoList.add(new BldgDongInfo(tmp.get(i)));
		}
		
		return bldgDongInfoList;
	}
}
