package geomex.kras.ivo;

import geomex.kras.common.vo.ResponseHeader;
import geomex.kras.vo.HouseInfo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;


@XmlRootElement(name = "RESPONSE")
@XmlAccessorType(XmlAccessType.FIELD)
public class HouseInfoDataSet {

	@XmlAccessorType(XmlAccessType.FIELD)
	public static class ResponseBody {

		@XmlElement(name = "HOUSE_INFO_SET")
		private HouseInfo houseInfo;

		public ResponseBody() {
		}
		
		public ResponseBody(ResponseBody body) {
			setHouseInfo(body.getHouseInfo()); 
		}

		
		public HouseInfo getHouseInfo() {
			return houseInfo;
		}
		public void setHouseInfo(HouseInfo houseInfo) {
			this.houseInfo = new HouseInfo(houseInfo);
		}

		
		@Override
		public String toString() {
			return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
		}

		@Override
		public int hashCode() {
			return HashCodeBuilder.reflectionHashCode(this, false);
		}

		@Override
		public boolean equals(Object obj) {
			return EqualsBuilder.reflectionEquals(this, obj, false);
		}

	}

	@XmlElement(name = "HEADER")
	private ResponseHeader header;
	
	@XmlElement(name = "BODY")
	private ResponseBody body;

	
	public HouseInfoDataSet() {
		
	}
	
	public ResponseHeader getHeader() {
		return header;
	}
	public void setHeader(ResponseHeader header) {
		this.header = new ResponseHeader(header);
	}

	public ResponseBody getBody() {
		return body;
	}
	public void setBody(ResponseBody body) {
		this.body = new ResponseBody(body);
	}

	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this, false);
	}

	@Override
	public boolean equals(Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj, false);
	}
	
}
