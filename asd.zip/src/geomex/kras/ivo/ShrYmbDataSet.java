package geomex.kras.ivo;

import java.util.ArrayList;

import geomex.kras.common.vo.ResponseHeader;
import geomex.kras.vo.ShrYmb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;


@XmlRootElement(name = "RESPONSE")
@XmlAccessorType(XmlAccessType.FIELD)
public class ShrYmbDataSet {

	@XmlAccessorType(XmlAccessType.FIELD)
	public static class ResponseBody {

		@XmlElementWrapper(name = "SHR_YMB_SET")
		@XmlElement(name = "SHR_YMB")
		private ArrayList<ShrYmb> shrYmbList;

		public ResponseBody() {
		}
		
		public ResponseBody(ResponseBody body) {
			setShrYmbList(body.getShrYmbList()); 
		}

		
		public ArrayList<ShrYmb> getShrYmbList() {
			return shrYmbList;
		}
		public void setShrYmbList(ArrayList<ShrYmb> shrYmbList) {
			this.shrYmbList = shrYmbList;
		}

		
		@Override
		public String toString() {
			return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
		}

		@Override
		public int hashCode() {
			return HashCodeBuilder.reflectionHashCode(this, false);
		}

		@Override
		public boolean equals(Object obj) {
			return EqualsBuilder.reflectionEquals(this, obj, false);
		}

	}

	@XmlElement(name = "HEADER")
	private ResponseHeader header;
	
	@XmlElement(name = "BODY")
	private ResponseBody body;

	
	public ShrYmbDataSet() {
		
	}
	
	public ResponseHeader getHeader() {
		return header;
	}
	public void setHeader(ResponseHeader header) {
		this.header = new ResponseHeader(header);
	}

	public ResponseBody getBody() {
		return body;
	}
	public void setBody(ResponseBody body) {
		this.body = new ResponseBody(body);
	}

	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this, false);
	}

	@Override
	public boolean equals(Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj, false);
	}
	
}
