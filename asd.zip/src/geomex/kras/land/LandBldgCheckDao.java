package geomex.kras.land;

import geomex.kras.KrasConn;
import geomex.kras.ivo.*;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.io.IOUtils;

/**
 * 
* <PRE>
* 파일명   : LandBldgCheckDao.java
* 파일설명 : 토지(건물)조재여부 조회
* 수정이력 : 
*       2015. 6. 9.  이규하  : 최초작성
* </PRE>
*
* @author 이규하
*
 */
public class LandBldgCheckDao {

	private static KrasConn krasConn = new KrasConn();

	
	public LandBldgCheckDataSet getData(String pnu) {
		
		LandBldgCheckDataSet landBldgCheckDataSet = new LandBldgCheckDataSet();

		try {
			JAXBContext jc = JAXBContext.newInstance(LandBldgCheckDataSet.class);

	        Unmarshaller unmarshaller = jc.createUnmarshaller();

	        String data = krasConn.getData("KRAS000101", pnu);
	        
	        if ( data != null ) {
	        	if ( data.equals("-1") ) {
	        		System.out.println("접속서버정보가 없음. PNU : " + pnu);
	        	} else {
	    	        landBldgCheckDataSet = (LandBldgCheckDataSet) unmarshaller.unmarshal(IOUtils.toInputStream(data, "UTF-8"));
	        	}
	        }

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}
		
		return landBldgCheckDataSet;
	}

}
