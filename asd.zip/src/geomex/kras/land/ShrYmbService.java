﻿package geomex.kras.land;

import geomex.kras.ivo.*;
import geomex.kras.vo.*;


public class ShrYmbService {

	private	ShrYmbDao shrYmbDao = new ShrYmbDao();

	
	public ShrYmbDataSet getData(String pnu) {

		return shrYmbDao.getData(pnu);
	
	}

}
