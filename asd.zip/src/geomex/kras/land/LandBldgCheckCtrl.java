﻿package geomex.kras.land;

import geomex.kras.ivo.*;
import geomex.kras.vo.*;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;


@Path("/land_bldg_check")
public class LandBldgCheckCtrl {
	
	private LandBldgCheckService landBldgCheckSvc = new LandBldgCheckService();

	
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public LandBldgCheckDataSet getData(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu) {
		
		LandBldgCheckDataSet ds = landBldgCheckSvc.getData(pnu);
		
		return ds;
	}

	@GET
	@Path("/body")
	@Produces(MediaType.APPLICATION_XML)
	public LandBldgCheck getBody(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu) {
		
		LandBldgCheckDataSet ds = landBldgCheckSvc.getData(pnu);
		LandBldgCheck landBldgCheck = new LandBldgCheck();
		if ( ds != null && ds.getBody() != null ) landBldgCheck = new LandBldgCheck(ds.getBody().getLandBldgCheck());
		
		return landBldgCheck;
	}

}
