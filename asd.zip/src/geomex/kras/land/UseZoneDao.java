package geomex.kras.land;

import geomex.kras.KrasConn;
import geomex.kras.ivo.*;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.io.IOUtils;

/**
 * 
* <PRE>
* 파일명   : UseZoneDao.java
* 파일설명 : 필지별 용도지역지구
* 수정이력 : 
*       2015. 6. 26.  이규하  : 최초작성
* </PRE>
*
* @author 이규하
*
 */
public class UseZoneDao {

	private static KrasConn krasConn = new KrasConn();

	
	public UseZoneDataSet getData(String pnu) {
		
		UseZoneDataSet useZoneDataSet = new UseZoneDataSet();

		try {
			JAXBContext jc = JAXBContext.newInstance(UseZoneDataSet.class);

	        Unmarshaller unmarshaller = jc.createUnmarshaller();

	        String data = krasConn.getData("KRAS000027", pnu);
	        
	        if ( data != null ) {
	        	if ( data.equals("-1") ) {
	        		System.out.println("접속서버정보가 없음. PNU : " + pnu);
	        	} else {
	    	        useZoneDataSet = (UseZoneDataSet) unmarshaller.unmarshal(IOUtils.toInputStream(data, "UTF-8"));
	        	}
	        }

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}
		
		return useZoneDataSet;
	}

}
