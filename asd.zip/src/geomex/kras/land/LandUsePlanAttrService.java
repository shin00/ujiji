﻿package geomex.kras.land;

import geomex.kras.ivo.*;
import geomex.kras.vo.*;


public class LandUsePlanAttrService {

	private	LandUsePlanAttrDao landUsePlanAttrDao = new LandUsePlanAttrDao();

	
	public LandUsePlanAttrDataSet getData(String pnu) {

		return landUsePlanAttrDao.getData(pnu);
	
	}

}
