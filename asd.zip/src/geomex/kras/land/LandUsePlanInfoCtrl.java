﻿package geomex.kras.land;

import geomex.kras.ivo.*;
import geomex.kras.vo.*;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.FormParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;


@Path("/land_use_plan_info")
public class LandUsePlanInfoCtrl {
	
	private LandUsePlanInfoService landUsePlanInfoSvc = new LandUsePlanInfoService();

	
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public LandUsePlanInfoDataSet getData(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu) {
		
		LandUsePlanInfoDataSet ds = landUsePlanInfoSvc.getData(pnu);
		
		return ds;
	}

	@GET
	@Path("/body")
	@Produces(MediaType.APPLICATION_XML)
	public LandUsePlanInfo getBody(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu) {
		
		LandUsePlanInfoDataSet ds = landUsePlanInfoSvc.getData(pnu);
		LandUsePlanInfo landUsePlanInfo = new LandUsePlanInfo();
		if ( ds != null && ds.getBody() != null ) landUsePlanInfo = new LandUsePlanInfo(ds.getBody().getLandUsePlanInfo());
		
		return landUsePlanInfo;
	}
}
