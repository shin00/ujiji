﻿package geomex.kras.land;

import geomex.kras.ivo.*;
import geomex.kras.vo.*;


public class OwnRgtHistService {

	private	OwnRgtHistDao ownRgtHistDao = new OwnRgtHistDao();

	
	public OwnRgtHistDataSet getData(String pnu) {

		return ownRgtHistDao.getData(pnu);
	
	}

}
