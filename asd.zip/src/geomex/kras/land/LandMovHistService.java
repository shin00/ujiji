﻿package geomex.kras.land;

import geomex.kras.ivo.*;
import geomex.kras.vo.*;


public class LandMovHistService {

	private	LandMovHistDao landMovHistDao = new LandMovHistDao();

	
	public LandMovHistDataSet getData(String pnu) {

		return landMovHistDao.getData(pnu);
	
	}

}
