package geomex.kras.land;

import geomex.kras.KrasConn;
import geomex.kras.ivo.*;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.io.IOUtils;

/**
 * 
* <PRE>
* 파일명   : ShrYmbDao.java
* 파일설명 : 공유지연명부
* 수정이력 : 
*       2015. 6. 14.  이규하  : 최초작성
* </PRE>
*
* @author 이규하
*
 */
public class ShrYmbDao {

	private static KrasConn krasConn = new KrasConn();

	
	public ShrYmbDataSet getData(String pnu) {
		
		ShrYmbDataSet shrYmbDataSet = new ShrYmbDataSet();

		try {
			JAXBContext jc = JAXBContext.newInstance(ShrYmbDataSet.class);

	        Unmarshaller unmarshaller = jc.createUnmarshaller();

	        String data = krasConn.getData("KRAS000003", pnu);
	        
	        if ( data != null ) {
	        	if ( data.equals("-1") ) {
	        		System.out.println("접속서버정보가 없음. PNU : " + pnu);
	        	} else {
	    	        shrYmbDataSet = (ShrYmbDataSet) unmarshaller.unmarshal(IOUtils.toInputStream(data, "UTF-8"));
	        	}
	        }

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}
		
		return shrYmbDataSet;
	}

}
