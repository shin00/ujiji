﻿package geomex.kras.land;

import geomex.kras.ivo.*;
import geomex.kras.vo.*;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.FormParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;


@Path("/use_zone")
public class UseZoneCtrl {
	
	private UseZoneService useZoneSvc = new UseZoneService();

	
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public UseZoneDataSet getData(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu) {
		
		UseZoneDataSet ds = useZoneSvc.getData(pnu);
		
		return ds;

	}

	@GET
	@Path("/body")
	@Produces(MediaType.APPLICATION_XML)
	public UseZone getBody(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu) {
		
		UseZoneDataSet ds = useZoneSvc.getData(pnu);
		UseZone useZone = new UseZone();
		if ( ds != null && ds.getBody() != null ) useZone = new UseZone(ds.getBody().getUseZone());
		
		return useZone;
	}
}
