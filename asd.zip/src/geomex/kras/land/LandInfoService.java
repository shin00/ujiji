﻿package geomex.kras.land;

import geomex.kras.ivo.*;
import geomex.kras.vo.*;


public class LandInfoService {

	private	LandInfoDao landInfoDao = new LandInfoDao();

	
	public LandInfoDataSet getData(String pnu) {

		return landInfoDao.getData(pnu);
	
	}

}
