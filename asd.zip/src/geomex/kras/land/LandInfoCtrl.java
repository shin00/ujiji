﻿package geomex.kras.land;

import geomex.kras.ivo.*;
import geomex.kras.vo.*;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.FormParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;


@Path("/land_info")
public class LandInfoCtrl {
	
	private LandInfoService landInfoSvc = new LandInfoService();

	
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public LandInfoDataSet getData(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu) {
		
		LandInfoDataSet ds = landInfoSvc.getData(pnu);
		
		return ds;
	}

	@GET
	@Path("/body")
	@Produces(MediaType.APPLICATION_XML)
	public LandInfo getBody(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu) {
		
		LandInfoDataSet ds = landInfoSvc.getData(pnu);
		LandInfo landInfo = new LandInfo();
		if ( ds != null && ds.getBody() != null ) landInfo = new LandInfo(ds.getBody().getLandInfo());
		
		return landInfo;
	}
}
