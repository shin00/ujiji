package geomex.kras.land;

import geomex.kras.KrasConn;
import geomex.kras.ivo.*;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.io.IOUtils;

/**
 * 
* <PRE>
* 파일명   : LandUsePlanAttrDao.java
* 파일설명 : 토지이용계획 속성
* 수정이력 : 
*       2015. 6. 14.  이규하  : 최초작성
* </PRE>
*
* @author 이규하
*
 */
public class LandUsePlanAttrDao {

	private static KrasConn krasConn = new KrasConn();

	
	public LandUsePlanAttrDataSet getData(String pnu) {
		
		LandUsePlanAttrDataSet landUsePlanAttrDataSet = new LandUsePlanAttrDataSet();

		try {
			JAXBContext jc = JAXBContext.newInstance(LandUsePlanAttrDataSet.class);

	        Unmarshaller unmarshaller = jc.createUnmarshaller();

	        String data = krasConn.getData("KRAS000025", pnu);
	        
	        if ( data != null ) {
	        	if ( data.equals("-1") ) {
	        		System.out.println("접속서버정보가 없음. PNU : " + pnu);
	        	} else {
	    	        landUsePlanAttrDataSet = (LandUsePlanAttrDataSet) unmarshaller.unmarshal(IOUtils.toInputStream(data, "UTF-8"));
	        	}
	        }

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}
		
		return landUsePlanAttrDataSet;
	}

}
