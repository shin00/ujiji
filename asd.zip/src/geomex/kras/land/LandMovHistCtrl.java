﻿package geomex.kras.land;

import geomex.kras.ivo.*;
import geomex.kras.vo.*;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.FormParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import java.util.ArrayList;


@Path("/land_mov_hist")
public class LandMovHistCtrl {
	
	private LandMovHistService landMovHistSvc = new LandMovHistService();

	
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public LandMovHistDataSet getData(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu) {
		
		LandMovHistDataSet ds = landMovHistSvc.getData(pnu);
		
		return ds;
	}

	@GET
	@Path("/body")
	@Produces(MediaType.APPLICATION_XML)
	public ArrayList<LandMovHist> getBody(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu) {
		
		LandMovHistDataSet ds = landMovHistSvc.getData(pnu);
		ArrayList<LandMovHist> landMovHistList = new ArrayList<LandMovHist>();

		ArrayList<LandMovHist> tmp = new ArrayList<LandMovHist>();
		if ( ds != null && ds.getBody() != null ) tmp = ds.getBody().getLandMovHistList();
		
		for ( int i = 0; i < tmp.size(); i++ ) {
			landMovHistList.add(new LandMovHist(tmp.get(i)));
		}

		return landMovHistList;
	}
}
