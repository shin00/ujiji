﻿package geomex.kras.land;

import geomex.kras.ivo.*;
import geomex.kras.vo.*;


public class LandJigaService {

	private	LandJigaDao landJigaDao = new LandJigaDao();

	
	public LandJigaDataSet getData(String pnu) {

		return landJigaDao.getData(pnu);
	
	}

}
