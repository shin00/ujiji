﻿package geomex.kras.land;

import geomex.kras.ivo.*;
import geomex.kras.vo.*;


public class LandUsePlanInfoService {

	private	LandUsePlanInfoDao landUsePlanInfoDao = new LandUsePlanInfoDao();

	
	public LandUsePlanInfoDataSet getData(String pnu) {

		return landUsePlanInfoDao.getData(pnu);
	
	}

}
