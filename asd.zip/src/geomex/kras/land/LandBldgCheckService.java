﻿package geomex.kras.land;

import geomex.kras.ivo.*;
import geomex.kras.vo.*;


public class LandBldgCheckService {

	private	LandBldgCheckDao landBldgCheckDao = new LandBldgCheckDao();

	
	public LandBldgCheckDataSet getData(String pnu) {

		return landBldgCheckDao.getData(pnu);
	
	}

	/**
	 * 토지,건물 존재 여부
	 * @param pnu
	 * @return
	 *         -1 : 토지없음
	 *          1 : 토지있음
	 *          2 : 토지,건물있음 
	 */
	public int getStat(String pnu) {

		int rst = -1;
		
		LandBldgCheckDataSet ds = getData(pnu);
		
		if ( ds.getHeader().getCode().equals("0000") ) {
			if( ds.getBody().getLandBldgCheck().getRealGbn().getVal().equals("토지") ) rst = 1;
			if( ds.getBody().getLandBldgCheck().getRealGbn().getVal().equals("토지(건물)") ) rst = 2;
		} else if ( ds.getHeader().getCode().equals("4017") ) {
			rst = 0;
		}
		
		return rst;
	
	}
}
