﻿package geomex.kras.land;

import geomex.kras.ivo.*;
import geomex.kras.vo.*;


public class UseZoneService {

	private	UseZoneDao useZoneDao = new UseZoneDao();

	
	public UseZoneDataSet getData(String pnu) {

		return useZoneDao.getData(pnu);
	
	}

}
