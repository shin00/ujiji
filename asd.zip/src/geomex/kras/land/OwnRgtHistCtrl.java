﻿package geomex.kras.land;

import geomex.kras.ivo.*;
import geomex.kras.vo.*;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.FormParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import java.util.ArrayList;


@Path("/own_rgt_hist")
public class OwnRgtHistCtrl {
	
	private OwnRgtHistService ownRgtHistSvc = new OwnRgtHistService();

	
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public OwnRgtHistDataSet getData(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu) {
		
		OwnRgtHistDataSet ds = ownRgtHistSvc.getData(pnu);
		
		return ds;
	}

	@GET
	@Path("/body")
	@Produces(MediaType.APPLICATION_XML)
	public ArrayList<OwnRgtHist> getBody(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu) {
		
		OwnRgtHistDataSet ds = ownRgtHistSvc.getData(pnu);
		ArrayList<OwnRgtHist> ownRgtHistList = new ArrayList<OwnRgtHist>();

		ArrayList<OwnRgtHist> tmp = new ArrayList<OwnRgtHist>();
		if ( ds != null && ds.getBody() != null ) tmp = ds.getBody().getOwnRgtHistList();
		
		for ( int i = 0; i < tmp.size(); i++ ) {
			ownRgtHistList.add(new OwnRgtHist(tmp.get(i)));
		}		
		
		return ownRgtHistList;
	}
}
