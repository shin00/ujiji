package geomex.kras.land;

import geomex.kras.KrasConn;
import geomex.kras.ivo.*;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.io.IOUtils;

/**
 * 
* <PRE>
* 파일명   : OwnRgtHistDao.java
* 파일설명 : 소유권변동연혁
* 수정이력 : 
*       2015. 6. 14.  이규하  : 최초작성
* </PRE>
*
* @author 이규하
*
 */
public class OwnRgtHistDao {

	private static KrasConn krasConn = new KrasConn();

	
	public OwnRgtHistDataSet getData(String pnu) {
		
		OwnRgtHistDataSet ownRgtHistDataSet = new OwnRgtHistDataSet();

		try {
			JAXBContext jc = JAXBContext.newInstance(OwnRgtHistDataSet.class);

	        Unmarshaller unmarshaller = jc.createUnmarshaller();

	        String data = krasConn.getData("KRAS000007", pnu);
	        
	        if ( data != null ) {
	        	if ( data.equals("-1") ) {
	        		System.out.println("접속서버정보가 없음. PNU : " + pnu);
	        	} else {
	    	        ownRgtHistDataSet = (OwnRgtHistDataSet) unmarshaller.unmarshal(IOUtils.toInputStream(data, "UTF-8"));
	        	}
	        }

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}
		
		return ownRgtHistDataSet;
	}

}
