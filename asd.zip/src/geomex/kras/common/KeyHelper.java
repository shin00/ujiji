package geomex.kras.common;

import java.util.ArrayList;

import org.apache.commons.lang3.StringUtils;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import geomex.utils.cipher.Base64;
import geomex.kras.common.vo.Col;

/**
* <PRE>
* 파일명   : KeyHelper.java
* 파일설명 : 
* 수정이력 : 
*       2014. 5. 28.  이규하  : 최초작성
* </PRE>
*/
public class KeyHelper {
	
	public static String toJSON(ArrayList<Col> keyList) {

		JSONArray jsonKey = new JSONArray();
		
		try {
			for (int i = 0; i < keyList.size(); i++) {
				JSONObject jsonFV = new JSONObject();
				jsonFV.putOpt("f", keyList.get(i).getName());
				jsonFV.putOpt("v", keyList.get(i).getVal()) ;
				jsonKey.put(jsonFV);
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}

		return jsonKey.toString();
	}

	
	public static String encode(ArrayList<Col> keyList) {
		return Base64.encodeString(toJSON(keyList));
	}

	public static String encode(String keyJsonStr) {
		return Base64.encodeString(keyJsonStr);
	}

	
	public static JSONArray decode(String key) {

		JSONArray jsonKey = new JSONArray();

		try {
			jsonKey = new JSONArray(Base64.decodeString(key));
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		return jsonKey;
	}
	

	public static String toQuery(JSONArray key, String alias) {
		
		StringBuilder kStr = new StringBuilder();
		
		JSONArray jArr = key;
		JSONObject jObj2 = new JSONObject();

		try {
			if ( jArr.length() > 0 ) {
				for (int i = 0; i < jArr.length(); i++) {
					jObj2 = (JSONObject)jArr.get(i);
					if ( jObj2.length() > 0 ) {
						if ( i > 0 ) kStr.append(" and ");
						if ( !StringUtils.isEmpty(alias) ) kStr.append(alias).append(".");
						kStr.append(jObj2.getString("f")).append(" = '").append(jObj2.getString("v")).append("'");
					}
				}
			}
			
		} catch (Exception e) {
            e.printStackTrace();
		} 

		return kStr.toString();
	}

	public static String toQuery(JSONArray key) {
		return toQuery(key, null);
	}
	
	public static String toQuery(String key, String alias) {
		
		return toQuery(decode(key), alias);
	}

	public static String toQuery(String key) {
		return toQuery(key, null);
	}

}
