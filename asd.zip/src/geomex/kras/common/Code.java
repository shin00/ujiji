package geomex.kras.common;

import geomex.kras.KrasConnCfg;
import geomex.utils.db.DBHandler;

import java.sql.SQLException;
import java.util.HashMap;

import org.apache.commons.lang3.StringUtils;

public class Code {

	private static String DEFAULT_SCHEMA = "";
	private static String DEFAULT_DB_NODE = "";
	
	static {

		HashMap<String, String> cfg = KrasConnCfg.getCfg();

		DEFAULT_SCHEMA = cfg.get("default_schema");
		if ( !"".equals(DEFAULT_SCHEMA) ) DEFAULT_SCHEMA += ".";
		
		DEFAULT_DB_NODE = cfg.get("default_db_node");
		
	}

	
	/**
	 * 토지코드명(약어)
	 * @param cd
	 * @return
	 */
	public static String getTojiNm(String cd) {
		return getTojiNm(cd, false);
	}
	/**
	 * 토지코드명
	 * @param cd
	 * @param fullNm
	 * @return
	 */
	public static String getTojiNm(String cd, boolean fullNm) {
		
		String rst = "";
		int rIdx = 0;
		if ( fullNm ) rIdx = 1;

		String key = "";
		if ( cd != null ) key = cd;
		
		HashMap<String, String> cdMap = new HashMap<String, String>();
		cdMap.put("1", "|");
		cdMap.put("2", "산|산번지");
		cdMap.put("3", "가|가지번");
		cdMap.put("4", "가|가지번(부번세분)");
		cdMap.put("5", "BL|블럭지번");
		cdMap.put("6", "BL|블럭지번(롯트세분)");
		cdMap.put("7", "지구BL|블럭지번(지구)");
		cdMap.put("8", "지구BL|블럭지번(지구-롯트)");
		cdMap.put("9", "|기타지번");
		
		if ( !key.equals("") ) rst = cdMap.get(key).split("\\|")[rIdx];
		return rst;
	}

	/**
	 * 지목코드명(약어)
	 * @param cd
	 * @return
	 */
	public static String getJimokNm(String cd) {
		return getJimokNm(cd, false);
	}
	/**
	 * 지목코드명
	 * @param cd
	 * @param fullNm
	 * @return
	 */
	public static String getJimokNm(String cd, boolean fullNm) {
		
		String rst = "";
		int rIdx = 0;
		if ( fullNm ) rIdx = 1;

		String key = "";
		if ( cd != null ) key = cd;
		
		HashMap<String, String> cdMap = new HashMap<String, String>();
		cdMap.put("01", "전|전");
		cdMap.put("02", "답|답");
		cdMap.put("03", "과|과수원");
		cdMap.put("04", "목|목장용지");
		cdMap.put("05", "임|임야");
		cdMap.put("06", "광|광천지");
		cdMap.put("07", "염|염전");
		cdMap.put("08", "대|대");
		cdMap.put("09", "장|공장용지");
		cdMap.put("10", "학|학교용지");
		cdMap.put("11", "차|주차장");
		cdMap.put("12", "주|주유소용지");
		cdMap.put("13", "창|창고용지");
		cdMap.put("14", "도|도로");
		cdMap.put("15", "철|철도용지");
		cdMap.put("16", "제|제방");
		cdMap.put("17", "천|하천");
		cdMap.put("18", "구|구거");
		cdMap.put("19", "유|유지");
		cdMap.put("20", "양|양어장");
		cdMap.put("21", "수|수도용지");
		cdMap.put("22", "공|공원");
		cdMap.put("23", "체|체육용지");
		cdMap.put("24", "원|유원지");
		cdMap.put("25", "종|종교용지");
		cdMap.put("26", "사|사적지");
		cdMap.put("27", "묘|묘지");
		cdMap.put("28", "잡|잡종지");
		
		if ( !key.equals("") ) rst = cdMap.get(key).split("\\|")[rIdx];
		return rst;
	}

	/**
	 * 소유구분코드명
	 * @param cd
	 * @return
	 */
	public static String getOwnGbnNm(String cd) {
		
		String rst = "";

		String key = "";
		if ( cd != null ) key = cd;
		
		HashMap<String, String> cdMap = new HashMap<String, String>();
		cdMap.put("00", "일본인,창씨명");
		cdMap.put("01", "개인");
		cdMap.put("02", "국유지");
		cdMap.put("03", "외국인,외국공공기관");
		cdMap.put("04", "시.도유지");
		cdMap.put("05", "군유지");
		cdMap.put("06", "법인");
		cdMap.put("07", "종중");
		cdMap.put("08", "종교단체");
		cdMap.put("09", "기타단체");
		
		if ( !key.equals("") ) rst = cdMap.get(key); 
		return rst;
	}

	
	public static String pnuToJimok(String pnu) {
		return getJimokNm(getJimokCd(pnu));
	}
	
	public static String getJimokCd(String pnu) {
		
		String rst = "";

		String[] pnuArr = PnuUtils.splitArr(pnu);

		StringBuilder query = new StringBuilder();
		DBHandler handler = new DBHandler();
		
		//adm_sec_cd, land_loc_cd, ledg_gbn, bobn, bubn, jimok, parea, owngbn
		query.append("SELECT jimok ")
			.append(" FROM ").append(DEFAULT_SCHEMA).append("land_frst_ledg ")
			.append(" WHERE adm_sec_cd = '").append(pnuArr[0]).append("' ")
			.append(" AND land_loc_cd = '").append(pnuArr[1]).append("' ")
			.append(" AND ledg_gbn = '").append(pnuArr[2]).append("' ")
			.append(" AND bobn = '").append(pnuArr[3]).append("' ")
			.append(" AND bubn = '").append(pnuArr[4]).append("' ")
			.append(" LIMIT 1");
		//System.out.println(query.toString());

		try {
			handler.open(DEFAULT_DB_NODE);

			handler.setQuery(query.toString());
			handler.execute();
			if (handler.next()) {
				rst = StringUtils.trimToEmpty(handler.getString("jimok"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			handler.close();
		}
		
		return rst;
	}

	
	public static String getJibunAddr(String pnu) {
		return getJibunAddr(pnu, false, true);
	}

	public static String getJibunAddr(String pnu, boolean fullAddr, boolean jibun) {
		
		String rst = "";
		if ( fullAddr ) rst = "강원도 ";

		String[] pnuArr = PnuUtils.riSplitArr(pnu);

		StringBuilder query = new StringBuilder();
		DBHandler handler = new DBHandler();
		
		query.append("SELECT sgg.sig_kor_nm, emd.emd_kor_nm, ri.li_kor_nm ")
			.append(" FROM ").append(DEFAULT_SCHEMA).append("lp_adm_sgg AS sgg ")
			.append(" JOIN ").append(DEFAULT_SCHEMA).append("lp_adm_emd AS emd ON sgg.sig_cd = substr(emd.emd_cd, 1, 5) ")
			.append(" LEFT JOIN ").append(DEFAULT_SCHEMA).append("lp_adm_ri AS ri ON emd.emd_cd = substr(ri.li_cd, 1, 8) ");
		if ( pnuArr[2].equals("00") ) {
			query.append(" WHERE emd.emd_cd = '").append(pnuArr[0]).append(pnuArr[1]).append("' ");
		} else {
			query.append(" WHERE ri.li_cd = '").append(pnuArr[0]).append(pnuArr[1]).append(pnuArr[2]).append("' ");
		}
		query.append(" LIMIT 1");
		//System.out.println(query.toString());

		try {
			handler.open(DEFAULT_DB_NODE);

			handler.setQuery(query.toString());
			handler.execute();
			
			if (handler.next()) {
				
				String tmp = "";
				
				tmp = StringUtils.trimToEmpty(handler.getString("sig_kor_nm"));
				rst += ( tmp );
				tmp = StringUtils.trimToEmpty(handler.getString("emd_kor_nm"));
				rst += ( " " + tmp );
				tmp = StringUtils.trimToEmpty(handler.getString("li_kor_nm"));
				if ( !tmp.equals("") ) rst += ( " " + tmp );
				
				if ( jibun ) rst += (" " + getBunjiAddr(pnu)); 
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			handler.close();
		}
		
		return rst;
	}
	
	public static String getBunjiAddr(String pnu) {
		String rst = "";

		String[] pnuArr = PnuUtils.riSplitArr(pnu);

		if ( pnuArr[3].equals("2") ) rst += "산";
		if ( !pnuArr[4].equals("0000") ) rst += ( " " + String.valueOf(Integer.parseInt(pnuArr[4])) );
		if ( !pnuArr[5].equals("0000") ) rst += ( "-" + String.valueOf(Integer.parseInt(pnuArr[5])) );
		
		return rst;
	}
	
	
	public static String getDoroAddr(String pnu) {
		return getDoroAddr(pnu, false);
	}

	public static String getDoroAddr(String pnu, boolean fullAddr) {
		
		String rst = "";
		if ( fullAddr ) rst = "강원도 ";
		
		String[] pnuArr = PnuUtils.riSplitArr(pnu);
		String mntn_yn = "0";
		if ( pnuArr[3].equals("2") ) mntn_yn = "1";

		StringBuilder query = new StringBuilder();
		DBHandler handler = new DBHandler();

		query.append("SELECT sgg.sig_kor_nm, dr.rn, bld.buld_mnnm, bld.buld_slno, emd.emd_kor_nm ")
			.append(" , bld._gid, (POINT(bld._geometry))[0] AS annox, (POINT(bld._geometry))[1] AS annoy, bld._geometry AS _geometry")
			.append(" FROM ").append(DEFAULT_SCHEMA).append("tl_spbd_buld AS bld ")
			.append(" JOIN ").append(DEFAULT_SCHEMA).append("lp_adm_sgg AS sgg ON bld.sig_cd = sgg.sig_cd ")
			.append(" JOIN ").append(DEFAULT_SCHEMA).append("tl_sprd_manage AS dr ON dr.rds_dpn_se = '0' AND bld.sig_cd = dr.sig_cd AND bld.rn_cd = dr.rn_cd ")
			.append(" JOIN ").append(DEFAULT_SCHEMA).append("lp_adm_emd AS emd ON (bld.sig_cd || bld.emd_cd) = emd.emd_cd ")
			.append(" WHERE bld.bul_dpn_se = 'M' AND bld.sig_cd = '").append(pnuArr[0]).append("' ")
			.append(" AND bld.emd_cd = '").append(pnuArr[1]).append("' ")
			.append(" AND bld.li_cd = '").append(pnuArr[2]).append("' ")
			.append(" AND bld.mntn_yn = '").append(mntn_yn).append("' ")
			.append(" AND bld.lnbr_mnnm = ").append(pnuArr[4])
			.append(" AND bld.lnbr_slno = ").append(pnuArr[5]);
		query.append(" LIMIT 1");
		//System.out.println(query.toString());
		
		try {
			handler.open(DEFAULT_DB_NODE);

			handler.setQuery(query.toString());
			handler.execute();
			
			if (handler.next()) {
				
				String tmp = "";
				
				tmp = StringUtils.trimToEmpty(handler.getString("sig_kor_nm"));
				rst += ( tmp );
				tmp = StringUtils.trimToEmpty(handler.getString("rn"));
				rst += ( " " + tmp );
				tmp = StringUtils.trimToEmpty(handler.getString("buld_mnnm"));
				rst += ( " " + tmp );
				tmp = StringUtils.trimToEmpty(handler.getString("buld_slno"));
				if ( !tmp.equals("0") && !tmp.equals("") ) rst += ( "-" + tmp );
				tmp = StringUtils.trimToEmpty(handler.getString("emd_kor_nm"));
				rst += ( " (" + tmp + ")" );

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			handler.close();
		}

		return rst;
	}

	
	public static String getBldgKindNm(String cd) {
		return getBldgKindNm(cd, false);
	}

	public static String getBldgKindNm(String cd, boolean fullNm) {

		String rst = "";
		int rIdx = 0;
		if ( fullNm ) rIdx = 1;

		String key = "";
		if ( cd != null ) key = cd;
		
		HashMap<String, String> cdMap = new HashMap<String, String>();
		cdMap.put("1", "총괄표제부|건축물대장(총괄표제부)");
		cdMap.put("2", "일반건축물|일반건축물");
		cdMap.put("3", "표제부|집합건축물(표제부)");
		cdMap.put("4", "전유부|집합건축물(전유부)");
		
		if ( !key.equals("") ) rst = cdMap.get(key).split("\\|")[rIdx];
		return rst;
		
	}
}
