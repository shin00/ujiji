package geomex.kras.common;

import geomex.kras.common.vo.Col;

import java.text.DecimalFormat;


public class ColUtils {

	/**
	 * 날짜 formatting
	 * @param date
	 * @return
	 */
    public static String formatDate(String date) {
    	
    	String tmp = "";
    	
    	if ( date.indexOf("-") > -1 ) {
    		tmp = date;
    	} else {
        	int dateLen = date.length();
        	StringBuilder rtn = new StringBuilder(19);
        	
        	if ( dateLen > 0 ) rtn.append(date.substring(0, 4));
        	if ( dateLen > 4 ) rtn.append("-").append(date.substring(4, 6));
        	if ( dateLen > 6 ) rtn.append("-").append(date.substring(6, 8));
        	if ( dateLen > 8 ) rtn.append(" ").append(date.substring(8, 10));
        	if ( dateLen > 10 ) rtn.append(":").append(date.substring(10, 12));
        	if ( dateLen > 12 ) rtn.append(":").append(date.substring(12, 14));

        	tmp = rtn.toString();
    	}
    	
        return tmp;
    }

    public static String formatDate(Col date) {
    	return formatDate(date.getVal());
    }
    
    /**
     * 숫자 formatting
     * @param val
     * @return
     */
    public static String formatNumber(String val) {
    	
    	String tmp = val.replace(",", "");
    	if ( tmp.equals("") ) tmp = "0";
    	
    	int posPoint = tmp.lastIndexOf("."); 
    	String vi = tmp;
    	String vd = "";
    	
    	String fmtStr = "###,###,###,###";

    	if ( posPoint > -1 ) {
    		vi = tmp.substring(0, posPoint).replace(".",  "");
    		vi += ".";
    		vd = tmp.substring(posPoint+1, tmp.length());

    		fmtStr += ".";
    		for ( int i = 0; i < vd.length(); i++ ) fmtStr += "0"; 
    	}
    	DecimalFormat format = new DecimalFormat(fmtStr);
        return format.format(Double.parseDouble(vi+vd));
    }

    public static String formatNumber(Col val) {
    	return formatNumber(val.getVal());
    }

}
