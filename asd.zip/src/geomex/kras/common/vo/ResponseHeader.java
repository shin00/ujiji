package geomex.kras.common.vo;

import geomex.kras.vo.LandBldgCheck;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
* <PRE>
* 파일명   : ResponseHeader.java
* 파일설명 : 
* 수정이력 : 
*       2015. 6. 17.  이규하  : 최초작성
* </PRE>
*/
@XmlRootElement(name = "HEADER")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {"code", "message"})
public class ResponseHeader {

	@XmlElement(name = "CODE")
	private String code;
	@XmlElement(name = "MESSAGE")
	private String message;

	public ResponseHeader() {
	}

	public ResponseHeader(ResponseHeader header) {
		this.setCode(header.getCode());
		this.setMessage(header.getMessage());
	}

	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this, false);
	}

	@Override
	public boolean equals(Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj, false);
	}
}
