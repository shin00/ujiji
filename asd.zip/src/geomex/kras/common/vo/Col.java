package geomex.kras.common.vo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlValue;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
* <PRE>
* 파일명   : Col.java
* 파일설명 : 
* 수정이력 : 
*       2014. 5. 26.  이규하  : 최초작성
*       2014. 7. 28.  이규하  : 컬럼명과 값으로 생성가능하도록 수정
* </PRE>
*/
@XmlAccessorType(XmlAccessType.FIELD)
public class Col {

	@XmlTransient
	public static final boolean PK = true; 
	
	@XmlAttribute
	private String name;
	@XmlAttribute
	private String desc = "";
	@XmlAttribute
	private String type = "";
	@XmlAttribute
	private String size;
	@XmlAttribute
	private String relcode;
	@XmlAttribute
	private String ispk;
	@XmlValue
	private String val;

	
	public Col() {
		setName(null);
		setDesc(null);
		setType(null);
	}

	public Col(String val) {
		setVal(val);
	}

	public Col(String name, String val) {
		//setName(name);
		setVal(val);
	}

	public Col(String name, String desc, String type) {
		//setName(name);
		setDesc(desc);
		setType(type);
	}

	public Col(String name, String desc, String type, String size) {
		//setName(name);
		setDesc(desc);
		setType(type);
		setSize(size);
	}

	public Col(String name, String desc, String type, String size, String relcode) {
		//setName(name);
		setDesc(desc);
		setType(type);
		setSize(size);
		setRelcode(relcode);
	}

	public Col(String name, String desc, String type, String size, boolean ispk) {
		//setName(name);
		setDesc(desc);
		setType(type);
		setSize(size);
		setIspk(ispk);
	}

	public Col(String name, String desc, String type, String size, String relcode, boolean ispk) {
		//setName(name);
		setDesc(desc);
		setType(type);
		setSize(size);
		setRelcode(relcode);
		setIspk(ispk);
	}

	
	public String getName() {
		return name;
	}
	private void setName(String name) {
		this.name = name;
	}
	
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	public String getType() {
		return type;
	}
	private void setType(String type) {
		this.type = type;
	}
	
	public String getSize() {
		return size;
	}
	private void setSize(String size) {
		this.size = size;
	}
	
	public String getRelcode() {
		return relcode;
	}
	private void setRelcode(String relcode) {
		this.relcode = relcode;
	}

	public String getIspk() {
		return ispk;
	}
	public Col setIspk(boolean ispkB) {
		String ispk = null;
		if ( ispkB ) ispk = "1";
		this.ispk = ispk;
		return this;
	}
	public Col setIspk() {
		setIspk(true);
		return this;
	}
	public boolean isKey() {
		return (ispk != null) ? true : false;
	}

	public String getVal() {
		return StringUtils.trimToEmpty(val);
	}
	public Col setVal(String val) {
		this.val = val;
		return this;
	}
	public Col setOnlyVal(String val) {
		setVal(val);
		
		return toOnlyVal();
	}
	public Col toOnlyVal() {
		setDesc(null);
		setType(null);
		setSize(null);
		setRelcode(null);
		setIspk(false);

		return this;
	}


	public String toString(boolean debug) {
		String rst = getVal();
		if ( debug ) rst = ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
		return rst;
	}

	@Override
	public String toString() {
		//return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
		return toString(false);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this, false);
	}

	@Override
	public boolean equals(Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj, false);
	}

}
