package geomex.kras.common;

/**
* <PRE>
* 파일명   : Validation.java
* 파일설명 : 
* 수정이력 : 
*       2014. 6. 2.  이규하  : 최초작성
* </PRE>
*/
public class Validation {

	/**
	 * 숫자가 허용자릿수안에 있는지 체크 
	 * @param val
	 *          입력값
	 * @param len
	 *          허용자릿수
	 * @return boolean
	 */
	public static boolean numChk(String val, String len) {
		boolean chkBool = true;
		int iLen = 0;
		int fLen = 0;
		String[] lenArr = len.split(",");
		String[] valArr = val.split("\\.");
		iLen = Math.abs(Integer.parseInt(lenArr[0]));
		if ( lenArr.length > 1 ) {
			fLen = Integer.parseInt(lenArr[1]);
			iLen -= fLen;
		}
		if ( valArr[0].length() > iLen ) chkBool = false; 
		if ( valArr.length > 1 ) {
			if ( valArr[1].length() > fLen ) chkBool = false; 
		}

    	return chkBool;
	}
	
}
