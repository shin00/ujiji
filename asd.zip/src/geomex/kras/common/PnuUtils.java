package geomex.kras.common;

import org.apache.commons.lang3.StringUtils;

public class PnuUtils {

	
	public static String[] splitArr(String pnu) {
		String[] rst = {"00000", "00000", "1", "0000", "0000"};
		
		int pnuLen = pnu.length();
		
		if ( pnuLen >= 5 ) rst[0] = pnu.substring(0, 5);
		if ( pnuLen >= 10 ) rst[1] = pnu.substring(5, 10);
		if ( pnuLen >= 11 ) rst[2] = pnu.substring(10, 11);
		if ( pnuLen >= 15 ) rst[3] = pnu.substring(11, 15);
		if ( pnuLen >= 19 ) rst[4] = pnu.substring(15, 19);
		
		return rst;
	}

	public static String[] riSplitArr(String pnu) {
		String[] rst = {"00000", "000", "00", "1", "0000", "0000"};
		
		int pnuLen = pnu.length();

		if ( pnuLen >= 5 ) rst[0] = pnu.substring(0, 5);
		if ( pnuLen >= 8 ) rst[1] = pnu.substring(5, 8);
		if ( pnuLen >= 10 ) rst[2] = pnu.substring(8, 10);
		if ( pnuLen >= 11 ) rst[3] = pnu.substring(10, 11);
		if ( pnuLen >= 15 ) rst[4] = pnu.substring(11, 15);
		if ( pnuLen >= 19 ) rst[5] = pnu.substring(15, 19);
		
		return rst;
	}

	public static String genSerial(String pnu) {
		String rst = "";
		rst = StringUtils.join(splitSerialArr(pnu), "-");
		return rst;
	}

	public static String genLandSerial(String pnu) {
		String rst = "";
		String[] tmp = splitArr(pnu);
		String[] landSerialArr = {"0000000000", "10000", "0000"};
		
		landSerialArr[0] = tmp[0] + tmp[1];
		landSerialArr[1] = tmp[2] + tmp[3];
		landSerialArr[2] = tmp[4];
		rst = StringUtils.join(landSerialArr, "-");
		return rst;
	}

	public static String genBldgSerial(String pnu, String bldgGbn) {
		String rst = "";
		String[] bldgSerialArr = splitSerialArr(pnu);
		
		String miNum = bldgSerialArr[1];

		if ( "3".equals(bldgGbn) ) {
			miNum = "3";
			if ( bldgSerialArr[1].equals("2") ) miNum = "4";
		}
		
		bldgSerialArr[1] = miNum;
		rst = StringUtils.join(bldgSerialArr, "-");
		return rst;
	}
	
	public static String toJibunString(String pnu) {
		String rst = "";
		
		String[] pnuArr = splitArr(pnu);
		if ( !pnuArr[2].equals("1") ) rst += ( Code.getTojiNm(pnuArr[2]) + " " );
		rst += ( String.valueOf( Integer.parseInt(pnuArr[3]) ) );
		if ( !pnuArr[4].equals("0000") ) rst += ( "-" + String.valueOf( Integer.parseInt(pnuArr[4]) ) );
		
		return rst;
	}

	
	private static String[] splitSerialArr(String pnu) {
		
		String[] rst = {"0000000000", "1", "00000000"};
		
		int pnuLen = pnu.length();

		if ( pnuLen >= 10 ) rst[0] = pnu.substring(0, 10);
		if ( pnuLen >= 11 ) rst[1] = pnu.substring(10, 11);
		if ( pnuLen >= 19 ) rst[2] = pnu.substring(11, 19);
		
		return rst;
	}
}
