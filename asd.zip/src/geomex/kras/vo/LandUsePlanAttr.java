package geomex.kras.vo;

import geomex.kras.common.vo.Col;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;


@XmlRootElement(name = "LAND_USE_PLAN_CNF_ATTR")
@XmlAccessorType(XmlAccessType.FIELD)
public class LandUsePlanAttr {

	@XmlElement(name = "UCODE")
	private Col ucode = new Col("UCODE", "용도지역지구 코드", "S");
	@XmlElement(name = "DIVNO")
	private Col divno = new Col("DIVNO", "용도지역코드 번호", "S");
	@XmlElement(name = "GUBUN")
	private Col gubun = new Col("GUBUN", "용도지역지구 형태", "S");
	@XmlElement(name = "CTYPE")
	private Col ctype = new Col("CTYPE", "저촉여부", "S");
	@XmlElement(name = "UNM")
	private Col unm = new Col("UNM", "용도지역지구 명", "S");
	@XmlElement(name = "SEQ")
	private Col seq = new Col("SEQ", "일련번호", "N");
	@XmlElement(name = "LAWNM")
	private Col lawnm = new Col("LAWNM", "법률명", "S");
	@XmlElement(name = "UNAME")
	private Col uname = new Col("UNAME", "용도지역지구 명", "S");
	
	
	public LandUsePlanAttr() {
	}

	public LandUsePlanAttr(LandUsePlanAttr landUsePlanAttr) {
		this.ucode.setVal(landUsePlanAttr.ucode.getVal());
		this.divno.setVal(landUsePlanAttr.divno.getVal());
		this.gubun.setVal(landUsePlanAttr.gubun.getVal());
		this.ctype.setVal(landUsePlanAttr.ctype.getVal());
		this.unm.setVal(landUsePlanAttr.unm.getVal());
		this.seq.setVal(landUsePlanAttr.seq.getVal());
		this.lawnm.setVal(landUsePlanAttr.lawnm.getVal());
		this.uname.setVal(landUsePlanAttr.uname.getVal());
	}
	

	public Col getUcode() {
		return ucode;
	}
	public void setUcode(Col ucode) {
		this.ucode.setOnlyVal(ucode.getVal());
	}
	public Col getDivno() {
		return divno;
	}
	public void setDivno(Col divno) {
		this.divno = divno;
	}
	public Col getGubun() {
		return gubun;
	}
	public void setGubun(Col gubun) {
		this.gubun.setOnlyVal(gubun.getVal());
	}
	public Col getCtype() {
		return ctype;
	}
	public void setCtype(Col ctype) {
		this.ctype.setOnlyVal(ctype.getVal());
	}
	public Col getUnm() {
		return unm;
	}
	public void setUnm(Col unm) {
		this.unm.setOnlyVal(unm.getVal());
	}
	public Col getSeq() {
		return seq;
	}
	public void setSeq(Col seq) {
		this.seq.setOnlyVal(seq.getVal());
	}
	public Col getLawnm() {
		return lawnm;
	}
	public void setLawnm(Col lawnm) {
		this.lawnm.setOnlyVal(lawnm.getVal());
	}
	public Col getUname() {
		return uname;
	}
	public void setUname(Col uname) {
		this.uname.setOnlyVal(uname.getVal());
	}

	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this, false);
	}

	@Override
	public boolean equals(Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj, false);
	}
}
