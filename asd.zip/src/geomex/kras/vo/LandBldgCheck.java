package geomex.kras.vo;

import geomex.kras.common.vo.Col;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;


@XmlRootElement(name = "LAND_BLDG_CHECK")
@XmlAccessorType(XmlAccessType.FIELD)
public class LandBldgCheck {

	@XmlElement(name = "REAL_GBN")
	private Col realGbn = new Col("REAL_GBN", "토지_건물_구분", "S");
	@XmlElement(name = "ADM_SECT_CD")
	private Col admSectCd = new Col("ADM_SECT_CD", "행정구역코드", "S");
	@XmlElement(name = "LAND_LOC_CD")
	private Col landLocCd = new Col("LAND_LOC_CD", "소재지코드", "S");
	@XmlElement(name = "LEDG_GBN")
	private Col ledgGbn = new Col("LEDG_GBN", "대장구분", "S");
	@XmlElement(name = "BOBN")
	private Col bobn = new Col("BOBN", "본번", "S");
	@XmlElement(name = "BUBN")
	private Col bubn = new Col("BUBN", "부번", "S");
	@XmlElement(name = "ADM_SECT_NM")
	private Col admSectNm = new Col("ADM_SECT_NM", "행정구역명", "S");
	@XmlElement(name = "SECT_LOC_NM")
	private Col sectLocNm = new Col("SECT_LOC_NM", "소재지명", "S");
	@XmlElement(name = "MAP_GBN")
	private Col mapGbn = new Col("MAP_GBN", "지적도 구분", "S");
	
	
	public LandBldgCheck() {
	}

	public LandBldgCheck(LandBldgCheck landBldgCheck) {
		this.realGbn.setVal(landBldgCheck.realGbn.getVal());
		this.admSectCd.setVal(landBldgCheck.admSectCd.getVal());
		this.landLocCd.setVal(landBldgCheck.landLocCd.getVal());
		this.ledgGbn.setVal(landBldgCheck.ledgGbn.getVal());
		this.bobn.setVal(landBldgCheck.bobn.getVal());
		this.bubn.setVal(landBldgCheck.bubn.getVal());
		this.admSectNm.setVal(landBldgCheck.admSectNm.getVal());
		this.sectLocNm.setVal(landBldgCheck.sectLocNm.getVal());
		this.mapGbn.setVal(landBldgCheck.mapGbn.getVal());
	}
	

	public Col getRealGbn() {
		return realGbn;
	}
	public void setRealGbn(Col realGbn) {
		this.realGbn.setOnlyVal(realGbn.getVal());
	}
	public Col getAdmSectCd() {
		return admSectCd;
	}
	public void setAdmSectCd(Col admSectCd) {
		this.admSectCd.setOnlyVal(admSectCd.getVal());
	}
	public Col getLandLocCd() {
		return landLocCd;
	}
	public void setLandLocCd(Col landLocCd) {
		this.landLocCd.setOnlyVal(landLocCd.getVal());
	}
	public Col getLedgGbn() {
		return ledgGbn;
	}
	public void setLedgGbn(Col ledgGbn) {
		this.ledgGbn.setOnlyVal(ledgGbn.getVal());
	}
	public Col getBobn() {
		return bobn;
	}
	public void setBobn(Col bobn) {
		this.bobn.setOnlyVal(bobn.getVal());
	}
	public Col getBubn() {
		return bubn;
	}
	public void setBubn(Col bubn) {
		this.bubn.setOnlyVal(bubn.getVal());
	}
	public Col getAdmSectNm() {
		return admSectNm;
	}
	public void setAdmSectNm(Col admSectNm) {
		this.admSectNm.setOnlyVal(admSectNm.getVal());
	}
	public Col getSectLocNm() {
		return sectLocNm;
	}
	public void setSectLocNm(Col sectLocNm) {
		this.sectLocNm.setOnlyVal(sectLocNm.getVal());
	}
	public Col getMapGbn() {
		return mapGbn;
	}
	public void setMapGbn(Col mapGbn) {
		this.mapGbn.setOnlyVal(mapGbn.getVal());
	}

	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this, false);
	}

	@Override
	public boolean equals(Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj, false);
	}
}
