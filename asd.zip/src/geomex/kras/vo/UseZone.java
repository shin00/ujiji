package geomex.kras.vo;

import geomex.kras.common.vo.Col;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;


@XmlRootElement(name = "USE_ZONE")
@XmlAccessorType(XmlAccessType.FIELD)
public class UseZone {

	@XmlElement(name = "USE_ZONE_ZONE_CD")
	private Col useZoneZoneCd = new Col("USE_ZONE_ZONE_CD", "용도지역지구 코드", "S");
	@XmlElement(name = "USE_ZONE_ZONE_CD_NM")
	private Col useZoneZoneCdNm = new Col("USE_ZONE_ZONE_CD_NM", "용도지역지구명", "S");
	@XmlElement(name = "CFLT_YN")
	private Col cfltYn = new Col("CFLT_YN", "", "S");
	@XmlElement(name = "ADM_SECT_CD")
	private Col admSectCd = new Col("ADM_SECT_CD", "행정구역코드", "S");
	@XmlElement(name = "LAND_LOC_CD")
	private Col landLocCd = new Col("LAND_LOC_CD", "소재지코드", "S");
	@XmlElement(name = "LEDG_GBN")
	private Col ledgGbn = new Col("LEDG_GBN", "대장구분", "S");
	@XmlElement(name = "BOBN")
	private Col bobn = new Col("BOBN", "본번", "S");
	@XmlElement(name = "BUBN")
	private Col bubn = new Col("BUBN", "부번", "S");
	
	
	public UseZone() {
	}

	public UseZone(UseZone useZone) {
		this.useZoneZoneCd.setVal(useZone.useZoneZoneCd.getVal());
		this.useZoneZoneCdNm.setVal(useZone.useZoneZoneCdNm.getVal());
		this.cfltYn.setVal(useZone.cfltYn.getVal());
		this.admSectCd.setVal(useZone.admSectCd.getVal());
		this.landLocCd.setVal(useZone.landLocCd.getVal());
		this.ledgGbn.setVal(useZone.ledgGbn.getVal());
		this.bobn.setVal(useZone.bobn.getVal());
		this.bubn.setVal(useZone.bubn.getVal());
	}
	

	public Col getUseZoneZoneCd() {
		return useZoneZoneCd;
	}
	public void setUseZoneZoneCd(Col useZoneZoneCd) {
		this.useZoneZoneCd.setOnlyVal(useZoneZoneCd.getVal());
	}
	public Col getUseZoneZoneCdNm() {
		return useZoneZoneCdNm;
	}
	public void setUseZoneZoneCdNm(Col useZoneZoneCdNm) {
		this.useZoneZoneCdNm.setOnlyVal(useZoneZoneCdNm.getVal());
	}
	public Col getCfltYn() {
		return cfltYn;
	}
	public void setCfltYn(Col cfltYn) {
		this.cfltYn.setOnlyVal(cfltYn.getVal());
	}
	public Col getAdmSectCd() {
		return admSectCd;
	}
	public void setAdmSectCd(Col admSectCd) {
		this.admSectCd.setOnlyVal(admSectCd.getVal());
	}
	public Col getLandLocCd() {
		return landLocCd;
	}
	public void setLandLocCd(Col landLocCd) {
		this.landLocCd.setOnlyVal(landLocCd.getVal());
	}
	public Col getLedgGbn() {
		return ledgGbn;
	}
	public void setLedgGbn(Col ledgGbn) {
		this.ledgGbn.setOnlyVal(ledgGbn.getVal());
	}
	public Col getBobn() {
		return bobn;
	}
	public void setBobn(Col bobn) {
		this.bobn.setOnlyVal(bobn.getVal());
	}
	public Col getBubn() {
		return bubn;
	}
	public void setBubn(Col bubn) {
		this.bubn.setOnlyVal(bubn.getVal());
	}

	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this, false);
	}

	@Override
	public boolean equals(Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj, false);
	}
}
