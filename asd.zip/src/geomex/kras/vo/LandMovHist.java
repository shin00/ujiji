package geomex.kras.vo;

import geomex.kras.common.vo.Col;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;


@XmlRootElement(name = "LAND_MOV_HIST")
@XmlAccessorType(XmlAccessType.FIELD)
public class LandMovHist {

	@XmlElement(name = "JIMOK")
	private Col jimok = new Col("JIMOK", "지목", "S");
	@XmlElement(name = "LAND_MOV_RSN_CD")
	private Col landMovRsnCd = new Col("LAND_MOV_RSN_CD", "토지이동사유코드", "S");
	@XmlElement(name = "SCALE")
	private Col scale = new Col("SCALE", "스케일", "S");
	@XmlElement(name = "OWN_GBN")
	private Col ownGbn = new Col("OWN_GBN", "소유구분", "S");
	@XmlElement(name = "SHR_CNT")
	private Col shrCnt = new Col("SHR_CNT", "공유인수", "N");
	@XmlElement(name = "OWNER_ADDR")
	private Col ownerAddr = new Col("OWNER_ADDR", "소유자주소", "S");
	@XmlElement(name = "OWNER_NM")
	private Col ownerNm = new Col("OWNER_NM", "소유자명", "S");
	@XmlElement(name = "SCALE_NM")
	private Col scaleNm = new Col("SCALE_NM", "스케일명", "S");
	@XmlElement(name = "DOHO")
	private Col doho = new Col("DOHO", "도호", "S");
	@XmlElement(name = "DEL_YMD")
	private Col delYmd = new Col("DEL_YMD", "말소일자", "S");
	@XmlElement(name = "LAND_MOV_DEL_YMD")
	private Col landMovDelYmd = new Col("LAND_MOV_DEL_YMD", "토지이동말소일자", "S");
	@XmlElement(name = "LAND_MOV_HIST_ODRNO")
	private Col landMovHistOdrno = new Col("LAND_MOV_HIST_ODRNO", "토지이동연혁순번", "N");
	@XmlElement(name = "LAND_HIST_ODRNO")
	private Col landHistOdrno = new Col("LAND_HIST_ODRNO", "연혁순번", "S");
	@XmlElement(name = "JIMOK_NM")
	private Col jimokNm = new Col("JIMOK_NM", "지목명", "S");
	@XmlElement(name = "PAREA")
	private Col parea = new Col("PAREA", "면적", "N");
	@XmlElement(name = "DYMD")
	private Col dymd = new Col("DYMD", "이동일자", "S");
	@XmlElement(name = "LAND_MOV_RSN_CD_NM")
	private Col landMovRsnCdNm = new Col("LAND_MOV_RSN_CD_NM", "토지이동사유명", "S");
	@XmlElement(name = "LAND_MOV_CHRG_MAN_ID")
	private Col landMovChrgManId = new Col("LAND_MOV_CHRG_MAN_ID", "처리담당자", "S");

	@XmlElementWrapper(name = "RELJIBUN")
	@XmlElement(name = "JIBUN")
	private ArrayList<Col> jibun; // new Col("JIBUN", "관련지번", "S");
	
	
	public LandMovHist() {
	}

	public LandMovHist(LandMovHist landMovHist) {
		this.jimok.setVal(landMovHist.jimok.getVal());
		this.landMovRsnCd.setVal(landMovHist.landMovRsnCd.getVal());
		this.scale.setVal(landMovHist.scale.getVal());
		this.ownGbn.setVal(landMovHist.ownGbn.getVal());
		this.shrCnt.setVal(landMovHist.shrCnt.getVal());
		this.ownerAddr.setVal(landMovHist.ownerAddr.getVal());
		this.ownerNm.setVal(landMovHist.ownerNm.getVal());
		this.scaleNm.setVal(landMovHist.scaleNm.getVal());
		this.doho.setVal(landMovHist.doho.getVal());
		this.delYmd.setVal(landMovHist.delYmd.getVal());
		this.landMovDelYmd.setVal(landMovHist.landMovDelYmd.getVal());
		this.landMovHistOdrno.setVal(landMovHist.landMovHistOdrno.getVal());
		this.landHistOdrno.setVal(landMovHist.landHistOdrno.getVal());
		this.jimokNm.setVal(landMovHist.jimokNm.getVal());
		this.parea.setVal(landMovHist.parea.getVal());
		this.dymd.setVal(landMovHist.dymd.getVal());
		this.landMovRsnCdNm.setVal(landMovHist.landMovRsnCdNm.getVal());
		this.landMovChrgManId.setVal(landMovHist.landMovChrgManId.getVal());
		
		this.jibun = landMovHist.jibun;
	}
	

	public Col getJimok() {
		return jimok;
	}
	public void setJimok(Col jimok) {
		this.jimok.setOnlyVal(jimok.getVal());
	}
	public Col getLandMovRsnCd() {
		return landMovRsnCd;
	}
	public void setLandMovRsnCd(Col landMovRsnCd) {
		this.landMovRsnCd.setOnlyVal(landMovRsnCd.getVal());
	}
	public Col getScale() {
		return scale;
	}
	public void setScale(Col scale) {
		this.scale.setOnlyVal(scale.getVal());
	}
	public Col getOwnGbn() {
		return ownGbn;
	}
	public void setOwnGbn(Col ownGbn) {
		this.ownGbn.setOnlyVal(ownGbn.getVal());
	}
	public Col getShrCnt() {
		return shrCnt;
	}
	public void setShrCnt(Col shrCnt) {
		this.shrCnt.setOnlyVal(shrCnt.getVal());
	}
	public Col getOwnerAddr() {
		return ownerAddr;
	}
	public void setOwnerAddr(Col ownerAddr) {
		this.ownerAddr.setOnlyVal(ownerAddr.getVal());
	}
	public Col getOwnerNm() {
		return ownerNm;
	}
	public void setOwnerNm(Col ownerNm) {
		this.ownerNm.setOnlyVal(ownerNm.getVal());
	}
	public Col getScaleNm() {
		return scaleNm;
	}
	public void setScaleNm(Col scaleNm) {
		this.scaleNm.setOnlyVal(scaleNm.getVal());
	}
	public Col getDoho() {
		return doho;
	}
	public void setDoho(Col doho) {
		this.doho.setOnlyVal(doho.getVal());
	}
	public Col getDelYmd() {
		return delYmd;
	}
	public void setDelYmd(Col delYmd) {
		this.delYmd.setOnlyVal(delYmd.getVal());
	}
	public Col getLandMovDelYmd() {
		return landMovDelYmd;
	}
	public void setLandMovDelYmd(Col landMovDelYmd) {
		this.landMovDelYmd.setOnlyVal(landMovDelYmd.getVal());
	}
	public Col getLandMovHistOdrno() {
		return landMovHistOdrno;
	}
	public void setLandMovHistOdrno(Col landMovHistOdrno) {
		this.landMovHistOdrno.setOnlyVal(landMovHistOdrno.getVal());
	}
	public Col getLandHistOdrno() {
		return landHistOdrno;
	}
	public void setLandHistOdrno(Col landHistOdrno) {
		this.landHistOdrno.setOnlyVal(landHistOdrno.getVal());
	}
	public Col getJimokNm() {
		return jimokNm;
	}
	public void setJimokNm(Col jimokNm) {
		this.jimokNm.setOnlyVal(jimokNm.getVal());
	}
	public Col getParea() {
		return parea;
	}
	public void setParea(Col parea) {
		this.parea.setOnlyVal(parea.getVal());
	}
	public Col getDymd() {
		return dymd;
	}
	public void setDymd(Col dymd) {
		this.dymd.setOnlyVal(dymd.getVal());
	}
	public Col getLandMovRsnCdNm() {
		return landMovRsnCdNm;
	}
	public void setLandMovRsnCdNm(Col landMovRsnCdNm) {
		this.landMovRsnCdNm.setOnlyVal(landMovRsnCdNm.getVal());
	}
	public Col getLandMovChrgManId() {
		return landMovChrgManId;
	}
	public void setLandMovChrgManId(Col landMovChrgManId) {
		this.landMovChrgManId.setOnlyVal(landMovChrgManId.getVal());
	}
	
	public ArrayList<Col> getJibun() {
		return jibun;
	}
	public void setJibun(ArrayList<Col> jibun) {
		this.jibun = jibun;
	}

	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this, false);
	}

	@Override
	public boolean equals(Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj, false);
	}
}
