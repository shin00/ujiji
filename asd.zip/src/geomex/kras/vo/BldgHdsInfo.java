package geomex.kras.vo;

import geomex.kras.common.vo.Col;
import geomex.utils.SensInfoUtils;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;


@XmlRootElement(name = "BLDG_HDS_INFO")
@XmlAccessorType(XmlAccessType.FIELD)
public class BldgHdsInfo {

	@XmlElement(name = "BLDG_GBN_NO")
	private Col bldgGbnNo = new Col("BLDG_GBN_NO", "건물식별번호", "N");
	@XmlElement(name = "SPC_NM")
	private Col spcNm = new Col("SPC_NM", "특수지명", "S");
	@XmlElement(name = "BLOCK")
	private Col block = new Col("BLOCK", "블록", "S");
	@XmlElement(name = "LOT")
	private Col lot = new Col("LOT", "로트", "S");
	@XmlElement(name = "BLDG_NM")
	private Col bldgNm = new Col("BLDG_NM", "건물명", "S");
	@XmlElement(name = "CMPL_GBN")
	private Col cmplGbn = new Col("CMPL_GBN", "보완구분", "S");
	@XmlElement(name = "LEGA_YN")
	private Col legaYn = new Col("LEGA_YN", "양성화여부", "S");
	@XmlElement(name = "VIO_BLDG_YN")
	private Col vioBldgYn = new Col("VIO_BLDG_YN", "위반건축물여부", "S");
	@XmlElement(name = "LAND_CNT")
	private Col landCnt = new Col("LAND_CNT", "외필지수", "N");
	@XmlElement(name = "ETC_WRT_ITEM")
	private Col etcWrtItem = new Col("ETC_WRT_ITEM", "기타기재사항", "S");
	@XmlElement(name = "DONG")
	private Col dong = new Col("DONG", "동", "S");
	@XmlElement(name = "MAIN_SUB_GBN_NM")
	private Col mainSubGbnNm = new Col("MAIN_SUB_GBN_NM", "주부속구분명", "S");
	@XmlElement(name = "MAIN_SUB_SEQNO")
	private Col mainSubSeqno = new Col("MAIN_SUB_SEQNO", "주부속일련번호", "S");
	@XmlElement(name = "STRU_NM")
	private Col struNm = new Col("STRU_NM", "구조명", "S");
	@XmlElement(name = "ETC_STRU")
	private Col etcStru = new Col("ETC_STRU", "기타구조", "S");
	@XmlElement(name = "ROOF_NM")
	private Col roofNm = new Col("ROOF_NM", "지붕명", "S");
	@XmlElement(name = "ETC_ROOF")
	private Col etcRoof = new Col("ETC_ROOF", "기타지붕", "S");
	@XmlElement(name = "LAREA")
	private Col larea = new Col("LAREA", "대지면적", "N");
	@XmlElement(name = "FMLY_CNT")
	private Col fmlyCnt = new Col("FMLY_CNT", "가구수", "N");
	@XmlElement(name = "HEHD_CNT")
	private Col hehdCnt = new Col("HEHD_CNT", "세대수", "N");
	@XmlElement(name = "HO_CNT")
	private Col hoCnt = new Col("HO_CNT", "호수", "N");
	@XmlElement(name = "BAREA")
	private Col barea = new Col("BAREA", "건축면적", "N");
	@XmlElement(name = "MAIN_USE_NM")
	private Col mainUseNm = new Col("MAIN_USE_NM", "주용도명", "S");
	@XmlElement(name = "ETC_USE")
	private Col etcUse = new Col("ETC_USE", "기타용도", "S");
	@XmlElement(name = "GAREA")
	private Col garea = new Col("GAREA", "연면적", "N");
	@XmlElement(name = "TOT_DONG_GAREA")
	private Col totDongGarea = new Col("TOT_DONG_GAREA", "총괄동연면적", "N");
	@XmlElement(name = "DONG_BLR")
	private Col dongBlr = new Col("DONG_BLR", "동건폐율", "N");
	@XmlElement(name = "FSI_CALC_GAREA")
	private Col fsiCalcGarea = new Col("FSI_CALC_GAREA", "용적율산정연면적", "N");
	@XmlElement(name = "FSI")
	private Col fsi = new Col("FSI", "용적율", "N");
	@XmlElement(name = "HGT")
	private Col hgt = new Col("HGT", "높이", "N");
	@XmlElement(name = "SUB_BLDG_CNT")
	private Col subBldgCnt = new Col("SUB_BLDG_CNT", "총부속건축물수", "N");
	@XmlElement(name = "SUB_BLDG_AREA")
	private Col subBldgArea = new Col("SUB_BLDG_AREA", "총부속건축물면적", "N");
	@XmlElement(name = "BLDG_KIND_CD")
	private Col bldgKindCd = new Col("BLDG_KIND_CD", "건물종류코드", "S");

	@XmlElement(name = "RELATIONJIBUNSLIST")
	private ArrayList<RelationJibunsList> relationJibunsList;

	@XmlElement(name = "FLOORINFOLIST")
	private ArrayList<FloorInfoList> floorInfoList;

	@XmlElement(name = "CHGDATALIST")
	private ArrayList<ChgDataList> chgDataList;

	@XmlElement(name = "USERINFOLIST")
	private ArrayList<UserInfoList> userInfoList;

	
	@XmlAccessorType(XmlAccessType.FIELD)
	public static class RelationJibunsList {
		
		@XmlElement(name = "REL_LAND_LOC_CD")
		private Col relLandLocCd = new Col("REL_LAND_LOC_CD", "관련소재지코드", "S");
		@XmlElement(name = "REL_BOBN")
		private Col relBobn = new Col("REL_BOBN", "관련본번", "S");
		@XmlElement(name = "REL_BUBN")
		private Col relBubn = new Col("REL_BUBN", "관련부번", "S");
		@XmlElement(name = "SPC_NM")
		private Col spcNm = new Col("SPC_NM", "특수지명", "S");
		@XmlElement(name = "ETC_JIBN_NM")
		private Col etcJibnNm = new Col("ETC_JIBN_NM", "기타지번명", "S");
		
		
		public RelationJibunsList() {
		}
		
		public RelationJibunsList(RelationJibunsList relationJibunsList) {
			this.relLandLocCd.setVal(relationJibunsList.relLandLocCd.getVal());
			this.relBobn.setVal(relationJibunsList.relBobn.getVal());
			this.relBubn.setVal(relationJibunsList.relBubn.getVal());
			this.spcNm.setVal(relationJibunsList.spcNm.getVal());
			this.etcJibnNm.setVal(relationJibunsList.etcJibnNm.getVal());
		}
		
		
		public Col getRelLandLocCd() {
			return relLandLocCd;
		}
		public void setRelLandLocCd(Col relLandLocCd) {
			this.relLandLocCd.setOnlyVal(relLandLocCd.getVal());
		}
		public Col getRelBobn() {
			return relBobn;
		}
		public void setRelBobn(Col relBobn) {
			this.relBobn.setOnlyVal(relBobn.getVal());
		}
		public Col getRelBubn() {
			return relBubn;
		}
		public void setRelBubn(Col relBubn) {
			this.relBubn.setOnlyVal(relBubn.getVal());
		}
		public Col getSpcNm() {
			return spcNm;
		}
		public void setSpcNm(Col spcNm) {
			this.spcNm.setOnlyVal(spcNm.getVal());
		}
		public Col getEtcJibnNm() {
			return etcJibnNm;
		}
		public void setEtcJibnNm(Col etcJibnNm) {
			this.etcJibnNm.setOnlyVal(etcJibnNm.getVal());
		}

	
		@Override
		public String toString() {
			return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
		}

		@Override
		public int hashCode() {
			return HashCodeBuilder.reflectionHashCode(this, false);
		}

		@Override
		public boolean equals(Object obj) {
			return EqualsBuilder.reflectionEquals(this, obj, false);
		}
	}
	

	@XmlAccessorType(XmlAccessType.FIELD)
	public static class FloorInfoList {
		
		@XmlElement(name = "FLR")
		private Col flr = new Col("FLR", "층", "S");
		@XmlElement(name = "ETC_STRU")
		private Col etcStru = new Col("ETC_STRU", "기타구조", "S");
		@XmlElement(name = "MAIN_USE_NM")
		private Col mainUseNm = new Col("MAIN_USE_NM", "주용도명", "S");
		@XmlElement(name = "ETC_USE")
		private Col etcUse = new Col("ETC_USE", "기타용도", "S");
		@XmlElement(name = "BTM_AREA")
		private Col btmArea = new Col("BTM_AREA", "면적", "N");
		@XmlElement(name = "FLR_GBN_CD")
		private Col flrGbnCd = new Col("FLR_GBN_CD", "층구분코드", "S");
		@XmlElement(name = "MAIN_SUB_GBN_NM")
		private Col mainSubGbnNm = new Col("MAIN_SUB_GBN_NM", "주부속구분한글", "S");
		@XmlElement(name = "MAIN_SUB_SEQNO")
		private Col mainSubSeqno = new Col("MAIN_SUB_SEQNO", "주부속일련번호", "N");


		public FloorInfoList() {
		}
		
		public FloorInfoList(FloorInfoList floorInfoList) {
			this.flr.setVal(floorInfoList.flr.getVal());
			this.etcStru.setVal(floorInfoList.etcStru.getVal());
			this.mainUseNm.setVal(floorInfoList.mainUseNm.getVal());
			this.etcUse.setVal(floorInfoList.etcUse.getVal());
			this.btmArea.setVal(floorInfoList.btmArea.getVal());
			this.flrGbnCd.setVal(floorInfoList.flrGbnCd.getVal());
			this.mainSubGbnNm.setVal(floorInfoList.mainSubGbnNm.getVal());
			this.mainSubSeqno.setVal(floorInfoList.mainSubSeqno.getVal());
		}

		
		public Col getFlr() {
			return flr;
		}
		public void setFlr(Col flr) {
			this.flr.setOnlyVal(flr.getVal());
		}
		public Col getEtcStru() {
			return etcStru;
		}
		public void setEtcStru(Col etcStru) {
			this.etcStru.setOnlyVal(etcStru.getVal());
		}
		public Col getMainUseNm() {
			return mainUseNm;
		}
		public void setMainUseNm(Col mainUseNm) {
			this.mainUseNm.setOnlyVal(mainUseNm.getVal());
		}
		public Col getEtcUse() {
			return etcUse;
		}
		public void setEtcUse(Col etcUse) {
			this.etcUse.setOnlyVal(etcUse.getVal());
		}
		public Col getBtmArea() {
			return btmArea;
		}
		public void setBtmArea(Col btmArea) {
			this.btmArea.setOnlyVal(btmArea.getVal());
		}
		public Col getFlrGbnCd() {
			return flrGbnCd;
		}
		public void setFlrGbnCd(Col flrGbnCd) {
			this.flrGbnCd.setOnlyVal(flrGbnCd.getVal());
		}
		public Col getMainSubGbnNm() {
			return mainSubGbnNm;
		}
		public void setMainSubGbnNm(Col mainSubGbnNm) {
			this.mainSubGbnNm.setOnlyVal(mainSubGbnNm.getVal());
		}
		public Col getMainSubSeqno() {
			return mainSubSeqno;
		}
		public void setMainSubSeqno(Col mainSubSeqno) {
			this.mainSubSeqno.setOnlyVal(mainSubSeqno.getVal());
		}
		
		
		@Override
		public String toString() {
			return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
		}

		@Override
		public int hashCode() {
			return HashCodeBuilder.reflectionHashCode(this, false);
		}

		@Override
		public boolean equals(Object obj) {
			return EqualsBuilder.reflectionEquals(this, obj, false);
		}
	}
	
	
	@XmlAccessorType(XmlAccessType.FIELD)
	public static class ChgDataList {

		@XmlElement(name = "CHG_RSN_NM")
		private Col chgRsnNm = new Col("CHG_RSN_NM", "변동원인명", "S");
		@XmlElement(name = "CHG_CNTN")
		private Col chgCntn = new Col("CHG_CNTN", "변동내역", "S");
		@XmlElement(name = "CHG_YMD")
		private Col chgYmd = new Col("CHG_YMD", "변동일자", "S");
		@XmlElement(name = "ADJ_YMD")
		private Col adjYmd = new Col("ADJ_YMD", "정리일자", "S");
		
		
		public ChgDataList() {
		}

		public ChgDataList(ChgDataList chgDataList) {
			this.chgRsnNm.setVal(chgDataList.chgRsnNm.getVal());
			this.chgCntn.setVal(chgDataList.chgCntn.getVal());
			this.chgYmd.setVal(chgDataList.chgYmd.getVal());
			this.adjYmd.setVal(chgDataList.adjYmd.getVal());
		}

		
		public Col getChgRsnNm() {
			return chgRsnNm;
		}
		public void setChgRsnNm(Col chgRsnNm) {
			this.chgRsnNm.setOnlyVal(chgRsnNm.getVal());
		}
		public Col getChgCntn() {
			return chgCntn;
		}
		public void setChgCntn(Col chgCntn) {
			this.chgCntn.setOnlyVal(chgCntn.getVal());
		}
		public Col getChgYmd() {
			return chgYmd;
		}
		public void setChgYmd(Col chgYmd) {
			this.chgYmd.setOnlyVal(chgYmd.getVal());
		}
		public Col getAdjYmd() {
			return adjYmd;
		}
		public void setAdjYmd(Col adjYmd) {
			this.adjYmd.setOnlyVal(adjYmd.getVal());
		}

		
		@Override
		public String toString() {
			return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
		}

		@Override
		public int hashCode() {
			return HashCodeBuilder.reflectionHashCode(this, false);
		}

		@Override
		public boolean equals(Object obj) {
			return EqualsBuilder.reflectionEquals(this, obj, false);
		}
	}


	@XmlAccessorType(XmlAccessType.FIELD)
	public static class UserInfoList {

		@XmlElement(name = "CHG_YMD")
		private Col chgYmd = new Col("CHG_YMD", "변동일자", "S");
		@XmlElement(name = "OWNER_NM")
		private Col ownerNm = new Col("OWNER_NM", "소유자명", "S");
		@XmlElement(name = "DREGNO")
		private Col dregno = new Col("DREGNO", "등록번호", "S");
		@XmlElement(name = "DETL_ADDR")
		private Col detlAddr = new Col("DETL_ADDR", "상세주소", "S");
		@XmlElement(name = "LAST_YN")
		private Col lastYn = new Col("LAST_YN", "최종여부", "S");
		@XmlElement(name = "CHG_RSN_NM")
		private Col chgRsnNm = new Col("CHG_RSN_NM", "변동원인명", "S");
		@XmlElement(name = "OWN_GBN_NM")
		private Col ownGbnNm = new Col("OWN_GBN_NM", "소유구분명", "S");
		@XmlElement(name = "RES_GBN_NM")
		private Col resGbnNm = new Col("RES_GBN_NM", "주민구분명", "S");
		@XmlElement(name = "REGT_YN")
		private Col regtYn = new Col("REGT_YN", "등기여부", "S");
		@XmlElement(name = "JIBUN_DESC")
		private Col jibunDesc = new Col("JIBUN_DESC", "지분내역", "S");
		
		
		public UserInfoList() {
		}

		public UserInfoList(UserInfoList userInfoList) {
			this.chgYmd.setVal(userInfoList.chgYmd.getVal());
			this.ownerNm.setVal(userInfoList.ownerNm.getVal());
			this.dregno.setVal(userInfoList.dregno.getVal());
			this.detlAddr.setVal(userInfoList.detlAddr.getVal());
			this.lastYn.setVal(userInfoList.lastYn.getVal());
			this.chgRsnNm.setVal(userInfoList.chgRsnNm.getVal());
			this.ownGbnNm.setVal(userInfoList.ownGbnNm.getVal());
			this.resGbnNm.setVal(userInfoList.resGbnNm.getVal());
			this.regtYn.setVal(userInfoList.regtYn.getVal());
			this.jibunDesc.setVal(userInfoList.jibunDesc.getVal());
		}

		
		public Col getChgYmd() {
			return chgYmd;
		}
		public void setChgYmd(Col chgYmd) {
			this.chgYmd.setOnlyVal(chgYmd.getVal());
		}
		public Col getOwnerNm() {
			return ownerNm;
		}
		public void setOwnerNm(Col ownerNm) {
			this.ownerNm.setOnlyVal(ownerNm.getVal());
		}
		public Col getDregno() {
			return getDregno(true);
		}
		public Col getDregno(boolean mask) {
			Col tmp = new Col(dregno.getVal());
			if ( mask ) tmp.setVal(SensInfoUtils.maskRegNo(tmp.getVal()));
			return tmp;
		}
		public void setDregno(Col dregno) {
			this.dregno.setOnlyVal(dregno.getVal());
		}
		public Col getDetlAddr() {
			return detlAddr;
		}
		public void setDetlAddr(Col detlAddr) {
			this.detlAddr.setOnlyVal(detlAddr.getVal());
		}
		public Col getLastYn() {
			return lastYn;
		}
		public void setLastYn(Col lastYn) {
			this.lastYn.setOnlyVal(lastYn.getVal());
		}
		public Col getChgRsnNm() {
			return chgRsnNm;
		}
		public void setChgRsnNm(Col chgRsnNm) {
			this.chgRsnNm.setOnlyVal(chgRsnNm.getVal());
		}
		public Col getOwnGbnNm() {
			return ownGbnNm;
		}
		public void setOwnGbnNm(Col ownGbnNm) {
			this.ownGbnNm.setOnlyVal(ownGbnNm.getVal());
		}
		public Col getResGbnNm() {
			return resGbnNm;
		}
		public void setResGbnNm(Col resGbnNm) {
			this.resGbnNm.setOnlyVal(resGbnNm.getVal());
		}
		public Col getRegtYn() {
			return regtYn;
		}
		public void setRegtYn(Col regtYn) {
			this.regtYn.setOnlyVal(regtYn.getVal());
		}
		public Col getJibunDesc() {
			return jibunDesc;
		}
		public void setJibunDesc(Col jibunDesc) {
			this.jibunDesc.setOnlyVal(jibunDesc.getVal());
		}

		
		@Override
		public String toString() {
			return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
		}

		@Override
		public int hashCode() {
			return HashCodeBuilder.reflectionHashCode(this, false);
		}

		@Override
		public boolean equals(Object obj) {
			return EqualsBuilder.reflectionEquals(this, obj, false);
		}
	}
	
	
	public BldgHdsInfo() {
	}

	public BldgHdsInfo(BldgHdsInfo bldgHdsInfo) {
		this.bldgGbnNo.setVal(bldgHdsInfo.bldgGbnNo.getVal());
		this.spcNm.setVal(bldgHdsInfo.spcNm.getVal());
		this.block.setVal(bldgHdsInfo.block.getVal());
		this.lot.setVal(bldgHdsInfo.lot.getVal());
		this.bldgNm.setVal(bldgHdsInfo.bldgNm.getVal());
		this.cmplGbn.setVal(bldgHdsInfo.cmplGbn.getVal());
		this.legaYn.setVal(bldgHdsInfo.legaYn.getVal());
		this.vioBldgYn.setVal(bldgHdsInfo.vioBldgYn.getVal());
		this.landCnt.setVal(bldgHdsInfo.landCnt.getVal());
		this.etcWrtItem.setVal(bldgHdsInfo.etcWrtItem.getVal());
		this.dong.setVal(bldgHdsInfo.dong.getVal());
		this.mainSubGbnNm.setVal(bldgHdsInfo.mainSubGbnNm.getVal());
		this.mainSubSeqno.setVal(bldgHdsInfo.mainSubSeqno.getVal());
		this.struNm.setVal(bldgHdsInfo.struNm.getVal());
		this.etcStru.setVal(bldgHdsInfo.etcStru.getVal());
		this.roofNm.setVal(bldgHdsInfo.roofNm.getVal());
		this.etcRoof.setVal(bldgHdsInfo.etcRoof.getVal());
		this.larea.setVal(bldgHdsInfo.larea.getVal());
		this.fmlyCnt.setVal(bldgHdsInfo.fmlyCnt.getVal());
		this.hehdCnt.setVal(bldgHdsInfo.hehdCnt.getVal());
		this.hoCnt.setVal(bldgHdsInfo.hoCnt.getVal());
		this.barea.setVal(bldgHdsInfo.barea.getVal());
		this.mainUseNm.setVal(bldgHdsInfo.mainUseNm.getVal());
		this.etcUse.setVal(bldgHdsInfo.etcUse.getVal());
		this.garea.setVal(bldgHdsInfo.garea.getVal());
		this.totDongGarea.setVal(bldgHdsInfo.totDongGarea.getVal());
		this.dongBlr.setVal(bldgHdsInfo.dongBlr.getVal());
		this.fsiCalcGarea.setVal(bldgHdsInfo.fsiCalcGarea.getVal());
		this.fsi.setVal(bldgHdsInfo.fsi.getVal());
		this.hgt.setVal(bldgHdsInfo.hgt.getVal());
		this.subBldgCnt.setVal(bldgHdsInfo.subBldgCnt.getVal());
		this.subBldgArea.setVal(bldgHdsInfo.subBldgArea.getVal());
		this.bldgKindCd.setVal(bldgHdsInfo.bldgKindCd.getVal());
		
		this.relationJibunsList = bldgHdsInfo.getRelationJibunsList();
		this.floorInfoList = bldgHdsInfo.getFloorInfoList();
		this.chgDataList = bldgHdsInfo.getChgDataList();
		this.userInfoList = bldgHdsInfo.getUserInfoList();
	}
	

	public Col getBldgGbnNo() {
		return bldgGbnNo;
	}
	public void setBldgGbnNo(Col bldgGbnNo) {
		this.bldgGbnNo.setOnlyVal(bldgGbnNo.getVal());
	}
	public Col getSpcNm() {
		return spcNm;
	}
	public void setSpcNm(Col spcNm) {
		this.spcNm.setOnlyVal(spcNm.getVal());
	}
	public Col getBlock() {
		return block;
	}
	public void setBlock(Col block) {
		this.block.setOnlyVal(block.getVal());
	}
	public Col getLot() {
		return lot;
	}
	public void setLot(Col lot) {
		this.lot.setOnlyVal(lot.getVal());
	}
	public Col getBldgNm() {
		return bldgNm;
	}
	public void setBldgNm(Col bldgNm) {
		this.bldgNm.setOnlyVal(bldgNm.getVal());
	}
	public Col getCmplGbn() {
		return cmplGbn;
	}
	public void setCmplGbn(Col cmplGbn) {
		this.cmplGbn.setOnlyVal(cmplGbn.getVal());
	}
	public Col getLegaYn() {
		return legaYn;
	}
	public void setLegaYn(Col legaYn) {
		this.legaYn.setOnlyVal(legaYn.getVal());
	}
	public Col getVioBldgYn() {
		return vioBldgYn;
	}
	public void setVioBldgYn(Col vioBldgYn) {
		this.vioBldgYn.setOnlyVal(vioBldgYn.getVal());
	}
	public Col getLandCnt() {
		return landCnt;
	}
	public void setLandCnt(Col landCnt) {
		this.landCnt.setOnlyVal(landCnt.getVal());
	}
	public Col getEtcWrtItem() {
		return etcWrtItem;
	}
	public void setEtcWrtItem(Col etcWrtItem) {
		this.etcWrtItem.setOnlyVal(etcWrtItem.getVal());
	}
	public Col getDong() {
		return dong;
	}
	public void setDong(Col dong) {
		this.dong.setOnlyVal(dong.getVal());
	}
	public Col getMainSubGbnNm() {
		return mainSubGbnNm;
	}
	public void setMainSubGbnNm(Col mainSubGbnNm) {
		this.mainSubGbnNm.setOnlyVal(mainSubGbnNm.getVal());
	}
	public Col getMainSubSeqno() {
		return mainSubSeqno;
	}
	public void setMainSubSeqno(Col mainSubSeqno) {
		this.mainSubSeqno.setOnlyVal(mainSubSeqno.getVal());
	}
	public Col getStruNm() {
		return struNm;
	}
	public void setStruNm(Col struNm) {
		this.struNm.setOnlyVal(struNm.getVal());
	}
	public Col getEtcStru() {
		return etcStru;
	}
	public void setEtcStru(Col etcStru) {
		this.etcStru.setOnlyVal(etcStru.getVal());
	}
	public Col getRoofNm() {
		return roofNm;
	}
	public void setRoofNm(Col roofNm) {
		this.roofNm.setOnlyVal(roofNm.getVal());
	}
	public Col getEtcRoof() {
		return etcRoof;
	}
	public void setEtcRoof(Col etcRoof) {
		this.etcRoof.setOnlyVal(etcRoof.getVal());
	}
	public Col getLarea() {
		return larea;
	}
	public void setLarea(Col larea) {
		this.larea.setOnlyVal(larea.getVal());
	}
	public Col getFmlyCnt() {
		return fmlyCnt;
	}
	public void setFmlyCnt(Col fmlyCnt) {
		this.fmlyCnt.setOnlyVal(fmlyCnt.getVal());
	}
	public Col getHehdCnt() {
		return hehdCnt;
	}
	public void setHehdCnt(Col hehdCnt) {
		this.hehdCnt.setOnlyVal(hehdCnt.getVal());
	}
	public Col getHoCnt() {
		return hoCnt;
	}
	public void setHoCnt(Col hoCnt) {
		this.hoCnt.setOnlyVal(hoCnt.getVal());
	}
	public Col getBarea() {
		return barea;
	}
	public void setBarea(Col barea) {
		this.barea.setOnlyVal(barea.getVal());
	}
	public Col getMainUseNm() {
		return mainUseNm;
	}
	public void setMainUseNm(Col mainUseNm) {
		this.mainUseNm.setOnlyVal(mainUseNm.getVal());
	}
	public Col getEtcUse() {
		return etcUse;
	}
	public void setEtcUse(Col etcUse) {
		this.etcUse.setOnlyVal(etcUse.getVal());
	}
	public Col getGarea() {
		return garea;
	}
	public void setGarea(Col garea) {
		this.garea.setOnlyVal(garea.getVal());
	}
	public Col getTotDongGarea() {
		return totDongGarea;
	}
	public void setTotDongGarea(Col totDongGarea) {
		this.totDongGarea.setOnlyVal(totDongGarea.getVal());
	}
	public Col getDongBlr() {
		return dongBlr;
	}
	public void setDongBlr(Col dongBlr) {
		this.dongBlr.setOnlyVal(dongBlr.getVal());
	}
	public Col getFsiCalcGarea() {
		return fsiCalcGarea;
	}
	public void setFsiCalcGarea(Col fsiCalcGarea) {
		this.fsiCalcGarea.setOnlyVal(fsiCalcGarea.getVal());
	}
	public Col getFsi() {
		return fsi;
	}
	public void setFsi(Col fsi) {
		this.fsi.setOnlyVal(fsi.getVal());
	}
	public Col getHgt() {
		return hgt;
	}
	public void setHgt(Col hgt) {
		this.hgt.setOnlyVal(hgt.getVal());
	}
	public Col getSubBldgCnt() {
		return subBldgCnt;
	}
	public void setSubBldgCnt(Col subBldgCnt) {
		this.subBldgCnt.setOnlyVal(subBldgCnt.getVal());
	}
	public Col getSubBldgArea() {
		return subBldgArea;
	}
	public void setSubBldgArea(Col subBldgArea) {
		this.subBldgArea.setOnlyVal(subBldgArea.getVal());
	}
	public Col getBldgKindCd() {
		return bldgKindCd;
	}
	public void setBldgKindCd(Col bldgKindCd) {
		this.bldgKindCd.setOnlyVal(bldgKindCd.getVal());
	}

	public ArrayList<RelationJibunsList> getRelationJibunsList() {
		return relationJibunsList;
	}
	public void setRelationJibunsList(ArrayList<RelationJibunsList> relationJibunsList) {
		this.relationJibunsList = relationJibunsList;
	}
	public ArrayList<FloorInfoList> getFloorInfoList() {
		return floorInfoList;
	}
	public void setFloorInfoList(ArrayList<FloorInfoList> floorInfoList) {
		this.floorInfoList = floorInfoList;
	}
	public ArrayList<ChgDataList> getChgDataList() {
		return chgDataList;
	}
	public void setChgDataList(ArrayList<ChgDataList> chgDataList) {
		this.chgDataList = chgDataList;
	}
	public ArrayList<UserInfoList> getUserInfoList() {
		return userInfoList;
	}
	public void setUserInfoList(ArrayList<UserInfoList> userInfoList) {
		this.userInfoList = userInfoList;
	}

	// 층 정렬
	public void sortFloor() {
		// 정규식으로 flrIdx를 입력
		// 정렬
	}
	
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this, false);
	}

	@Override
	public boolean equals(Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj, false);
	}
}
