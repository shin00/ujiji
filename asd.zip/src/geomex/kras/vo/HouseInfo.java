package geomex.kras.vo;

import geomex.kras.common.vo.Col;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;


@XmlRootElement(name = "HOUSE_INFO_SET")
@XmlAccessorType(XmlAccessType.FIELD)
public class HouseInfo {

	@XmlElement(name = "HOUSE_INFO_BASE")
	private Base base;
	
	@XmlElement(name = "HOUSE_INFO_LIST")
	private ArrayList<HouseInfoList> houseInfoList;


	@XmlAccessorType(XmlAccessType.FIELD)
	public static class Base {

		@XmlElement(name = "ISS_NO")
		private Col issNo = new Col("ISS_NO", "발급문서번호", "N");
		@XmlElement(name = "SEQNO")
		private Col seqno = new Col("SEQNO", "발급일련번호", "N");
		@XmlElement(name = "ADM_SECT_HEAD")
		private Col admSectHead = new Col("ADM_SECT_HEAD", "발급지시장이름 ", "S");
		@XmlElement(name = "ISS_DATE")
		private Col issDate = new Col("ISS_DATE", "발급일자", "S");
		@XmlElement(name = "JIBN")
		private Col jibn = new Col("JIBN", "지번", "S");
		@XmlElement(name = "LAND_LOC_NM")
		private Col landLocNm = new Col("LAND_LOC_NM", "소재지", "S");
		@XmlElement(name = "STAMP_IMG")
		private Col stampImg = new Col("STAMP_IMG", "직인 Image", "S");

		
		public Base() {
		}

		public Base(Base base) {
			this.issNo.setVal(base.issNo.getVal());
			this.seqno.setVal(base.seqno.getVal());
			this.admSectHead.setVal(base.admSectHead.getVal());
			this.issDate.setVal(base.issDate.getVal());
			this.jibn.setVal(base.jibn.getVal());
			this.landLocNm.setVal(base.landLocNm.getVal());
			this.stampImg.setVal(base.stampImg.getVal());
		}
		
		
		public Col getIssNo() {
			return issNo;
		}
		public void setIssNo(Col issNo) {
			this.issNo.setOnlyVal(issNo.getVal());
		}
		public Col getSeqno() {
			return seqno;
		}
		public void setSeqno(Col seqno) {
			this.seqno.setOnlyVal(seqno.getVal());
		}
		public Col getAdmSectHead() {
			return admSectHead;
		}
		public void setAdmSectHead(Col admSectHead) {
			this.admSectHead.setOnlyVal(admSectHead.getVal());
		}
		public Col getIssDate() {
			return issDate;
		}
		public void setIssDate(Col issDate) {
			this.issDate.setOnlyVal(issDate.getVal());
		}
		public Col getJibn() {
			return jibn;
		}
		public void setJibn(Col jibn) {
			this.jibn.setOnlyVal(jibn.getVal());
		}
		public Col getLandLocNm() {
			return landLocNm;
		}
		public void setLandLocNm(Col landLocNm) {
			this.landLocNm.setOnlyVal(landLocNm.getVal());
		}
		public Col getStampImg() {
			return stampImg;
		}
		public void setStampImg(Col stampImg) {
			this.stampImg.setOnlyVal(stampImg.getVal());
		}


		@Override
		public String toString() {
			return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
		}

		@Override
		public int hashCode() {
			return HashCodeBuilder.reflectionHashCode(this, false);
		}

		@Override
		public boolean equals(Object obj) {
			return EqualsBuilder.reflectionEquals(this, obj, false);
		}
	}

	@XmlAccessorType(XmlAccessType.FIELD)
	public static class HouseInfoList {

		@XmlElement(name = "BASE_YEAR")
		private Col baseYear = new Col("BASE_YEAR", "기준년도", "S");
		@XmlElement(name = "INDI_HOUSE_PRC")
		private Col indiHousePrc = new Col("INDI_HOUSE_PRC", "개별주택가격", "N");
		@XmlElement(name = "LAND_AREA")
		private Col landArea = new Col("LAND_AREA", "토지 면적", "N");
		@XmlElement(name = "LAND_CALC_AREA")
		private Col landCalcArea = new Col("LAND_CALC_AREA", "토지 산정 면적", "N");
		@XmlElement(name = "BLDG_AREA")
		private Col bldgArea = new Col("BLDG_AREA", "건물 면적", "N");
		@XmlElement(name = "BLDG_CALC_AREA")
		private Col bldgCalcArea = new Col("BLDG_CALC_AREA", "건물 산정 면적", "N");
		@XmlElement(name = "DONG_NO")
		private Col dongNo = new Col("DONG_NO", "", "N");
		@XmlElement(name = "STDMT")
		private Col stdmt = new Col("STDMT", "", "S");

		
		public HouseInfoList() {
		}

		public HouseInfoList(HouseInfoList houseInfoList) {
			this.baseYear.setVal(houseInfoList.baseYear.getVal());
			this.indiHousePrc.setVal(houseInfoList.indiHousePrc.getVal());
			this.landArea.setVal(houseInfoList.landArea.getVal());
			this.landCalcArea.setVal(houseInfoList.landCalcArea.getVal());
			this.bldgArea.setVal(houseInfoList.bldgArea.getVal());
			this.bldgCalcArea.setVal(houseInfoList.bldgCalcArea.getVal());
			this.dongNo.setVal(houseInfoList.dongNo.getVal());
			this.stdmt.setVal(houseInfoList.stdmt.getVal());
		}
		
		
		public Col getBaseYear() {
			return baseYear;
		}
		public void setBaseYear(Col baseYear) {
			this.baseYear.setOnlyVal(baseYear.getVal());
		}
		public Col getIndiHousePrc() {
			return indiHousePrc;
		}
		public void setIndiHousePrc(Col indiHousePrc) {
			this.indiHousePrc.setOnlyVal(indiHousePrc.getVal());
		}
		public Col getLandArea() {
			return landArea;
		}
		public void setLandArea(Col landArea) {
			this.landArea.setOnlyVal(landArea.getVal());
		}
		public Col getLandCalcArea() {
			return landCalcArea;
		}
		public void setLandCalcArea(Col landCalcArea) {
			this.landCalcArea.setOnlyVal(landCalcArea.getVal());
		}
		public Col getBldgArea() {
			return bldgArea;
		}
		public void setBldgArea(Col bldgArea) {
			this.bldgArea.setOnlyVal(bldgArea.getVal());
		}
		public Col getBldgCalcArea() {
			return bldgCalcArea;
		}
		public void setBldgCalcArea(Col bldgCalcArea) {
			this.bldgCalcArea.setOnlyVal(bldgCalcArea.getVal());
		}
		public Col getDongNo() {
			return dongNo;
		}
		public void setDongNo(Col dongNo) {
			this.dongNo.setOnlyVal(dongNo.getVal());
		}
		public Col getStdmt() {
			return stdmt;
		}
		public void setStdmt(Col stdmt) {
			this.stdmt.setOnlyVal(stdmt.getVal());
		}


		@Override
		public String toString() {
			return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
		}

		@Override
		public int hashCode() {
			return HashCodeBuilder.reflectionHashCode(this, false);
		}

		@Override
		public boolean equals(Object obj) {
			return EqualsBuilder.reflectionEquals(this, obj, false);
		}
	}
	
	
	
	public HouseInfo() {
	}

	public HouseInfo(HouseInfo houseInfo) {
		setBase(houseInfo.base);
		this.houseInfoList = houseInfo.getHouseInfoList();
	}
	

	public Base getBase() {
		return base;
	}
	public void setBase(Base base) {
		this.base = new Base(base);
	}
	public ArrayList<HouseInfoList> getHouseInfoList() {
		return houseInfoList;
	}
	public void setHouseInfoList(ArrayList<HouseInfoList> houseInfoList) {
		this.houseInfoList = houseInfoList;
	}

	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this, false);
	}

	@Override
	public boolean equals(Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj, false);
	}
}
