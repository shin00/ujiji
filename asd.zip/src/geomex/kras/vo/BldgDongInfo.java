package geomex.kras.vo;

import geomex.kras.common.vo.Col;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;


@XmlRootElement(name = "BLDG_DONG_INFO")
@XmlAccessorType(XmlAccessType.FIELD)
public class BldgDongInfo {

	@XmlElement(name = "ADM_SECT_CD")
	private Col admSectCd = new Col("ADM_SECT_CD", "행정구역코드", "S");
	@XmlElement(name = "LAND_LOC_CD")
	private Col landLocCd = new Col("LAND_LOC_CD", "소재지코드", "S");
	@XmlElement(name = "LEDG_GBN")
	private Col ledgGbn = new Col("LEDG_GBN", "대장구분", "S");
	@XmlElement(name = "BOBN")
	private Col bobn = new Col("BOBN", "본번", "S");
	@XmlElement(name = "BUBN")
	private Col bubn = new Col("BUBN", "부번", "S");
	@XmlElement(name = "BLDG_KIND_NM")
	private Col bldgKindNm = new Col("BLDG_KIND_NM", "건물종류명", "S");
	@XmlElement(name = "BLDG_KIND_CD")
	private Col bldgKindCd = new Col("BLDG_KIND_CD", "건물종류코드", "S");
	@XmlElement(name = "BLDG_GBN_NO")
	private Col bldgGbnNo = new Col("BLDG_GBN_NO", "건물구분번호", "S");
	@XmlElement(name = "BLDG_NM")
	private Col bldgNm = new Col("BLDG_NM", "건물명", "S");
	@XmlElement(name = "DONG_NM")
	private Col dongNm = new Col("DONG_NM", "동명", "S");
	@XmlElement(name = "BMAP_YN")
	private Col bmapYn = new Col("BMAP_YN", "건축물 현황도 여부", "S");
	@XmlElement(name = "GAREA")
	private Col garea = new Col("GAREA", "연면적", "N");
	
	
	public BldgDongInfo() {
	}

	public BldgDongInfo(BldgDongInfo bldgDongInfo) {
		this.admSectCd.setVal(bldgDongInfo.admSectCd.getVal());
		this.landLocCd.setVal(bldgDongInfo.landLocCd.getVal());
		this.ledgGbn.setVal(bldgDongInfo.ledgGbn.getVal());
		this.bobn.setVal(bldgDongInfo.bobn.getVal());
		this.bubn.setVal(bldgDongInfo.bubn.getVal());
		this.bldgKindNm.setVal(bldgDongInfo.bldgKindNm.getVal());
		this.bldgKindCd.setVal(bldgDongInfo.bldgKindCd.getVal());
		this.bldgGbnNo.setVal(bldgDongInfo.bldgGbnNo.getVal());
		this.bldgNm.setVal(bldgDongInfo.bldgNm.getVal());
		this.dongNm.setVal(bldgDongInfo.dongNm.getVal());
		this.bmapYn.setVal(bldgDongInfo.bmapYn.getVal());
		this.garea.setVal(bldgDongInfo.garea.getVal());
	}
	

	public Col getAdmSectCd() {
		return admSectCd;
	}
	public void setAdmSectCd(Col admSectCd) {
		this.admSectCd.setOnlyVal(admSectCd.getVal());
	}
	public Col getLandLocCd() {
		return landLocCd;
	}
	public void setLandLocCd(Col landLocCd) {
		this.landLocCd.setOnlyVal(landLocCd.getVal());
	}
	public Col getLedgGbn() {
		return ledgGbn;
	}
	public void setLedgGbn(Col ledgGbn) {
		this.ledgGbn.setOnlyVal(ledgGbn.getVal());
	}
	public Col getBobn() {
		return bobn;
	}
	public void setBobn(Col bobn) {
		this.bobn.setOnlyVal(bobn.getVal());
	}
	public Col getBubn() {
		return bubn;
	}
	public void setBubn(Col bubn) {
		this.bubn.setOnlyVal(bubn.getVal());
	}
	public Col getBldgKindNm() {
		return bldgKindNm;
	}
	public void setBldgKindNm(Col bldgKindNm) {
		this.bldgKindNm.setOnlyVal(bldgKindNm.getVal());
	}
	public Col getBldgKindCd() {
		return bldgKindCd;
	}
	public void setBldgKindCd(Col bldgKindCd) {
		this.bldgKindCd.setOnlyVal(bldgKindCd.getVal());
	}
	public Col getBldgGbnNo() {
		return bldgGbnNo;
	}
	public void setBldgGbnNo(Col bldgGbnNo) {
		this.bldgGbnNo.setOnlyVal(bldgGbnNo.getVal());
	}
	public Col getBldgNm() {
		return bldgNm;
	}
	public void setBldgNm(Col bldgNm) {
		this.bldgNm.setOnlyVal(bldgNm.getVal());
	}
	public Col getDongNm() {
		return dongNm;
	}
	public void setDongNm(Col dongNm) {
		this.dongNm.setOnlyVal(dongNm.getVal());
	}
	public Col getBmapYn() {
		return bmapYn;
	}
	public void setBmapYn(Col bmapYn) {
		this.bmapYn.setOnlyVal(bmapYn.getVal());
	}
	public Col getGarea() {
		return garea;
	}
	public void setGarea(Col garea) {
		this.garea.setOnlyVal(garea.getVal());
	}

	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this, false);
	}

	@Override
	public boolean equals(Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj, false);
	}
}
