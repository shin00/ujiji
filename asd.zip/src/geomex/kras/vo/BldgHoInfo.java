package geomex.kras.vo;

import geomex.kras.common.vo.Col;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;


@XmlRootElement(name = "BLDG_HO_INFO")
@XmlAccessorType(XmlAccessType.FIELD)
public class BldgHoInfo {

	@XmlElement(name = "ADM_SECT_CD")
	private Col admSectCd = new Col("ADM_SECT_CD", "행정구역코드", "S");
	@XmlElement(name = "LAND_LOC_CD")
	private Col landLocCd = new Col("LAND_LOC_CD", "소재지코드", "S");
	@XmlElement(name = "LEDG_GBN")
	private Col ledgGbn = new Col("LEDG_GBN", "대장구분", "S");
	@XmlElement(name = "BOBN")
	private Col bobn = new Col("BOBN", "본번", "S");
	@XmlElement(name = "BUBN")
	private Col bubn = new Col("BUBN", "부번", "S");
	@XmlElement(name = "BLDG_KIND_CD")
	private Col bldgKindCd = new Col("BLDG_KIND_CD", "건물종류코드", "S");
	@XmlElement(name = "BLDG_GBN_NO")
	private Col bldgGbnNo = new Col("BLDG_GBN_NO", "건물구분번호", "N");
	@XmlElement(name = "DONG_NM")
	private Col dongNm = new Col("DONG_NM", "동명", "S");
	@XmlElement(name = "FLR_HO_NM")
	private Col flrHoNm = new Col("FLR_HO_NM", "호명", "S");
	@XmlElement(name = "BMAP_YN")
	private Col bmapYn = new Col("BMAP_YN", "건축물 현황도 여부", "S");
	@XmlElement(name = "GAREA")
	private Col garea = new Col("GAREA", "연면적", "N");
	
	
	public BldgHoInfo() {
	}

	public BldgHoInfo(BldgHoInfo bldgHoInfo) {
		this.admSectCd.setVal(bldgHoInfo.admSectCd.getVal());
		this.landLocCd.setVal(bldgHoInfo.landLocCd.getVal());
		this.ledgGbn.setVal(bldgHoInfo.ledgGbn.getVal());
		this.bobn.setVal(bldgHoInfo.bobn.getVal());
		this.bubn.setVal(bldgHoInfo.bubn.getVal());
		this.bldgKindCd.setVal(bldgHoInfo.bldgKindCd.getVal());
		this.bldgGbnNo.setVal(bldgHoInfo.bldgGbnNo.getVal());
		this.dongNm.setVal(bldgHoInfo.dongNm.getVal());
		this.flrHoNm.setVal(bldgHoInfo.flrHoNm.getVal());
		this.bmapYn.setVal(bldgHoInfo.bmapYn.getVal());
		this.garea.setVal(bldgHoInfo.garea.getVal());
	}
	

	public Col getAdmSectCd() {
		return admSectCd;
	}
	public void setAdmSectCd(Col admSectCd) {
		this.admSectCd.setOnlyVal(admSectCd.getVal());
	}
	public Col getLandLocCd() {
		return landLocCd;
	}
	public void setLandLocCd(Col landLocCd) {
		this.landLocCd.setOnlyVal(landLocCd.getVal());
	}
	public Col getLedgGbn() {
		return ledgGbn;
	}
	public void setLedgGbn(Col ledgGbn) {
		this.ledgGbn.setOnlyVal(ledgGbn.getVal());
	}
	public Col getBobn() {
		return bobn;
	}
	public void setBobn(Col bobn) {
		this.bobn.setOnlyVal(bobn.getVal());
	}
	public Col getBubn() {
		return bubn;
	}
	public void setBubn(Col bubn) {
		this.bubn.setOnlyVal(bubn.getVal());
	}
	public Col getBldgKindCd() {
		return bldgKindCd;
	}
	public void setBldgKindCd(Col bldgKindCd) {
		this.bldgKindCd.setOnlyVal(bldgKindCd.getVal());
	}
	public Col getBldgGbnNo() {
		return bldgGbnNo;
	}
	public void setBldgGbnNo(Col bldgGbnNo) {
		this.bldgGbnNo.setOnlyVal(bldgGbnNo.getVal());
	}
	public Col getDongNm() {
		return dongNm;
	}
	public void setDongNm(Col dongNm) {
		this.dongNm.setOnlyVal(dongNm.getVal());
	}
	public Col getFlrHoNm() {
		return flrHoNm;
	}
	public void setFlrHoNm(Col flrHoNm) {
		this.flrHoNm.setOnlyVal(flrHoNm.getVal());
	}
	public Col getBmapYn() {
		return bmapYn;
	}
	public void setBmapYn(Col bmapYn) {
		this.bmapYn.setOnlyVal(bmapYn.getVal());
	}
	public Col getGarea() {
		return garea;
	}
	public void setGarea(Col garea) {
		this.garea.setOnlyVal(garea.getVal());
	}

	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this, false);
	}

	@Override
	public boolean equals(Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj, false);
	}
}
