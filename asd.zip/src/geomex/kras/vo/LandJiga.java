package geomex.kras.vo;

import geomex.kras.common.vo.Col;
import geomex.kras.common.vo.ResponseHeader;
import geomex.kras.ivo.BldgDongInfoDataSet.ResponseBody;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;


@XmlRootElement(name = "JIGA_CNT_LIST")
@XmlAccessorType(XmlAccessType.FIELD)
public class LandJiga {

	@XmlElement(name = "JIGA_CNF_BASE")
	private Base base;
	
	@XmlElement(name = "JIGA_CNF_LIST")
	private ArrayList<JigaList> jigaList;

	
	@XmlAccessorType(XmlAccessType.FIELD)
	public static class Base {

		@XmlElement(name = "ISS_NO")
		private Col issNo = new Col("ISS_NO", "발급문서번호", "N");
		@XmlElement(name = "SEQNO")
		private Col seqno = new Col("SEQNO", "발급일련번호", "N");
		@XmlElement(name = "ADM_SECT_HEAD")
		private Col admSectHead = new Col("ADM_SECT_HEAD", "발급지시장이름 ", "S");
		@XmlElement(name = "ISS_DATE")
		private Col issDate = new Col("ISS_DATE", "발급일자", "S");
		@XmlElement(name = "ACC_NO")
		private Col accNo = new Col("ACC_NO", "접수번호", "N");
		@XmlElement(name = "SEAL_IMG")
		private Col sealImg = new Col("SEAL_IMG", "수입증지Image", "S");
		@XmlElement(name = "STAMP_IMG")
		private Col stampImg = new Col("STAMP_IMG", "직인 Image", "S");

		
		public Base() {
		}

		public Base(Base base) {
			this.issNo.setVal(base.issNo.getVal());
			this.seqno.setVal(base.seqno.getVal());
			this.admSectHead.setVal(base.admSectHead.getVal());
			this.issDate.setVal(base.issDate.getVal());
			this.accNo.setVal(base.accNo.getVal());
			this.sealImg.setVal(base.sealImg.getVal());
			this.stampImg.setVal(base.stampImg.getVal());
		}
		
		
		public Col getIssNo() {
			return issNo;
		}
		public void setIssNo(Col issNo) {
			this.issNo.setOnlyVal(issNo.getVal());
		}
		public Col getSeqno() {
			return seqno;
		}
		public void setSeqno(Col seqno) {
			this.seqno.setOnlyVal(seqno.getVal());
		}
		public Col getAdmSectHead() {
			return admSectHead;
		}
		public void setAdmSectHead(Col admSectHead) {
			this.admSectHead.setOnlyVal(admSectHead.getVal());
		}
		public Col getIssDate() {
			return issDate;
		}
		public void setIssDate(Col issDate) {
			this.issDate.setOnlyVal(issDate.getVal());
		}
		public Col getAccNo() {
			return accNo;
		}
		public void setAccNo(Col accNo) {
			this.accNo.setOnlyVal(accNo.getVal());
		}
		public Col getSealImg() {
			return sealImg;
		}
		public void setSealImg(Col sealImg) {
			this.sealImg.setOnlyVal(sealImg.getVal());
		}
		public Col getStampImg() {
			return stampImg;
		}
		public void setStampImg(Col stampImg) {
			this.stampImg.setOnlyVal(stampImg.getVal());
		}


		@Override
		public String toString() {
			return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
		}

		@Override
		public int hashCode() {
			return HashCodeBuilder.reflectionHashCode(this, false);
		}

		@Override
		public boolean equals(Object obj) {
			return EqualsBuilder.reflectionEquals(this, obj, false);
		}
	}
	
	@XmlAccessorType(XmlAccessType.FIELD)
	public static class JigaList {

		@XmlElement(name = "BASE_YEAR")
		private Col baseYear = new Col("BASE_YEAR", "기준년도", "S");
		@XmlElement(name = "BASE_MON")
		private Col baseMon = new Col("BASE_MON", "기준월", "S");
		@XmlElement(name = "PANN_JIGA")
		private Col pannJiga = new Col("PANN_JIGA", "개별공시지가", "S");
		@XmlElement(name = "LAND_LOC_NM")
		private Col landLocNm = new Col("LAND_LOC_NM", "소재지", "S");
		@XmlElement(name = "JIBUN")
		private Col jibun = new Col("JIBUN", "지번", "S");
		@XmlElement(name = "PANN_YMD")
		private Col pannYmd = new Col("PANN_YMD", "공시일자", "S");
		@XmlElement(name = "REMARK")
		private Col remark = new Col("REMARK", "비고", "S");
		
		
		public JigaList() {
		}

		public JigaList(JigaList jigaList) {
			this.baseYear.setVal(jigaList.baseYear.getVal());
			this.baseMon.setVal(jigaList.baseMon.getVal());
			this.pannJiga.setVal(jigaList.pannJiga.getVal());
			this.landLocNm.setVal(jigaList.landLocNm.getVal());
			this.jibun.setVal(jigaList.jibun.getVal());
			this.pannYmd.setVal(jigaList.pannYmd.getVal());
			this.remark.setVal(jigaList.remark.getVal());
		}

		
		public Col getBaseYear() {
			return baseYear;
		}
		public void setBaseYear(Col baseYear) {
			this.baseYear.setOnlyVal(baseYear.getVal());
		}
		public Col getBaseMon() {
			return baseMon;
		}
		public void setBaseMon(Col baseMon) {
			this.baseMon.setOnlyVal(baseMon.getVal());
		}
		public Col getPannJiga() {
			return pannJiga;
		}
		public void setPannJiga(Col pannJiga) {
			this.pannJiga.setOnlyVal(pannJiga.getVal());
		}
		public Col getLandLocNm() {
			return landLocNm;
		}
		public void setLandLocNm(Col landLocNm) {
			this.landLocNm.setOnlyVal(landLocNm.getVal());
		}
		public Col getJibun() {
			return jibun;
		}
		public void setJibun(Col jibun) {
			this.jibun.setOnlyVal(jibun.getVal());
		}
		public Col getPannYmd() {
			return pannYmd;
		}
		public void setPannYmd(Col pannYmd) {
			this.pannYmd.setOnlyVal(pannYmd.getVal());
		}
		public Col getRemark() {
			return remark;
		}
		public void setRemark(Col remark) {
			this.remark.setOnlyVal(remark.getVal());
		}

		
		@Override
		public String toString() {
			return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
		}

		@Override
		public int hashCode() {
			return HashCodeBuilder.reflectionHashCode(this, false);
		}

		@Override
		public boolean equals(Object obj) {
			return EqualsBuilder.reflectionEquals(this, obj, false);
		}
	}
	
	
	public LandJiga() {
	}

	public LandJiga(LandJiga landJiga) {
		setBase(landJiga.base);
		this.jigaList = landJiga.getJigaList();
	}
	

	public Base getBase() {
		return base;
	}
	public void setBase(Base base) {
		this.base = new Base(base);
	}
	public ArrayList<JigaList> getJigaList() {
		return jigaList;
	}
	public void setJigaList(ArrayList<JigaList> jigaList) {
		this.jigaList = jigaList;
	}

	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this, false);
	}

	@Override
	public boolean equals(Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj, false);
	}
}
