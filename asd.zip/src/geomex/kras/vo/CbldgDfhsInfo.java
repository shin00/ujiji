package geomex.kras.vo;

import geomex.kras.common.vo.Col;
import geomex.utils.SensInfoUtils;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;


@XmlRootElement(name = "CBLDG_DFHS_INFO")
@XmlAccessorType(XmlAccessType.FIELD)
public class CbldgDfhsInfo {

	@XmlElement(name = "BLDG_GBN_NO")
	private Col bldgGbnNo = new Col("BLDG_GBN_NO", "건물식별번호", "N");
	@XmlElement(name = "HO")
	private Col ho = new Col("HO", "호", "S");
	@XmlElement(name = "UPPER_BLDG_NO")
	private Col upperBldgNo = new Col("UPPER_BLDG_NO", "상위건물식별번호", "N");
	@XmlElement(name = "ETC_WRT_ITEM")
	private Col etcWrtItem = new Col("ETC_WRT_ITEM", "기타기재사항", "S");
	@XmlElement(name = "FLR_NO")
	private Col flrNo = new Col("FLR_NO", "층번호", "N");

	@XmlElement(name = "MONOALL")
	private ArrayList<MonoAll> monoAll;

	@XmlElement(name = "USERINFOM")
	private ArrayList<UserInfom> userInfom;

	@XmlElement(name = "CHGLISTED")
	private ArrayList<ChgListed> chgListed;

	@XmlElement(name = "ALLPRICE")
	private ArrayList<AllPrice> allPrice;

	
	@XmlAccessorType(XmlAccessType.FIELD)
	public static class MonoAll {

		@XmlElement(name = "BLDG_GBN_NO")
		private Col bldgGbnNo = new Col("BLDG_GBN_NO", "건물식별번호", "N");
		@XmlElement(name = "MAIN_SUB_GBN_NM")
		private Col mainSubGbnNm = new Col("MAIN_SUB_GBN_NM", "주부속구분명", "S");
		@XmlElement(name = "EXPOS_COMM_GBN_NM")
		private Col exposCommGbnNm = new Col("EXPOS_COMM_GBN_NM", "전유공유구분코드", "S");
		@XmlElement(name = "FLR")
		private Col flr = new Col("FLR", "층", "S");
		@XmlElement(name = "STRU_NM")
		private Col struNm = new Col("STRU_NM", "구조명", "S");
		@XmlElement(name = "MAIN_USE_NM")
		private Col mainUseNm = new Col("MAIN_USE_NM", "주용도명", "S");
		@XmlElement(name = "ETC_USE")
		private Col etcUse = new Col("ETC_USE", "기타용도", "S");


		public MonoAll() {
		}
		
		public MonoAll(MonoAll monoAll) {
			this.bldgGbnNo.setVal(monoAll.bldgGbnNo.getVal());
			this.mainSubGbnNm.setVal(monoAll.mainSubGbnNm.getVal());
			this.exposCommGbnNm.setVal(monoAll.exposCommGbnNm.getVal());
			this.flr.setVal(monoAll.flr.getVal());
			this.struNm.setVal(monoAll.struNm.getVal());
			this.mainUseNm.setVal(monoAll.mainUseNm.getVal());
			this.etcUse.setVal(monoAll.etcUse.getVal());
		}

		
		public Col getBldgGbnNo() {
			return bldgGbnNo;
		}
		public void setBldgGbnNo(Col bldgGbnNo) {
			this.bldgGbnNo.setOnlyVal(bldgGbnNo.getVal());
		}
		public Col getMainSubGbnNm() {
			return mainSubGbnNm;
		}
		public void setMainSubGbnNm(Col mainSubGbnNm) {
			this.mainSubGbnNm.setOnlyVal(mainSubGbnNm.getVal());
		}
		public Col getExposCommGbnNm() {
			return exposCommGbnNm;
		}
		public void setExposCommGbnNm(Col exposCommGbnNm) {
			this.exposCommGbnNm.setOnlyVal(exposCommGbnNm.getVal());
		}
		public Col getFlr() {
			return flr;
		}
		public void setFlr(Col flr) {
			this.flr.setOnlyVal(flr.getVal());
		}
		public Col getStruNm() {
			return struNm;
		}
		public void setStruNm(Col struNm) {
			this.struNm.setOnlyVal(struNm.getVal());
		}
		public Col getMainUseNm() {
			return mainUseNm;
		}
		public void setMainUseNm(Col mainUseNm) {
			this.mainUseNm.setOnlyVal(mainUseNm.getVal());
		}
		public Col getEtcUse() {
			return etcUse;
		}
		public void setEtcUse(Col etcUse) {
			this.etcUse.setOnlyVal(etcUse.getVal());
		}

		
		@Override
		public String toString() {
			return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
		}

		@Override
		public int hashCode() {
			return HashCodeBuilder.reflectionHashCode(this, false);
		}

		@Override
		public boolean equals(Object obj) {
			return EqualsBuilder.reflectionEquals(this, obj, false);
		}
	}

	@XmlAccessorType(XmlAccessType.FIELD)
	public static class UserInfom {

		@XmlElement(name = "BLDG_GBN_NO")
		private Col bldgGbnNo = new Col("BLDG_GBN_NO", "건물식별번호", "N");
		@XmlElement(name = "CHG_YMD")
		private Col chgYmd = new Col("CHG_YMD", "변동일자", "S");
		@XmlElement(name = "OWNER_NM")
		private Col ownerNm = new Col("OWNER_NM", "소유자명", "S");
		@XmlElement(name = "DREGNO")
		private Col dregno = new Col("DREGNO", "등록번호", "S");
		@XmlElement(name = "DETL_ADDR")
		private Col detlAddr = new Col("DETL_ADDR", "상세주소", "S");
		@XmlElement(name = "LAST_YN")
		private Col lastYn = new Col("LAST_YN", "최종여부", "S");
		@XmlElement(name = "CHG_RSN_NM")
		private Col chgRsnNm = new Col("CHG_RSN_NM", "변동원인명", "S");
		@XmlElement(name = "OWN_GBN_NM")
		private Col ownGbnNm = new Col("OWN_GBN_NM", "소유구분명", "S");
		@XmlElement(name = "RES_GBN_NM")
		private Col resGbnNm = new Col("RES_GBN_NM", "주민구분명", "S");
		@XmlElement(name = "REGT_YN")
		private Col regtYn = new Col("REGT_YN", "등기여부", "S");
		@XmlElement(name = "JIBUN_DESC")
		private Col jibunDesc = new Col("JIBUN_DESC", "지분내역", "S");

	
		public UserInfom() {
		}
		
		public UserInfom(UserInfom userInfom) {
			this.bldgGbnNo.setVal(userInfom.bldgGbnNo.getVal());
			this.chgYmd.setVal(userInfom.chgYmd.getVal());
			this.ownerNm.setVal(userInfom.ownerNm.getVal());
			this.dregno.setVal(userInfom.dregno.getVal());
			this.detlAddr.setVal(userInfom.detlAddr.getVal());
			this.lastYn.setVal(userInfom.lastYn.getVal());
			this.chgRsnNm.setVal(userInfom.chgRsnNm.getVal());
			this.ownGbnNm.setVal(userInfom.ownGbnNm.getVal());
			this.resGbnNm.setVal(userInfom.resGbnNm.getVal());
			this.regtYn.setVal(userInfom.regtYn.getVal());
			this.jibunDesc.setVal(userInfom.jibunDesc.getVal());
		}

		
		public Col getBldgGbnNo() {
			return bldgGbnNo;
		}
		public void setBldgGbnNo(Col bldgGbnNo) {
			this.bldgGbnNo.setOnlyVal(bldgGbnNo.getVal());
		}
		public Col getChgYmd() {
			return chgYmd;
		}
		public void setChgYmd(Col chgYmd) {
			this.chgYmd.setOnlyVal(chgYmd.getVal());
		}
		public Col getOwnerNm() {
			return ownerNm;
		}
		public void setOwnerNm(Col ownerNm) {
			this.ownerNm.setOnlyVal(ownerNm.getVal());
		}
		public Col getDregno() {
			return getDregno(true);
		}
		public Col getDregno(boolean mask) {
			Col tmp = new Col(dregno.getVal());
			if ( mask ) tmp.setVal(SensInfoUtils.maskRegNo(tmp.getVal()));
			return tmp;
		}
		public void setDregno(Col dregno) {
			this.dregno.setOnlyVal(dregno.getVal());
		}
		public Col getDetlAddr() {
			return detlAddr;
		}
		public void setDetlAddr(Col detlAddr) {
			this.detlAddr.setOnlyVal(detlAddr.getVal());
		}
		public Col getLastYn() {
			return lastYn;
		}
		public void setLastYn(Col lastYn) {
			this.lastYn.setOnlyVal(lastYn.getVal());
		}
		public Col getChgRsnNm() {
			return chgRsnNm;
		}
		public void setChgRsnNm(Col chgRsnNm) {
			this.chgRsnNm.setOnlyVal(chgRsnNm.getVal());
		}
		public Col getOwnGbnNm() {
			return ownGbnNm;
		}
		public void setOwnGbnNm(Col ownGbnNm) {
			this.ownGbnNm.setOnlyVal(ownGbnNm.getVal());
		}
		public Col getResGbnNm() {
			return resGbnNm;
		}
		public void setResGbnNm(Col resGbnNm) {
			this.resGbnNm.setOnlyVal(resGbnNm.getVal());
		}
		public Col getRegtYn() {
			return regtYn;
		}
		public void setRegtYn(Col regtYn) {
			this.regtYn.setOnlyVal(regtYn.getVal());
		}
		public Col getJibunDesc() {
			return jibunDesc;
		}
		public void setJibunDesc(Col jibunDesc) {
			this.jibunDesc.setOnlyVal(jibunDesc.getVal());
		}

		
		@Override
		public String toString() {
			return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
		}

		@Override
		public int hashCode() {
			return HashCodeBuilder.reflectionHashCode(this, false);
		}

		@Override
		public boolean equals(Object obj) {
			return EqualsBuilder.reflectionEquals(this, obj, false);
		}
	}

	@XmlAccessorType(XmlAccessType.FIELD)
	public static class ChgListed {

		@XmlElement(name = "BLDG_GBN_NO")
		private Col bldgGbnNo = new Col("BLDG_GBN_NO", "건물식별번호", "N");
		@XmlElement(name = "CHG_RSN_NM")
		private Col chgRsnNm = new Col("CHG_RSN_NM", "변동원인명", "S");
		@XmlElement(name = "CHG_CNTN")
		private Col chgCntn = new Col("CHG_CNTN", "변동내역", "S");
		@XmlElement(name = "CHG_YMD")
		private Col chgYmd = new Col("CHG_YMD", "변동일자", "S");
		@XmlElement(name = "ADJ_YMD")
		private Col adjYmd = new Col("ADJ_YMD", "정리일자", "S");

		
		public ChgListed() {
		}
		
		public ChgListed(ChgListed chgListed) {
			this.bldgGbnNo.setVal(chgListed.bldgGbnNo.getVal());
			this.chgRsnNm.setVal(chgListed.chgRsnNm.getVal());
			this.chgCntn.setVal(chgListed.chgCntn.getVal());
			this.chgYmd.setVal(chgListed.chgYmd.getVal());
			this.adjYmd.setVal(chgListed.adjYmd.getVal());
		}

		
		public Col getBldgGbnNo() {
			return bldgGbnNo;
		}
		public void setBldgGbnNo(Col bldgGbnNo) {
			this.bldgGbnNo.setOnlyVal(bldgGbnNo.getVal());
		}
		public Col getChgRsnNm() {
			return chgRsnNm;
		}
		public void setChgRsnNm(Col chgRsnNm) {
			this.chgRsnNm.setOnlyVal(chgRsnNm.getVal());
		}
		public Col getChgCntn() {
			return chgCntn;
		}
		public void setChgCntn(Col chgCntn) {
			this.chgCntn.setOnlyVal(chgCntn.getVal());
		}
		public Col getChgYmd() {
			return chgYmd;
		}
		public void setChgYmd(Col chgYmd) {
			this.chgYmd.setOnlyVal(chgYmd.getVal());
		}
		public Col getAdjYmd() {
			return adjYmd;
		}
		public void setAdjYmd(Col adjYmd) {
			this.adjYmd.setOnlyVal(adjYmd.getVal());
		}

		
		@Override
		public String toString() {
			return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
		}

		@Override
		public int hashCode() {
			return HashCodeBuilder.reflectionHashCode(this, false);
		}

		@Override
		public boolean equals(Object obj) {
			return EqualsBuilder.reflectionEquals(this, obj, false);
		}
	}

	@XmlAccessorType(XmlAccessType.FIELD)
	public static class AllPrice {

		@XmlElement(name = "BLDG_GBN_NO")
		private Col bldgGbnNo = new Col("BLDG_GBN_NO", "건물식별번호", "N");
		@XmlElement(name = "BASE_YMD")
		private Col baseYmd = new Col("BASE_YMD", "기준일자", "S");
		@XmlElement(name = "HOUSE_PRC")
		private Col housePrc = new Col("HOUSE_PRC", "주택가격", "N");

		
		public AllPrice() {
		}

		public AllPrice(AllPrice allPrice) {
			this.bldgGbnNo.setVal(allPrice.bldgGbnNo.getVal());
			this.baseYmd.setVal(allPrice.baseYmd.getVal());
			this.housePrc.setVal(allPrice.housePrc.getVal());
		}

		
		public Col getBldgGbnNo() {
			return bldgGbnNo;
		}
		public void setBldgGbnNo(Col bldgGbnNo) {
			this.bldgGbnNo.setOnlyVal(bldgGbnNo.getVal());
		}
		public Col getBaseYmd() {
			return baseYmd;
		}
		public void setBaseYmd(Col baseYmd) {
			this.baseYmd.setOnlyVal(baseYmd.getVal());
		}
		public Col getHousePrc() {
			return housePrc;
		}
		public void setHousePrc(Col housePrc) {
			this.housePrc.setOnlyVal(housePrc.getVal());
		}

		
		@Override
		public String toString() {
			return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
		}

		@Override
		public int hashCode() {
			return HashCodeBuilder.reflectionHashCode(this, false);
		}

		@Override
		public boolean equals(Object obj) {
			return EqualsBuilder.reflectionEquals(this, obj, false);
		}
	}
	
	
	public CbldgDfhsInfo() {
	}

	public CbldgDfhsInfo(CbldgDfhsInfo cbldgDfhsInfo) {
		this.upperBldgNo.setVal(cbldgDfhsInfo.upperBldgNo.getVal());
		this.etcWrtItem.setVal(cbldgDfhsInfo.etcWrtItem.getVal());
		this.ho.setVal(cbldgDfhsInfo.ho.getVal());
		this.flrNo.setVal(cbldgDfhsInfo.flrNo.getVal());
		this.bldgGbnNo.setVal(cbldgDfhsInfo.bldgGbnNo.getVal());
		
		this.monoAll = cbldgDfhsInfo.getMonoAll();
		this.userInfom = cbldgDfhsInfo.getUserInfom();
		this.chgListed = cbldgDfhsInfo.getChgListed();
		this.allPrice = cbldgDfhsInfo.getAllPrice();
	}
	

	public Col getBldgGbnNo() {
		return bldgGbnNo;
	}
	public void setBldgGbnNo(Col bldgGbnNo) {
		this.bldgGbnNo.setOnlyVal(bldgGbnNo.getVal());
	}
	public Col getHo() {
		return ho;
	}
	public void setHo(Col ho) {
		this.ho.setOnlyVal(ho.getVal());
	}
	public Col getUpperBldgNo() {
		return upperBldgNo;
	}
	public void setUpperBldgNo(Col upperBldgNo) {
		this.upperBldgNo.setOnlyVal(upperBldgNo.getVal());
	}
	public Col getEtcWrtItem() {
		return etcWrtItem;
	}
	public void setEtcWrtItem(Col etcWrtItem) {
		this.etcWrtItem.setOnlyVal(etcWrtItem.getVal());
	}
	public Col getFlrNo() {
		return flrNo;
	}
	public void setFlrNo(Col flrNo) {
		this.flrNo.setOnlyVal(flrNo.getVal());
	}

	public ArrayList<MonoAll> getMonoAll() {
		return monoAll;
	}
	public void setMonoAll(ArrayList<MonoAll> monoAll) {
		this.monoAll = monoAll;
	}
	public ArrayList<UserInfom> getUserInfom() {
		return userInfom;
	}
	public void setUserInfom(ArrayList<UserInfom> userInfom) {
		this.userInfom = userInfom;
	}
	public ArrayList<ChgListed> getChgListed() {
		return chgListed;
	}
	public void setChgListed(ArrayList<ChgListed> chgListed) {
		this.chgListed = chgListed;
	}
	public ArrayList<AllPrice> getAllPrice() {
		return allPrice;
	}
	public void setAllPrice(ArrayList<AllPrice> allPrice) {
		this.allPrice = allPrice;
	}

	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this, false);
	}

	@Override
	public boolean equals(Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj, false);
	}
}
