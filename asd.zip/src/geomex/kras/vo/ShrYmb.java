package geomex.kras.vo;

import geomex.kras.common.vo.Col;
import geomex.utils.SensInfoUtils;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;


@XmlRootElement(name = "SHR_YMB")
@XmlAccessorType(XmlAccessType.FIELD)
public class ShrYmb {

	@XmlElement(name = "ADM_SECT_CD")
	private Col admSectCd = new Col("ADM_SECT_CD", "행정구역코드", "S");
	@XmlElement(name = "LAND_LOC_CD")
	private Col landLocCd = new Col("LAND_LOC_CD", "소재지코드", "S");
	@XmlElement(name = "LEDG_GBN")
	private Col ledgGbn = new Col("LEDG_GBN", "대장구분", "S");
	@XmlElement(name = "BOBN")
	private Col bobn = new Col("BOBN", "본번", "S");
	@XmlElement(name = "BUBN")
	private Col bubn = new Col("BUBN", "부번", "S");
	@XmlElement(name = "SHR_SEQNO")
	private Col shrSeqno = new Col("SHR_SEQNO", "공유순번", "N");
	@XmlElement(name = "OWN_RGT_CHG_RSN_CD")
	private Col ownRgtChgRsnCd = new Col("OWN_RGT_CHG_RSN_CD", "소유권변동원인", "S");
	@XmlElement(name = "OWN_RGT_CHG_RSN_NM")
	private Col ownRgtChgRsnNm = new Col("OWN_RGT_CHG_RSN_NM", "소유권변동원인명", "S");
	@XmlElement(name = "OWN_RGT_CHG_YMD")
	private Col ownRgtChgYmd = new Col("OWN_RGT_CHG_YMD", "소유권변동일자", "S");
	@XmlElement(name = "OWNER_REGNO")
	private Col ownerRegno = new Col("OWNER_REGNO", "소유자등록번호", "S");
	@XmlElement(name = "OWNER_NM")
	private Col ownerNm = new Col("OWNER_NM", "소유자명", "S");
	@XmlElement(name = "OWNER_ADDR")
	private Col ownerAddr = new Col("OWNER_ADDR", "소유자주소", "S");
	@XmlElement(name = "OWN_RGT_JIBUN")
	private Col ownRgtJibun = new Col("OWN_RGT_JIBUN", "소유권지분", "S");
	@XmlElement(name = "OWN_RGT_CHG_DEL_YMD")
	private Col ownRgtChgDelYmd = new Col("OWN_RGT_CHG_DEL_YMD", "소유권말소일자", "S");
	@XmlElement(name = "OWN_GBN")
	private Col ownGbn = new Col("OWN_GBN", "소유구분", "S");
	@XmlElement(name = "OWN_GBN_NM")
	private Col ownGbnNm = new Col("OWN_GBN_NM", "소유구분명", "S");
	
	
	public ShrYmb() {
	}

	public ShrYmb(ShrYmb shrYmb) {
		this.admSectCd.setVal(shrYmb.admSectCd.getVal());
		this.landLocCd.setVal(shrYmb.landLocCd.getVal());
		this.ledgGbn.setVal(shrYmb.ledgGbn.getVal());
		this.bobn.setVal(shrYmb.bobn.getVal());
		this.bubn.setVal(shrYmb.bubn.getVal());
		this.shrSeqno.setVal(shrYmb.shrSeqno.getVal());
		this.ownRgtChgRsnCd.setVal(shrYmb.ownRgtChgRsnCd.getVal());
		this.ownRgtChgRsnNm.setVal(shrYmb.ownRgtChgRsnNm.getVal());
		this.ownRgtChgYmd.setVal(shrYmb.ownRgtChgYmd.getVal());
		this.ownerRegno.setVal(shrYmb.ownerRegno.getVal());
		this.ownerNm.setVal(shrYmb.ownerNm.getVal());
		this.ownerAddr.setVal(shrYmb.ownerAddr.getVal());
		this.ownRgtJibun.setVal(shrYmb.ownRgtJibun.getVal());
		this.ownRgtChgDelYmd.setVal(shrYmb.ownRgtChgDelYmd.getVal());
		this.ownGbn.setVal(shrYmb.ownGbn.getVal());
		this.ownGbnNm.setVal(shrYmb.ownGbnNm.getVal());
	}
	

	public Col getAdmSectCd() {
		return admSectCd;
	}
	public void setAdmSectCd(Col admSectCd) {
		this.admSectCd.setOnlyVal(admSectCd.getVal());
	}
	public Col getLandLocCd() {
		return landLocCd;
	}
	public void setLandLocCd(Col landLocCd) {
		this.landLocCd.setOnlyVal(landLocCd.getVal());
	}
	public Col getLedgGbn() {
		return ledgGbn;
	}
	public void setLedgGbn(Col ledgGbn) {
		this.ledgGbn.setOnlyVal(ledgGbn.getVal());
	}
	public Col getBobn() {
		return bobn;
	}
	public void setBobn(Col bobn) {
		this.bobn.setOnlyVal(bobn.getVal());
	}
	public Col getBubn() {
		return bubn;
	}
	public void setBubn(Col bubn) {
		this.bubn.setOnlyVal(bubn.getVal());
	}
	public Col getShrSeqno() {
		return shrSeqno;
	}
	public void setShrSeqno(Col shrSeqno) {
		this.shrSeqno.setOnlyVal(shrSeqno.getVal());
	}
	public Col getOwnRgtChgRsnCd() {
		return ownRgtChgRsnCd;
	}
	public void setOwnRgtChgRsnCd(Col ownRgtChgRsnCd) {
		this.ownRgtChgRsnCd.setOnlyVal(ownRgtChgRsnCd.getVal());
	}
	public Col getOwnRgtChgRsnNm() {
		return ownRgtChgRsnNm;
	}
	public void setOwnRgtChgRsnNm(Col ownRgtChgRsnNm) {
		this.ownRgtChgRsnNm.setOnlyVal(ownRgtChgRsnNm.getVal());
	}
	public Col getOwnRgtChgYmd() {
		return ownRgtChgYmd;
	}
	public void setOwnRgtChgYmd(Col ownRgtChgYmd) {
		this.ownRgtChgYmd.setOnlyVal(ownRgtChgYmd.getVal());
	}
	public Col getOwnerRegno() {
		return getOwnerRegno(true);
	}
	public Col getOwnerRegno(boolean mask) {
		Col tmp = new Col(ownerRegno.getVal());
		if ( mask ) tmp.setVal(SensInfoUtils.maskRegNo(tmp.getVal()));
		return tmp;
	}
	public void setOwnerRegno(Col ownerRegno) {
		this.ownerRegno.setOnlyVal(ownerRegno.getVal());
	}
	public Col getOwnerNm() {
		return ownerNm;
	}
	public void setOwnerNm(Col ownerNm) {
		this.ownerNm.setOnlyVal(ownerNm.getVal());
	}
	public Col getOwnerAddr() {
		return ownerAddr;
	}
	public void setOwnerAddr(Col ownerAddr) {
		this.ownerAddr.setOnlyVal(ownerAddr.getVal());
	}
	public Col getOwnRgtJibun() {
		return ownRgtJibun;
	}
	public void setOwnRgtJibun(Col ownRgtJibun) {
		this.ownRgtJibun.setOnlyVal(ownRgtJibun.getVal());
	}
	public Col getOwnRgtChgDelYmd() {
		return ownRgtChgDelYmd;
	}
	public void setOwnRgtChgDelYmd(Col ownRgtChgDelYmd) {
		this.ownRgtChgDelYmd.setOnlyVal(ownRgtChgDelYmd.getVal());
	}
	public Col getOwnGbn() {
		return ownGbn;
	}
	public void setOwnGbn(Col ownGbn) {
		this.ownGbn.setOnlyVal(ownGbn.getVal());
	}
	public Col getOwnGbnNm() {
		return ownGbnNm;
	}
	public void setOwnGbnNm(Col ownGbnNm) {
		this.ownGbnNm.setOnlyVal(ownGbnNm.getVal());
	}

	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this, false);
	}

	@Override
	public boolean equals(Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj, false);
	}
}
