package geomex.kras.vo;

import geomex.kras.common.vo.Col;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;


@XmlRootElement(name = "BLDG_LEDG_GEN_HDS_INFO")
@XmlAccessorType(XmlAccessType.FIELD)
public class BldgLedgGenHdsInfo {

	@XmlElement(name = "BLDG_GBN_NO")
	private Col bldgGbnNo = new Col("BLDG_GBN_NO", "건물식별번호", "N");
	@XmlElement(name = "ADM_SECT_CD")
	private Col admSectCd = new Col("ADM_SECT_CD", "행정구역코드", "S");
	@XmlElement(name = "LAND_LOC_CD")
	private Col landLocCd = new Col("LAND_LOC_CD", "소재지코드", "S");
	@XmlElement(name = "LEDG_GBN")
	private Col ledgGbn = new Col("LEDG_GBN", "대장구분", "S");
	@XmlElement(name = "BOBN")
	private Col bobn = new Col("BOBN", "본번", "S");
	@XmlElement(name = "BUBN")
	private Col bubn = new Col("BUBN", "부번", "S");
	@XmlElement(name = "BLDG_NM")
	private Col bldgNm = new Col("BLDG_NM", "건물명", "S");
	@XmlElement(name = "LAND_CNT")
	private Col landCnt = new Col("LAND_CNT", "외필지수", "N");
	@XmlElement(name = "ETC_WRT_ITEM")
	private Col etcWrtItem = new Col("ETC_WRT_ITEM", "기타기재사항", "S");
	@XmlElement(name = "LEGA_YN")
	private Col legaYn = new Col("LEGA_YN", "양성화여부", "S");
	@XmlElement(name = "UPPER_BLDG_NO")
	private Col upperBldgNo = new Col("UPPER_BLDG_NO", "상위건물식별번호", "N");
	@XmlElement(name = "VIO_BLDG_YN")
	private Col vioBldgYn = new Col("VIO_BLDG_YN", "위반건축물여부", "S");
	@XmlElement(name = "SPC_NM")
	private Col spcNm = new Col("SPC_NM", "특수지명", "S");
	@XmlElement(name = "BLOCK")
	private Col block = new Col("BLOCK", "블록", "S");
	@XmlElement(name = "LOT")
	private Col lot = new Col("LOT", "로트", "S");
	@XmlElement(name = "CMPL_GBN")
	private Col cmplGbn = new Col("CMPL_GBN", "보완구분", "S");
	@XmlElement(name = "SPC_ITEM")
	private Col spcItem = new Col("SPC_ITEM", "특이사항", "S");
	@XmlElement(name = "LAREA")
	private Col larea = new Col("LAREA", "대지면적", "N");
	@XmlElement(name = "BAREA")
	private Col barea = new Col("BAREA", "건축면적", "N");
	@XmlElement(name = "BLR")
	private Col blr = new Col("BLR", "건폐율", "N");
	@XmlElement(name = "GAREA")
	private Col garea = new Col("GAREA", "연면적", "N");
	@XmlElement(name = "FSI")
	private Col fsi = new Col("FSI", "용적율", "N");
	@XmlElement(name = "FSI_CALC_GAREA")
	private Col fsiCalcGarea = new Col("FSI_CALC_GAREA", "용적율산정연면적", "N");
	@XmlElement(name = "MAIN_USE_NM")
	private Col mainUseNm = new Col("MAIN_USE_NM", "주용도코드", "S");
	@XmlElement(name = "ETC_USE")
	private Col etcUse = new Col("ETC_USE", "기타용도", "S");
	@XmlElement(name = "TOT_FMLY_CNT")
	private Col totFmlyCnt = new Col("TOT_FMLY_CNT", "총가구수", "N");
	@XmlElement(name = "TOT_HEHD_CNT")
	private Col totHehdCnt = new Col("TOT_HEHD_CNT", "총세대수", "N");
	@XmlElement(name = "TOT_HO_CNT")
	private Col totHoCnt = new Col("TOT_HO_CNT", "총호수", "N");
	@XmlElement(name = "TOT_MAIN_BLDG_CNT")
	private Col totMainBldgCnt = new Col("TOT_MAIN_BLDG_CNT", "총주건축물수", "N");
	@XmlElement(name = "SUB_BLDG_CNT")
	private Col subBldgCnt = new Col("SUB_BLDG_CNT", "총부속건축물수", "N");
	@XmlElement(name = "SUB_BLDG_AREA")
	private Col subBldgArea = new Col("SUB_BLDG_AREA", "총부속건축물면적", "N");
	@XmlElement(name = "TOT_PARK_CNT")
	private Col totParkCnt = new Col("TOT_PARK_CNT", "총주차수", "N");
	@XmlElement(name = "PERM_YMD")
	private Col permYmd = new Col("PERM_YMD", "허가일자", "S");
	@XmlElement(name = "BGCONS_YMD")
	private Col bgconsYmd = new Col("BGCONS_YMD", "착공일자", "S");
	@XmlElement(name = "USE_APRV_YMD")
	private Col useAprvYmd = new Col("USE_APRV_YMD", "사용승인일자", "S");
	@XmlElement(name = "PERMYMDNUM")
	private Col permymdnum = new Col("PERMYMDNUM", "허가번호", "S");
	
	
	public BldgLedgGenHdsInfo() {
	}

	public BldgLedgGenHdsInfo(BldgLedgGenHdsInfo bldgLedgGenHdsInfo) {
		this.bldgGbnNo.setVal(bldgLedgGenHdsInfo.bldgGbnNo.getVal());
		this.admSectCd.setVal(bldgLedgGenHdsInfo.admSectCd.getVal());
		this.landLocCd.setVal(bldgLedgGenHdsInfo.landLocCd.getVal());
		this.ledgGbn.setVal(bldgLedgGenHdsInfo.ledgGbn.getVal());
		this.bobn.setVal(bldgLedgGenHdsInfo.bobn.getVal());
		this.bubn.setVal(bldgLedgGenHdsInfo.bubn.getVal());
		this.bldgNm.setVal(bldgLedgGenHdsInfo.bldgNm.getVal());
		this.landCnt.setVal(bldgLedgGenHdsInfo.landCnt.getVal());
		this.etcWrtItem.setVal(bldgLedgGenHdsInfo.etcWrtItem.getVal());
		this.legaYn.setVal(bldgLedgGenHdsInfo.legaYn.getVal());
		this.upperBldgNo.setVal(bldgLedgGenHdsInfo.upperBldgNo.getVal());
		this.vioBldgYn.setVal(bldgLedgGenHdsInfo.vioBldgYn.getVal());
		this.spcNm.setVal(bldgLedgGenHdsInfo.spcNm.getVal());
		this.block.setVal(bldgLedgGenHdsInfo.block.getVal());
		this.lot.setVal(bldgLedgGenHdsInfo.lot.getVal());
		this.cmplGbn.setVal(bldgLedgGenHdsInfo.cmplGbn.getVal());
		this.spcItem.setVal(bldgLedgGenHdsInfo.spcItem.getVal());
		this.larea.setVal(bldgLedgGenHdsInfo.larea.getVal());
		this.barea.setVal(bldgLedgGenHdsInfo.barea.getVal());
		this.blr.setVal(bldgLedgGenHdsInfo.blr.getVal());
		this.garea.setVal(bldgLedgGenHdsInfo.garea.getVal());
		this.fsi.setVal(bldgLedgGenHdsInfo.fsi.getVal());
		this.fsiCalcGarea.setVal(bldgLedgGenHdsInfo.fsiCalcGarea.getVal());
		this.mainUseNm.setVal(bldgLedgGenHdsInfo.mainUseNm.getVal());
		this.etcUse.setVal(bldgLedgGenHdsInfo.etcUse.getVal());
		this.totFmlyCnt.setVal(bldgLedgGenHdsInfo.totFmlyCnt.getVal());
		this.totHehdCnt.setVal(bldgLedgGenHdsInfo.totHehdCnt.getVal());
		this.totHoCnt.setVal(bldgLedgGenHdsInfo.totHoCnt.getVal());
		this.totMainBldgCnt.setVal(bldgLedgGenHdsInfo.totMainBldgCnt.getVal());
		this.subBldgCnt.setVal(bldgLedgGenHdsInfo.subBldgCnt.getVal());
		this.subBldgArea.setVal(bldgLedgGenHdsInfo.subBldgArea.getVal());
		this.totParkCnt.setVal(bldgLedgGenHdsInfo.totParkCnt.getVal());
		this.permYmd.setVal(bldgLedgGenHdsInfo.permYmd.getVal());
		this.bgconsYmd.setVal(bldgLedgGenHdsInfo.bgconsYmd.getVal());
		this.useAprvYmd.setVal(bldgLedgGenHdsInfo.useAprvYmd.getVal());
		this.permymdnum.setVal(bldgLedgGenHdsInfo.permymdnum.getVal());
	}
	

	public Col getBldgGbnNo() {
		return bldgGbnNo;
	}
	public void setBldgGbnNo(Col bldgGbnNo) {
		this.bldgGbnNo.setOnlyVal(bldgGbnNo.getVal());
	}
	public Col getAdmSectCd() {
		return admSectCd;
	}
	public void setAdmSectCd(Col admSectCd) {
		this.admSectCd.setOnlyVal(admSectCd.getVal());
	}
	public Col getLandLocCd() {
		return landLocCd;
	}
	public void setLandLocCd(Col landLocCd) {
		this.landLocCd.setOnlyVal(landLocCd.getVal());
	}
	public Col getLedgGbn() {
		return ledgGbn;
	}
	public void setLedgGbn(Col ledgGbn) {
		this.ledgGbn.setOnlyVal(ledgGbn.getVal());
	}
	public Col getBobn() {
		return bobn;
	}
	public void setBobn(Col bobn) {
		this.bobn.setOnlyVal(bobn.getVal());
	}
	public Col getBubn() {
		return bubn;
	}
	public void setBubn(Col bubn) {
		this.bubn.setOnlyVal(bubn.getVal());
	}
	public Col getBldgNm() {
		return bldgNm;
	}
	public void setBldgNm(Col bldgNm) {
		this.bldgNm.setOnlyVal(bldgNm.getVal());
	}
	public Col getLandCnt() {
		return landCnt;
	}
	public void setLandCnt(Col landCnt) {
		this.landCnt.setOnlyVal(landCnt.getVal());
	}
	public Col getEtcWrtItem() {
		return etcWrtItem;
	}
	public void setEtcWrtItem(Col etcWrtItem) {
		this.etcWrtItem.setOnlyVal(etcWrtItem.getVal());
	}
	public Col getLegaYn() {
		return legaYn;
	}
	public void setLegaYn(Col legaYn) {
		this.legaYn.setOnlyVal(legaYn.getVal());
	}
	public Col getUpperBldgNo() {
		return upperBldgNo;
	}
	public void setUpperBldgNo(Col upperBldgNo) {
		this.upperBldgNo.setOnlyVal(upperBldgNo.getVal());
	}
	public Col getVioBldgYn() {
		return vioBldgYn;
	}
	public void setVioBldgYn(Col vioBldgYn) {
		this.vioBldgYn.setOnlyVal(vioBldgYn.getVal());
	}
	public Col getSpcNm() {
		return spcNm;
	}
	public void setSpcNm(Col spcNm) {
		this.spcNm.setOnlyVal(spcNm.getVal());
	}
	public Col getBlock() {
		return block;
	}
	public void setBlock(Col block) {
		this.block.setOnlyVal(block.getVal());
	}
	public Col getLot() {
		return lot;
	}
	public void setLot(Col lot) {
		this.lot.setOnlyVal(lot.getVal());
	}
	public Col getCmplGbn() {
		return cmplGbn;
	}
	public void setCmplGbn(Col cmplGbn) {
		this.cmplGbn.setOnlyVal(cmplGbn.getVal());
	}
	public Col getSpcItem() {
		return spcItem;
	}
	public void setSpcItem(Col spcItem) {
		this.spcItem.setOnlyVal(spcItem.getVal());
	}
	public Col getLarea() {
		return larea;
	}
	public void setLarea(Col larea) {
		this.larea.setOnlyVal(larea.getVal());
	}
	public Col getBarea() {
		return barea;
	}
	public void setBarea(Col barea) {
		this.barea.setOnlyVal(barea.getVal());
	}
	public Col getBlr() {
		return blr;
	}
	public void setBlr(Col blr) {
		this.blr.setOnlyVal(blr.getVal());
	}
	public Col getGarea() {
		return garea;
	}
	public void setGarea(Col garea) {
		this.garea.setOnlyVal(garea.getVal());
	}
	public Col getFsi() {
		return fsi;
	}
	public void setFsi(Col fsi) {
		this.fsi.setOnlyVal(fsi.getVal());
	}
	public Col getFsiCalcGarea() {
		return fsiCalcGarea;
	}
	public void setFsiCalcGarea(Col fsiCalcGarea) {
		this.fsiCalcGarea.setOnlyVal(fsiCalcGarea.getVal());
	}
	public Col getMainUseNm() {
		return mainUseNm;
	}
	public void setMainUseNm(Col mainUseNm) {
		this.mainUseNm.setOnlyVal(mainUseNm.getVal());
	}
	public Col getEtcUse() {
		return etcUse;
	}
	public void setEtcUse(Col etcUse) {
		this.etcUse.setOnlyVal(etcUse.getVal());
	}
	public Col getTotFmlyCnt() {
		return totFmlyCnt;
	}
	public void setTotFmlyCnt(Col totFmlyCnt) {
		this.totFmlyCnt.setOnlyVal(totFmlyCnt.getVal());
	}
	public Col getTotHehdCnt() {
		return totHehdCnt;
	}
	public void setTotHehdCnt(Col totHehdCnt) {
		this.totHehdCnt.setOnlyVal(totHehdCnt.getVal());
	}
	public Col getTotHoCnt() {
		return totHoCnt;
	}
	public void setTotHoCnt(Col totHoCnt) {
		this.totHoCnt.setOnlyVal(totHoCnt.getVal());
	}
	public Col getTotMainBldgCnt() {
		return totMainBldgCnt;
	}
	public void setTotMainBldgCnt(Col totMainBldgCnt) {
		this.totMainBldgCnt.setOnlyVal(totMainBldgCnt.getVal());
	}
	public Col getSubBldgCnt() {
		return subBldgCnt;
	}
	public void setSubBldgCnt(Col subBldgCnt) {
		this.subBldgCnt.setOnlyVal(subBldgCnt.getVal());
	}
	public Col getSubBldgArea() {
		return subBldgArea;
	}
	public void setSubBldgArea(Col subBldgArea) {
		this.subBldgArea.setOnlyVal(subBldgArea.getVal());
	}
	public Col getTotParkCnt() {
		return totParkCnt;
	}
	public void setTotParkCnt(Col totParkCnt) {
		this.totParkCnt.setOnlyVal(totParkCnt.getVal());
	}
	public Col getPermYmd() {
		return permYmd;
	}
	public void setPermYmd(Col permYmd) {
		this.permYmd.setOnlyVal(permYmd.getVal());
	}
	public Col getBgconsYmd() {
		return bgconsYmd;
	}
	public void setBgconsYmd(Col bgconsYmd) {
		this.bgconsYmd.setOnlyVal(bgconsYmd.getVal());
	}
	public Col getUseAprvYmd() {
		return useAprvYmd;
	}
	public void setUseAprvYmd(Col useAprvYmd) {
		this.useAprvYmd.setOnlyVal(useAprvYmd.getVal());
	}
	public Col getPermymdnum() {
		return permymdnum;
	}
	public void setPermymdnum(Col permymdnum) {
		this.permymdnum.setOnlyVal(permymdnum.getVal());
	}

	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this, false);
	}

	@Override
	public boolean equals(Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj, false);
	}
}
