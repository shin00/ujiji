package geomex.kras.vo;

import geomex.kras.common.vo.Col;
import geomex.utils.SensInfoUtils;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;


@XmlRootElement(name = "LAND_INFO")
@XmlAccessorType(XmlAccessType.FIELD)
public class LandInfo {

	@XmlElement(name = "ADM_SECT_CD")
	private Col admSectCd = new Col("ADM_SECT_CD", "행정구역코드", "S");
	@XmlElement(name = "LAND_LOC_CD")
	private Col landLocCd = new Col("LAND_LOC_CD", "소재지코드", "S");
	@XmlElement(name = "LEDG_GBN")
	private Col ledgGbn = new Col("LEDG_GBN", "대장구분", "S");
	@XmlElement(name = "BOBN")
	private Col bobn = new Col("BOBN", "본번", "S");
	@XmlElement(name = "BUBN")
	private Col bubn = new Col("BUBN", "부번", "S");
	@XmlElement(name = "JIMOK")
	private Col jimok = new Col("JIMOK", "지목코드", "S");
	@XmlElement(name = "JIMOK_NM")
	private Col jimokNm = new Col("JIMOK_NM", "지목명", "S");
	@XmlElement(name = "PAREA")
	private Col parea = new Col("PAREA", "면적", "N");
	@XmlElement(name = "GRD")
	private Col grd = new Col("GRD", "토지등급", "S");
	@XmlElement(name = "GRD_YMD")
	private Col grdYmd = new Col("GRD_YMD", "등급변동일자", "S");
	@XmlElement(name = "LAND_MOV_RSN_CD")
	private Col landMovRsnCd = new Col("LAND_MOV_RSN_CD", "이동사유코드", "S");
	@XmlElement(name = "LAND_MOV_RSN_CD_NM")
	private Col landMovRsnCdNm = new Col("LAND_MOV_RSN_CD_NM", "이동사유명", "S");
	@XmlElement(name = "LAND_MOV_YMD")
	private Col landMovYmd = new Col("LAND_MOV_YMD", "이동일자", "S");
	@XmlElement(name = "LEDG_CNTRST_CNF_GBN")
	private Col ledgCntrstCnfGbn = new Col("LEDG_CNTRST_CNF_GBN", "대장대조필구분", "S");
	@XmlElement(name = "BIZ_ACT_NTC_GBN")
	private Col bizActNtcGbn = new Col("BIZ_ACT_NTC_GBN", "사업시행신고구분", "S");
	@XmlElement(name = "MAP_GBN")
	private Col mapGbn = new Col("MAP_GBN", "도해/수치 구분", "S");
	@XmlElement(name = "LAND_LAST_HIST_ODRNO")
	private Col landLastHistOdrno = new Col("LAND_LAST_HIST_ODRNO", "토지최종연혁순번", "S");
	@XmlElement(name = "OWN_RGT_LAST_HIST_ODRNO")
	private Col ownRgtLastHistOdrno = new Col("OWN_RGT_LAST_HIST_ODRNO", "소유권최종연혁순번", "S");
	@XmlElement(name = "OWNER_NM")
	private Col ownerNm = new Col("OWNER_NM", "소유자명", "S");
	@XmlElement(name = "DREGNO")
	private Col dregno = new Col("DREGNO", "등록번호", "S");
	@XmlElement(name = "OWN_GBN")
	private Col ownGbn = new Col("OWN_GBN", "소유구분코드", "S");
	@XmlElement(name = "OWN_GBN_NM")
	private Col ownGbnNm = new Col("OWN_GBN_NM", "소유구분명", "S");
	@XmlElement(name = "SHR_CNT")
	private Col shrCnt = new Col("SHR_CNT", "공유인수", "N");
	@XmlElement(name = "OWNER_ADDR")
	private Col ownerAddr = new Col("OWNER_ADDR", "주소", "S");
	@XmlElement(name = "OWN_RGT_CHG_RSN_CD")
	private Col ownRgtChgRsnCd = new Col("OWN_RGT_CHG_RSN_CD", "변동원인코드", "S");
	@XmlElement(name = "OWN_RGT_CHG_RSN_CD_NM")
	private Col ownRgtChgRsnCdNm = new Col("OWN_RGT_CHG_RSN_CD_NM", "변동원인명", "S");
	@XmlElement(name = "OWNDYMD")
	private Col owndymd = new Col("OWNDYMD", "변동일자", "S");
	@XmlElement(name = "SCALE")
	private Col scale = new Col("SCALE", "축척코드", "S");
	@XmlElement(name = "SCALE_NM")
	private Col scaleNm = new Col("SCALE_NM", "축척명", "S");
	@XmlElement(name = "DOHO")
	private Col doho = new Col("DOHO", "도호", "S");
	@XmlElement(name = "JIGA_BASE_MON")
	private Col jigaBaseMon = new Col("JIGA_BASE_MON", "공시지가기준월", "S");
	@XmlElement(name = "PANN_JIGA")
	private Col pannJiga = new Col("PANN_JIGA", "공시지가", "N");
	@XmlElement(name = "LAST_JIBN")
	private Col lastJibn = new Col("LAST_JIBN", "최종종번", "S");
	@XmlElement(name = "LAST_BU")
	private Col lastBu = new Col("LAST_BU", "본번의 최종부번", "S");
	@XmlElement(name = "LASTBOBN")
	private Col lastbobn = new Col("LASTBOBN", "최종종번의 본번", "S");
	@XmlElement(name = "LASTBUBN")
	private Col lastbubn = new Col("LASTBUBN", "최종종번의 부번", "S");
	@XmlElement(name = "LAND_MOV_CHRG_MAN_ID")
	private Col landMovChrgManId = new Col("LAND_MOV_CHRG_MAN_ID", "토지이동담당당자ID", "S");
	@XmlElement(name = "OWN_RGT_CHG_CHRG_MAN_ID")
	private Col ownRgtChgChrgManId = new Col("OWN_RGT_CHG_CHRG_MAN_ID", "소유권변동담당자ID", "S");
	@XmlElement(name = "BLDG_GBN_NO")
	private Col bldgGbnNo = new Col("BLDG_GBN_NO", "건물식별번호", "S");
	@XmlElement(name = "LAND_MOVE_RELL_JIBN")
	private Col landMoveRellJibn = new Col("LAND_MOVE_RELL_JIBN", "관련지번", "S");
	
	
	public LandInfo() {
	}

	public LandInfo(LandInfo landInfo) {
		this.admSectCd.setVal(landInfo.admSectCd.getVal());
		this.landLocCd.setVal(landInfo.landLocCd.getVal());
		this.ledgGbn.setVal(landInfo.ledgGbn.getVal());
		this.bobn.setVal(landInfo.bobn.getVal());
		this.bubn.setVal(landInfo.bubn.getVal());
		this.jimok.setVal(landInfo.jimok.getVal());
		this.jimokNm.setVal(landInfo.jimokNm.getVal());
		this.parea.setVal(landInfo.parea.getVal());
		this.grd.setVal(landInfo.grd.getVal());
		this.grdYmd.setVal(landInfo.grdYmd.getVal());
		this.landMovRsnCd.setVal(landInfo.landMovRsnCd.getVal());
		this.landMovRsnCdNm.setVal(landInfo.landMovRsnCdNm.getVal());
		this.landMovYmd.setVal(landInfo.landMovYmd.getVal());
		this.ledgCntrstCnfGbn.setVal(landInfo.ledgCntrstCnfGbn.getVal());
		this.bizActNtcGbn.setVal(landInfo.bizActNtcGbn.getVal());
		this.mapGbn.setVal(landInfo.mapGbn.getVal());
		this.landLastHistOdrno.setVal(landInfo.landLastHistOdrno.getVal());
		this.ownRgtLastHistOdrno.setVal(landInfo.ownRgtLastHistOdrno.getVal());
		this.ownerNm.setVal(landInfo.ownerNm.getVal());
		this.dregno.setVal(landInfo.dregno.getVal());
		this.ownGbn.setVal(landInfo.ownGbn.getVal());
		this.ownGbnNm.setVal(landInfo.ownGbnNm.getVal());
		this.shrCnt.setVal(landInfo.shrCnt.getVal());
		this.ownerAddr.setVal(landInfo.ownerAddr.getVal());
		this.ownRgtChgRsnCd.setVal(landInfo.ownRgtChgRsnCd.getVal());
		this.ownRgtChgRsnCdNm.setVal(landInfo.ownRgtChgRsnCdNm.getVal());
		this.owndymd.setVal(landInfo.owndymd.getVal());
		this.scale.setVal(landInfo.scale.getVal());
		this.scaleNm.setVal(landInfo.scaleNm.getVal());
		this.doho.setVal(landInfo.doho.getVal());
		this.jigaBaseMon.setVal(landInfo.jigaBaseMon.getVal());
		this.pannJiga.setVal(landInfo.pannJiga.getVal());
		this.lastJibn.setVal(landInfo.lastJibn.getVal());
		this.lastBu.setVal(landInfo.lastBu.getVal());
		this.lastbobn.setVal(landInfo.lastbobn.getVal());
		this.lastbubn.setVal(landInfo.lastbubn.getVal());
		this.landMovChrgManId.setVal(landInfo.landMovChrgManId.getVal());
		this.ownRgtChgChrgManId.setVal(landInfo.ownRgtChgChrgManId.getVal());
		this.bldgGbnNo.setVal(landInfo.bldgGbnNo.getVal());
		this.landMoveRellJibn.setVal(landInfo.landMoveRellJibn.getVal());
	}
	

	public Col getAdmSectCd() {
		return admSectCd;
	}
	public void setAdmSectCd(Col admSectCd) {
		this.admSectCd.setOnlyVal(admSectCd.getVal());
	}
	public Col getLandLocCd() {
		return landLocCd;
	}
	public void setLandLocCd(Col landLocCd) {
		this.landLocCd.setOnlyVal(landLocCd.getVal());
	}
	public Col getLedgGbn() {
		return ledgGbn;
	}
	public void setLedgGbn(Col ledgGbn) {
		this.ledgGbn.setOnlyVal(ledgGbn.getVal());
	}
	public Col getBobn() {
		return bobn;
	}
	public void setBobn(Col bobn) {
		this.bobn.setOnlyVal(bobn.getVal());
	}
	public Col getBubn() {
		return bubn;
	}
	public void setBubn(Col bubn) {
		this.bubn.setOnlyVal(bubn.getVal());
	}
	public Col getJimok() {
		return jimok;
	}
	public void setJimok(Col jimok) {
		this.jimok.setOnlyVal(jimok.getVal());
	}
	public Col getJimokNm() {
		return jimokNm;
	}
	public void setJimokNm(Col jimokNm) {
		this.jimokNm.setOnlyVal(jimokNm.getVal());
	}
	public Col getParea() {
		return parea;
	}
	public void setParea(Col parea) {
		this.parea.setOnlyVal(parea.getVal());
	}
	public Col getGrd() {
		return grd;
	}
	public void setGrd(Col grd) {
		this.grd.setOnlyVal(grd.getVal());
	}
	public Col getGrdYmd() {
		return grdYmd;
	}
	public void setGrdYmd(Col grdYmd) {
		this.grdYmd.setOnlyVal(grdYmd.getVal());
	}
	public Col getLandMovRsnCd() {
		return landMovRsnCd;
	}
	public void setLandMovRsnCd(Col landMovRsnCd) {
		this.landMovRsnCd.setOnlyVal(landMovRsnCd.getVal());
	}
	public Col getLandMovRsnCdNm() {
		return landMovRsnCdNm;
	}
	public void setLandMovRsnCdNm(Col landMovRsnCdNm) {
		this.landMovRsnCdNm.setOnlyVal(landMovRsnCdNm.getVal());
	}
	public Col getLandMovYmd() {
		return landMovYmd;
	}
	public void setLandMovYmd(Col landMovYmd) {
		this.landMovYmd.setOnlyVal(landMovYmd.getVal());
	}
	public Col getLedgCntrstCnfGbn() {
		return ledgCntrstCnfGbn;
	}
	public void setLedgCntrstCnfGbn(Col ledgCntrstCnfGbn) {
		this.ledgCntrstCnfGbn.setOnlyVal(ledgCntrstCnfGbn.getVal());
	}
	public Col getBizActNtcGbn() {
		return bizActNtcGbn;
	}
	public void setBizActNtcGbn(Col bizActNtcGbn) {
		this.bizActNtcGbn.setOnlyVal(bizActNtcGbn.getVal());
	}
	public Col getMapGbn() {
		return mapGbn;
	}
	public void setMapGbn(Col mapGbn) {
		this.mapGbn.setOnlyVal(mapGbn.getVal());
	}
	public Col getLandLastHistOdrno() {
		return landLastHistOdrno;
	}
	public void setLandLastHistOdrno(Col landLastHistOdrno) {
		this.landLastHistOdrno.setOnlyVal(landLastHistOdrno.getVal());
	}
	public Col getOwnRgtLastHistOdrno() {
		return ownRgtLastHistOdrno;
	}
	public void setOwnRgtLastHistOdrno(Col ownRgtLastHistOdrno) {
		this.ownRgtLastHistOdrno.setOnlyVal(ownRgtLastHistOdrno.getVal());
	}
	public Col getOwnerNm() {
		return ownerNm;
	}
	public void setOwnerNm(Col ownerNm) {
		this.ownerNm.setOnlyVal(ownerNm.getVal());
	}
	public Col getDregno() {
		return getDregno(true);
	}
	public Col getDregno(boolean mask) {
		Col tmp = new Col(dregno.getVal());
		if ( mask ) tmp.setVal(SensInfoUtils.maskRegNo(tmp.getVal()));
		return tmp;
	}
	public void setDregno(Col dregno) {
		this.dregno.setOnlyVal(dregno.getVal());
	}
	public Col getOwnGbn() {
		return ownGbn;
	}
	public void setOwnGbn(Col ownGbn) {
		this.ownGbn.setOnlyVal(ownGbn.getVal());
	}
	public Col getOwnGbnNm() {
		return ownGbnNm;
	}
	public void setOwnGbnNm(Col ownGbnNm) {
		this.ownGbnNm.setOnlyVal(ownGbnNm.getVal());
	}
	public Col getShrCnt() {
		return shrCnt;
	}
	public void setShrCnt(Col shrCnt) {
		this.shrCnt.setOnlyVal(shrCnt.getVal());
	}
	public Col getOwnerAddr() {
		return ownerAddr;
	}
	public void setOwnerAddr(Col ownerAddr) {
		this.ownerAddr.setOnlyVal(ownerAddr.getVal());
	}
	public Col getOwnRgtChgRsnCd() {
		return ownRgtChgRsnCd;
	}
	public void setOwnRgtChgRsnCd(Col ownRgtChgRsnCd) {
		this.ownRgtChgRsnCd.setOnlyVal(ownRgtChgRsnCd.getVal());
	}
	public Col getOwnRgtChgRsnCdNm() {
		return ownRgtChgRsnCdNm;
	}
	public void setOwnRgtChgRsnCdNm(Col ownRgtChgRsnCdNm) {
		this.ownRgtChgRsnCdNm.setOnlyVal(ownRgtChgRsnCdNm.getVal());
	}
	public Col getOwndymd() {
		return owndymd;
	}
	public void setOwndymd(Col owndymd) {
		this.owndymd.setOnlyVal(owndymd.getVal());
	}
	public Col getScale() {
		return scale;
	}
	public void setScale(Col scale) {
		this.scale.setOnlyVal(scale.getVal());
	}
	public Col getScaleNm() {
		return scaleNm;
	}
	public void setScaleNm(Col scaleNm) {
		this.scaleNm.setOnlyVal(scaleNm.getVal());
	}
	public Col getDoho() {
		return doho;
	}
	public void setDoho(Col doho) {
		this.doho.setOnlyVal(doho.getVal());
	}
	public Col getJigaBaseMon() {
		return jigaBaseMon;
	}
	public void setJigaBaseMon(Col jigaBaseMon) {
		this.jigaBaseMon.setOnlyVal(jigaBaseMon.getVal());
	}
	public Col getPannJiga() {
		return pannJiga;
	}
	public void setPannJiga(Col pannJiga) {
		this.pannJiga.setOnlyVal(pannJiga.getVal());
	}
	public Col getLastJibn() {
		return lastJibn;
	}
	public void setLastJibn(Col lastJibn) {
		this.lastJibn.setOnlyVal(lastJibn.getVal());
	}
	public Col getLastBu() {
		return lastBu;
	}
	public void setLastBu(Col lastBu) {
		this.lastBu.setOnlyVal(lastBu.getVal());
	}
	public Col getLastbobn() {
		return lastbobn;
	}
	public void setLastbobn(Col lastbobn) {
		this.lastbobn.setOnlyVal(lastbobn.getVal());
	}
	public Col getLastbubn() {
		return lastbubn;
	}
	public void setLastbubn(Col lastbubn) {
		this.lastbubn.setOnlyVal(lastbubn.getVal());
	}
	public Col getLandMovChrgManId() {
		return landMovChrgManId;
	}
	public void setLandMovChrgManId(Col landMovChrgManId) {
		this.landMovChrgManId.setOnlyVal(landMovChrgManId.getVal());
	}
	public Col getOwnRgtChgChrgManId() {
		return ownRgtChgChrgManId;
	}
	public void setOwnRgtChgChrgManId(Col ownRgtChgChrgManId) {
		this.ownRgtChgChrgManId.setOnlyVal(ownRgtChgChrgManId.getVal());
	}
	public Col getBldgGbnNo() {
		return bldgGbnNo;
	}
	public void setBldgGbnNo(Col bldgGbnNo) {
		this.bldgGbnNo.setOnlyVal(bldgGbnNo.getVal());
	}
	public Col getLandMoveRellJibn() {
		return landMoveRellJibn;
	}
	public void setLandMoveRellJibn(Col landMoveRellJibn) {
		this.landMoveRellJibn.setOnlyVal(landMoveRellJibn.getVal());
	}

	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this, false);
	}

	@Override
	public boolean equals(Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj, false);
	}
}
