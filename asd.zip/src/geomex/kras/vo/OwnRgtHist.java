package geomex.kras.vo;

import geomex.kras.common.vo.Col;
import geomex.utils.SensInfoUtils;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;


@XmlRootElement(name = "OWN_RGT_HIST")
@XmlAccessorType(XmlAccessType.FIELD)
public class OwnRgtHist {

	@XmlElement(name = "ADM_SECT_CD")
	private Col admSectCd = new Col("ADM_SECT_CD", "행정구역코드", "S");
	@XmlElement(name = "LAND_LOC_CD")
	private Col landLocCd = new Col("LAND_LOC_CD", "소재지코드", "S");
	@XmlElement(name = "LEDG_GBN")
	private Col ledgGbn = new Col("LEDG_GBN", "대장구분", "S");
	@XmlElement(name = "BOBN")
	private Col bobn = new Col("BOBN", "본번", "S");
	@XmlElement(name = "BUBN")
	private Col bubn = new Col("BUBN", "부번", "S");
	@XmlElement(name = "OWN_RGT_CHG_RSN_CD")
	private Col ownRgtChgRsnCd = new Col("OWN_RGT_CHG_RSN_CD", "소유권변동원인코드", "S");
	@XmlElement(name = "DREGNO")
	private Col dregno = new Col("DREGNO", "등록번호", "S");
	@XmlElement(name = "DYMD")
	private Col dymd = new Col("DYMD", "변동일자", "S");
	@XmlElement(name = "OWNER_NM")
	private Col ownerNm = new Col("OWNER_NM", "소유자명", "S");
	@XmlElement(name = "SHR_CNT")
	private Col shrCnt = new Col("SHR_CNT", "공유인수", "N");
	@XmlElement(name = "OWN_GBN")
	private Col ownGbn = new Col("OWN_GBN", "소유구분", "S");
	@XmlElement(name = "OWN_RGT_CHG_CHRG_MAN_ID")
	private Col ownRgtChgChrgManId = new Col("OWN_RGT_CHG_CHRG_MAN_ID", "처리담당자", "S");
	@XmlElement(name = "DODRNO")
	private Col dodrno = new Col("DODRNO", "연혁순번", "S");
	@XmlElement(name = "OWN_RGT_CHG_HIST_ODRNO")
	private Col ownRgtChgHistOdrno = new Col("OWN_RGT_CHG_HIST_ODRNO", "소유권연혁순번", "N");
	@XmlElement(name = "OWN_GBN_NM")
	private Col ownGbnNm = new Col("OWN_GBN_NM", "소유구분명", "S");
	@XmlElement(name = "OWN_RGT_CHG_RSN_CD_NM")
	private Col ownRgtChgRsnCdNm = new Col("OWN_RGT_CHG_RSN_CD_NM", "변동원인명", "S");
	
	
	public OwnRgtHist() {
	}

	public OwnRgtHist(OwnRgtHist ownRgtHist) {
		this.admSectCd.setVal(ownRgtHist.admSectCd.getVal());
		this.landLocCd.setVal(ownRgtHist.landLocCd.getVal());
		this.ledgGbn.setVal(ownRgtHist.ledgGbn.getVal());
		this.bobn.setVal(ownRgtHist.bobn.getVal());
		this.bubn.setVal(ownRgtHist.bubn.getVal());
		this.ownRgtChgRsnCd.setVal(ownRgtHist.ownRgtChgRsnCd.getVal());
		this.dregno.setVal(ownRgtHist.dregno.getVal());
		this.dymd.setVal(ownRgtHist.dymd.getVal());
		this.ownerNm.setVal(ownRgtHist.ownerNm.getVal());
		this.shrCnt.setVal(ownRgtHist.shrCnt.getVal());
		this.ownGbn.setVal(ownRgtHist.ownGbn.getVal());
		this.ownRgtChgChrgManId.setVal(ownRgtHist.ownRgtChgChrgManId.getVal());
		this.dodrno.setVal(ownRgtHist.dodrno.getVal());
		this.ownRgtChgHistOdrno.setVal(ownRgtHist.ownRgtChgHistOdrno.getVal());
		this.ownGbnNm.setVal(ownRgtHist.ownGbnNm.getVal());
		this.ownRgtChgRsnCdNm.setVal(ownRgtHist.ownRgtChgRsnCdNm.getVal());
	}
	

	public Col getAdmSectCd() {
		return admSectCd;
	}
	public void setAdmSectCd(Col admSectCd) {
		this.admSectCd.setOnlyVal(admSectCd.getVal());
	}
	public Col getLandLocCd() {
		return landLocCd;
	}
	public void setLandLocCd(Col landLocCd) {
		this.landLocCd.setOnlyVal(landLocCd.getVal());
	}
	public Col getLedgGbn() {
		return ledgGbn;
	}
	public void setLedgGbn(Col ledgGbn) {
		this.ledgGbn.setOnlyVal(ledgGbn.getVal());
	}
	public Col getBobn() {
		return bobn;
	}
	public void setBobn(Col bobn) {
		this.bobn.setOnlyVal(bobn.getVal());
	}
	public Col getBubn() {
		return bubn;
	}
	public void setBubn(Col bubn) {
		this.bubn.setOnlyVal(bubn.getVal());
	}
	public Col getOwnRgtChgRsnCd() {
		return ownRgtChgRsnCd;
	}
	public void setOwnRgtChgRsnCd(Col ownRgtChgRsnCd) {
		this.ownRgtChgRsnCd.setOnlyVal(ownRgtChgRsnCd.getVal());
	}
	public Col getDregno() {
		return getDregno(true);
	}
	public Col getDregno(boolean mask) {
		Col tmp = new Col(dregno.getVal());
		if ( mask ) tmp.setVal(SensInfoUtils.maskRegNo(tmp.getVal()));
		return tmp;
	}
	public void setDregno(Col dregno) {
		this.dregno.setOnlyVal(dregno.getVal());
	}
	public Col getDymd() {
		return dymd;
	}
	public void setDymd(Col dymd) {
		this.dymd.setOnlyVal(dymd.getVal());
	}
	public Col getOwnerNm() {
		return ownerNm;
	}
	public void setOwnerNm(Col ownerNm) {
		this.ownerNm.setOnlyVal(ownerNm.getVal());
	}
	public Col getShrCnt() {
		return shrCnt;
	}
	public void setShrCnt(Col shrCnt) {
		this.shrCnt.setOnlyVal(shrCnt.getVal());
	}
	public Col getOwnGbn() {
		return ownGbn;
	}
	public void setOwnGbn(Col ownGbn) {
		this.ownGbn.setOnlyVal(ownGbn.getVal());
	}
	public Col getOwnRgtChgChrgManId() {
		return ownRgtChgChrgManId;
	}
	public void setOwnRgtChgChrgManId(Col ownRgtChgChrgManId) {
		this.ownRgtChgChrgManId.setOnlyVal(ownRgtChgChrgManId.getVal());
	}
	public Col getDodrno() {
		return dodrno;
	}
	public void setDodrno(Col dodrno) {
		this.dodrno.setOnlyVal(dodrno.getVal());
	}
	public Col getOwnRgtChgHistOdrno() {
		return ownRgtChgHistOdrno;
	}
	public void setOwnRgtChgHistOdrno(Col ownRgtChgHistOdrno) {
		this.ownRgtChgHistOdrno.setOnlyVal(ownRgtChgHistOdrno.getVal());
	}
	public Col getOwnGbnNm() {
		return ownGbnNm;
	}
	public void setOwnGbnNm(Col ownGbnNm) {
		this.ownGbnNm.setOnlyVal(ownGbnNm.getVal());
	}
	public Col getOwnRgtChgRsnCdNm() {
		return ownRgtChgRsnCdNm;
	}
	public void setOwnRgtChgRsnCdNm(Col ownRgtChgRsnCdNm) {
		this.ownRgtChgRsnCdNm.setOnlyVal(ownRgtChgRsnCdNm.getVal());
	}

	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this, false);
	}

	@Override
	public boolean equals(Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj, false);
	}
}
