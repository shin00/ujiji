package geomex.kras.vo;

import geomex.kras.common.vo.Col;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;


@XmlRootElement(name = "LAND_USE_PLAN_CNF_INFO_SET")
@XmlAccessorType(XmlAccessType.FIELD)
public class LandUsePlanInfo {

	@XmlElement(name = "LAND_USE_PLAN_CNF_INFO_BASE")
	private Base base;

	@XmlElement(name = "LEGEND")
	private ArrayList<Legend> legend;
	
	@XmlElement(name = "ABSOLUTE_IMG")
	private Col absoluteImg = new Col("ABSOLUTE_IMG", "", "S");
	@XmlElement(name = "WATER_IMG")
	private Col waterImg = new Col("WATER_IMG", "", "S");
	@XmlElement(name = "ECO_IMG")
	private Col ecoImg = new Col("ECO_IMG", "", "S");
	@XmlElement(name = "LAND_SPACE_IMG")
	private Col landSpaceImg = new Col("LAND_SPACE_IMG", "", "S");

	
	@XmlAccessorType(XmlAccessType.FIELD)
	public static class Base {

		@XmlElement(name = "ISS_SCALE")
		private Col issScale = new Col("ISS_SCALE", "발급축척", "N");
		@XmlElement(name = "ISS_NO")
		private Col issNo = new Col("ISS_NO", "발급문서번호", "N");
		@XmlElement(name = "SEQNO")
		private Col seqno = new Col("SEQNO", "발급일련번호", "N");
		@XmlElement(name = "ADM_SECT_HEAD")
		private Col admSectHead = new Col("ADM_SECT_HEAD", "발급지 시장이름 ", "S");
		@XmlElement(name = "BCHK")
		private Col bchk = new Col("BCHK", "속성,도면 정보 승인여부", "S");
		@XmlElement(name = "LAND_LOC_NM")
		private Col landLocNm = new Col("LAND_LOC_NM", "토지소재지", "S");
		@XmlElement(name = "JIBN")
		private Col jibn = new Col("JIBN", "지번", "S");
		@XmlElement(name = "JIMOK")
		private Col jimok = new Col("JIMOK", "지목 코드", "S");
		@XmlElement(name = "JIMOK_NM")
		private Col jimokNm = new Col("JIMOK_NM", "지목명", "S");
		@XmlElement(name = "PAREA")
		private Col parea = new Col("PAREA", "면적", "N");
		@XmlElement(name = "USELAW_A")
		private Col uselawA = new Col("USELAW_A", "국토의 계획 및 이용", "S");
		@XmlElement(name = "USELAW_B")
		private Col uselawB = new Col("USELAW_B", "타법령에 따른 지역_지구", "S");
		@XmlElement(name = "USELAW_C")
		private Col uselawC = new Col("USELAW_C", "추가기재확인", "S");
		@XmlElement(name = "USELAW_D")
		private Col uselawD = new Col("USELAW_D", "토지이용규제", "S");
		@XmlElement(name = "IMG")
		private Col img = new Col("IMG", "토지이용계획서 Image", "S");
		@XmlElement(name = "SCALE")
		private Col scale = new Col("SCALE", "Map scale", "S");
		@XmlElement(name = "SEAL_IMG")
		private Col sealImg = new Col("SEAL_IMG", "수입증지 Image", "S");
		@XmlElement(name = "STAMP_IMG")
		private Col stampImg = new Col("STAMP_IMG", "직인 Image", "S");

		
		public Base() {
		}
		
		public Base(Base base) {
			this.issScale.setVal(base.issScale.getVal());
			this.issNo.setVal(base.issNo.getVal());
			this.seqno.setVal(base.seqno.getVal());
			this.admSectHead.setVal(base.admSectHead.getVal());
			this.bchk.setVal(base.bchk.getVal());
			this.landLocNm.setVal(base.landLocNm.getVal());
			this.jibn.setVal(base.jibn.getVal());
			this.jimok.setVal(base.jimok.getVal());
			this.jimokNm.setVal(base.jimokNm.getVal());
			this.parea.setVal(base.parea.getVal());
			this.uselawA.setVal(base.uselawA.getVal());
			this.uselawB.setVal(base.uselawB.getVal());
			this.uselawC.setVal(base.uselawC.getVal());
			this.uselawD.setVal(base.uselawD.getVal());
			this.img.setVal(base.img.getVal());
			this.scale.setVal(base.scale.getVal());
			this.sealImg.setVal(base.sealImg.getVal());
			this.stampImg.setVal(base.stampImg.getVal());
		}
		
		
		public Col getIssScale() {
			return issScale;
		}
		public void setIssScale(Col issScale) {
			this.issScale.setOnlyVal(issScale.getVal());
		}
		public Col getIssNo() {
			return issNo;
		}
		public void setIssNo(Col issNo) {
			this.issNo.setOnlyVal(issNo.getVal());
		}
		public Col getSeqno() {
			return seqno;
		}
		public void setSeqno(Col seqno) {
			this.seqno.setOnlyVal(seqno.getVal());
		}
		public Col getAdmSectHead() {
			return admSectHead;
		}
		public void setAdmSectHead(Col admSectHead) {
			this.admSectHead.setOnlyVal(admSectHead.getVal());
		}
		public Col getBchk() {
			return bchk;
		}
		public void setBchk(Col bchk) {
			this.bchk.setOnlyVal(bchk.getVal());
		}
		public Col getLandLocNm() {
			return landLocNm;
		}
		public void setLandLocNm(Col landLocNm) {
			this.landLocNm.setOnlyVal(landLocNm.getVal());
		}
		public Col getJibn() {
			return jibn;
		}
		public void setJibn(Col jibn) {
			this.jibn.setOnlyVal(jibn.getVal());
		}
		public Col getJimok() {
			return jimok;
		}
		public void setJimok(Col jimok) {
			this.jimok.setOnlyVal(jimok.getVal());
		}
		public Col getJimokNm() {
			return jimokNm;
		}
		public void setJimokNm(Col jimokNm) {
			this.jimokNm.setOnlyVal(jimokNm.getVal());
		}
		public Col getParea() {
			return parea;
		}
		public void setParea(Col parea) {
			this.parea.setOnlyVal(parea.getVal());
		}
		public Col getUselawA() {
			return uselawA;
		}
		public void setUselawA(Col uselawA) {
			this.uselawA.setOnlyVal(uselawA.getVal());
		}
		public Col getUselawB() {
			return uselawB;
		}
		public void setUselawB(Col uselawB) {
			this.uselawB.setOnlyVal(uselawB.getVal());
		}
		public Col getUselawC() {
			return uselawC;
		}
		public void setUselawC(Col uselawC) {
			this.uselawC.setOnlyVal(uselawC.getVal());
		}
		public Col getUselawD() {
			return uselawD;
		}
		public void setUselawD(Col uselawD) {
			this.uselawD.setOnlyVal(uselawD.getVal());
		}
		public Col getImg() {
			return img;
		}
		public void setImg(Col img) {
			this.img.setOnlyVal(img.getVal());
		}
		public Col getScale() {
			return scale;
		}
		public void setScale(Col scale) {
			this.scale.setOnlyVal(scale.getVal());
		}
		public Col getSealImg() {
			return sealImg;
		}
		public void setSealImg(Col sealImg) {
			this.sealImg.setOnlyVal(sealImg.getVal());
		}
		public Col getStampImg() {
			return stampImg;
		}
		public void setStampImg(Col stampImg) {
			this.stampImg.setOnlyVal(stampImg.getVal());
		}

		
		@Override
		public String toString() {
			return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
		}

		@Override
		public int hashCode() {
			return HashCodeBuilder.reflectionHashCode(this, false);
		}

		@Override
		public boolean equals(Object obj) {
			return EqualsBuilder.reflectionEquals(this, obj, false);
		}
	}

	@XmlAccessorType(XmlAccessType.FIELD)
	public static class Legend {

		@XmlElement(name = "IMG")
		private Col img = new Col("IMG", "범례이미지", "S");
		@XmlElement(name = "TEXT")
		private Col text = new Col("TEXT", "범례명", "S");

		
		public Legend() {
		}
		
		public Legend(Legend legend) {
			this.img.setVal(legend.img.getVal());
			this.text.setVal(legend.text.getVal());
		}
		
		
		public Col getImg() {
			return img;
		}
		public void setImg(Col img) {
			this.img.setOnlyVal(img.getVal());
		}
		public Col getText() {
			return text;
		}
		public void setText(Col text) {
			this.text.setOnlyVal(text.getVal());
		}

		
		@Override
		public String toString() {
			return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
		}

		@Override
		public int hashCode() {
			return HashCodeBuilder.reflectionHashCode(this, false);
		}

		@Override
		public boolean equals(Object obj) {
			return EqualsBuilder.reflectionEquals(this, obj, false);
		}
	}
	
	
	public LandUsePlanInfo() {
	}

	public LandUsePlanInfo(LandUsePlanInfo landUsePlan) {

		this.base = landUsePlan.getBase();

		this.legend = landUsePlan.getLegend();

		this.absoluteImg.setVal(landUsePlan.absoluteImg.getVal());
		this.waterImg.setVal(landUsePlan.waterImg.getVal());
		this.ecoImg.setVal(landUsePlan.ecoImg.getVal());
		this.landSpaceImg.setVal(landUsePlan.landSpaceImg.getVal());
	}
	

	public Base getBase() {
		return base;
	}
	public void setBase(Base base) {
		this.base = new Base(base);
	}

	public ArrayList<Legend> getLegend() {
		return legend;
	}
	public void setLegend(ArrayList<Legend> legend) {
		this.legend = legend;
	}
	
	public Col getAbsoluteImg() {
		return absoluteImg;
	}
	public void setAbsoluteImg(Col absoluteImg) {
		this.absoluteImg.setOnlyVal(absoluteImg.getVal());
	}
	public Col getWaterImg() {
		return waterImg;
	}
	public void setWaterImg(Col waterImg) {
		this.waterImg.setOnlyVal(waterImg.getVal());
	}
	public Col getEcoImg() {
		return ecoImg;
	}
	public void setEcoImg(Col ecoImg) {
		this.ecoImg.setOnlyVal(ecoImg.getVal());
	}
	public Col getLandSpaceImg() {
		return landSpaceImg;
	}
	public void setLandSpaceImg(Col landSpaceImg) {
		this.landSpaceImg.setOnlyVal(landSpaceImg.getVal());
	}

	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this, false);
	}

	@Override
	public boolean equals(Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj, false);
	}
}
