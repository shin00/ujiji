package geomex.kras;

import geomex.kras.common.PnuUtils;
import geomex.utils.MapUtils;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;

import com.gpki.gpkiapi.GpkiApi;
import com.gpki.gpkiapi.cert.X509Certificate;
import com.gpki.gpkiapi.cms.EnvelopedData;
import com.gpki.gpkiapi.crypto.PrivateKey;
import com.gpki.gpkiapi.exception.GpkiApiException;
import com.gpki.gpkiapi.storage.Disk;


/**
 * <PRE>
 * 파일명   : KrasConn.java
 * 파일설명 : 
 * 수정이력 : 
 *       2015. 6. 9.  이규하  : 최초작성
 * </PRE>
 *
 * @author 이규하
 *
 */

public class KrasConn {

	private static HashMap<String, String> locCdIps = new HashMap<String, String>();
	
	private static String CONN_SYS_ID = "";
	
	
	private static boolean GPKI_USE = false;
	private static String GPKI_ID = "";
	private static String GPKI_API_CONF_PATH = "";
	private static String GPKI_CER_FILE = "";
	private static String GPKI_PRI_KEY_FILE = "";
	private static String GPKI_PASS = "";

	private static int TIMEOUT = 3000;

	static {

		locCdIps = KrasConnCfg.getServers();

		
		HashMap<String, String> cfg = KrasConnCfg.getCfg();
		String gpkiUse = "";

		CONN_SYS_ID = cfg.get("conn_sys_id");
		
		gpkiUse = cfg.get("gpki_use");
		if ( "true".equals(gpkiUse.toLowerCase()) ) GPKI_USE = true;
		
		GPKI_ID = cfg.get("gpki_id");
		GPKI_API_CONF_PATH = cfg.get("gpki_api_conf_path");
		GPKI_CER_FILE = cfg.get("gpki_cer_file");
		GPKI_PRI_KEY_FILE = cfg.get("gpki_pri_key_file");
		GPKI_PASS = cfg.get("gpki_pass");
		
		if ( cfg.get("timeout") != null && cfg.get("timeout").trim().equals("") ) TIMEOUT = Integer.valueOf(cfg.get("timeout")); 
	}

	private LinkedHashMap<String, String> params = new LinkedHashMap<String, String>();

	
	public KrasConn() {
		params.put("conn_sys_id", CONN_SYS_ID);
		params.put("gpki_id", GPKI_ID);
	}

	public String getData(String svcId, String pnu) {
		return getData(svcId, pnu, null);
	}

	public String getBldgData(String svcId, String pnu, String bldgGbnNo) {
		Map<String, String> params = new LinkedHashMap<String, String>();
		params.put("bldg_gbn_no", bldgGbnNo);
		
		return getData(svcId, pnu, params);
	}


	public String getData(String svcId, String pnu, Map<String, String> uParams) {
		
	    String rstData = null;
	    
	    HttpURLConnection httpConn = null;

	    String[] pnuArr = PnuUtils.splitArr(pnu);
	    
	    
	    if ( locCdIps.containsKey(pnuArr[0]) ) {
	    
		    params.put("conn_svc_id", svcId);
		
		    params.put("adm_sect_cd", pnuArr[0]);
		    params.put("land_loc_cd", pnuArr[1]);
		    params.put("ledg_gbn", pnuArr[2]); 
		    params.put("bobn", pnuArr[3]); 
		    params.put("bubn", pnuArr[4]);
		
		    if ( uParams != null ) params.putAll(uParams);
		    
			String param = MapUtils.join(params, "=", "&");
			//System.out.println(param);
		    
		    try {
				
			    String rcvStr = null;
		
			    URL svrUrl = new URL("http://" + locCdIps.get(pnuArr[0]) + ":8385/conn/estateGateway");
		
			    httpConn = (HttpURLConnection)svrUrl.openConnection();
			    httpConn.setConnectTimeout(TIMEOUT);
			    httpConn.setRequestMethod("POST");
			    httpConn.setDoOutput(true);
			    httpConn.connect();
						
				OutputStream os = (OutputStream)httpConn.getOutputStream();
				os.write(param.getBytes());
				os.flush();
				os.close();
		
				BufferedReader br;
				if ( GPKI_USE ) {
					br = new BufferedReader( new InputStreamReader( httpConn.getInputStream() ) );
				} else {
					br = new BufferedReader( new InputStreamReader( httpConn.getInputStream(), "UTF-8" ) );
				}
				StringBuffer sb = new StringBuffer();
				String line;
				while ( (line = br.readLine()) != null ) {
					sb.append(line);
				}
				rcvStr = sb.toString();
				//System.out.println(rcvStr);
		
				if ( GPKI_USE ) {
					rstData = new String(decrypt(rcvStr), "UTF-8");
				} else {
					rstData = rcvStr;
				}
		    } 	  
		    catch(Exception e){
		    	e.printStackTrace();
		    } finally {
		        if (httpConn != null) httpConn.disconnect();
		    }
		
	    } else {
	    	rstData = "-1";  //접속서버정보가 없음

	    }

		return rstData;
	}

	
	
	
	private byte[] decrypt(String str) throws GpkiApiException {
		
	 	byte[] rst = null;

	 	byte[] decoded = Base64.decodeBase64(str);
		
		X509Certificate psignerCert;
 		PrivateKey psignerKey;
		EnvelopedData envData = null;
		 
		/* 서버인증서 정보를 읽어서 복호화 */
		GpkiApi.init(GPKI_API_CONF_PATH);
		psignerCert = Disk.readCert(GPKI_CER_FILE);
		psignerKey = Disk.readPriKey(GPKI_PRI_KEY_FILE, GPKI_PASS);
		envData = new EnvelopedData("NEAT");  // NEAT 알고리즘으로 암호화 
		
		rst = envData.process( decoded, psignerCert, psignerKey );
		
		return rst;
	}
	
}
