package geomex.kras.gmx.ctrl;

import java.net.URLDecoder;

import geomex.kras.gmx.svc.*;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import javax.ws.rs.FormParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;


@Path("/")
public class LandBldgCtrl {

	/**
	 * 토지
	 */

	@GET
	@Path("/GetLandInfo")
	public Response getLandInfo_GET(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu) {
		return getLandInfo(req, pnu);
	}
	@POST
	@Path("/GetLandInfo")
	public Response getLandInfo_POST(@Context HttpServletRequest req, @FormParam("pnu") final String pnu) {
		return getLandInfo(req, pnu);
	}

	private Response getLandInfo(HttpServletRequest req, final String pnu) {
		String rst = "";
		
		GetLandInfo svc = new GetLandInfo();
		rst = appendXmlDcl(svc.getData(pnu));
		
		return Response.ok(rst, MediaType.APPLICATION_XML).build();
	}

	
	
	@GET
	@Path("/GetJigaInfo")
	public Response getJigaInfo_GET(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu) {
		return getJigaInfo(req, pnu);
	}
	@POST
	@Path("/GetJigaInfo")
	public Response getJigaInfo_POST(@Context HttpServletRequest req, @FormParam("pnu") final String pnu) {
		return getJigaInfo(req, pnu);
	}

	private Response getJigaInfo(HttpServletRequest req, final String pnu) {
		String rst = "";

		GetJigaInfo svc = new GetJigaInfo();
		rst = appendXmlDcl(svc.getData(pnu));
		
		return Response.ok(rst, MediaType.APPLICATION_XML).build();
	}

	
	
	@GET
	@Path("/GetShareInfo")
	public Response getShareInfo_GET(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu) {
		return getShareInfo(req, pnu);
	}
	@POST
	@Path("/GetShareInfo")
	public Response getShareInfo_POST(@Context HttpServletRequest req, @FormParam("pnu") final String pnu) {
		return getShareInfo(req, pnu);
	}

	private Response getShareInfo(HttpServletRequest req, final String pnu) {
		String rst = "";

		GetShareInfo svc = new GetShareInfo();
		rst = appendXmlDcl(svc.getData(pnu));
		
		return Response.ok(rst, MediaType.APPLICATION_XML).build();
	}
	
	
	
	@GET
	@Path("/GetTojiDaejangPrint")
	public Response getTojiDaejangPrint_GET(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu, @QueryParam("user") final String user) {
		String userDec = "";
		try {
			userDec = URLDecoder.decode(user, "UTF-8");
		} catch(Exception e) {
		}

		return getTojiDaejangPrint(req, pnu, userDec);
	}
	@POST
	@Path("/GetTojiDaejangPrint")
	public Response getTojiDaejangPrint_POST(@Context HttpServletRequest req, @FormParam("pnu") final String pnu, @FormParam("user") final String user) {
		return getTojiDaejangPrint(req, pnu, user);
	}

	private Response getTojiDaejangPrint(HttpServletRequest req, final String pnu, final String user) {
		String rst = "";

		GetTojiDaejangPrint svc = new GetTojiDaejangPrint();
		rst = appendXmlDcl(svc.getData(pnu, user));
		
		return Response.ok(rst, MediaType.APPLICATION_XML).build();
	}

	
	
	@GET
	@Path("/GetTojiDaejangPrint2")
	public Response getTojiDaejangPrint2_GET(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu, @QueryParam("user") final String user) {
		String userDec = "";
		try {
			userDec = URLDecoder.decode(user, "UTF-8");
		} catch(Exception e) {
		}
		
		return getTojiDaejangPrint2(req, pnu, userDec);
	}
	@POST
	@Path("/GetTojiDaejangPrint2")
	public Response getTojiDaejangPrint2_POST(@Context HttpServletRequest req, @FormParam("pnu") final String pnu, @FormParam("user") final String user) {
		return getTojiDaejangPrint2(req, pnu, user);
	}

	private Response getTojiDaejangPrint2(HttpServletRequest req, final String pnu, final String user) {
		String rst = "";

		GetTojiDaejangPrint2 svc = new GetTojiDaejangPrint2();
		rst = appendXmlDcl(svc.getData(pnu, user));
		
		return Response.ok(rst, MediaType.APPLICATION_XML).build();
	}


	
	@GET
	@Path("/GetUseZoneList")
	public Response getUseZoneList_GET(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu) {
		return getUseZoneList(req, pnu);
	}
	@POST
	@Path("/GetUseZoneList")
	public Response getUseZoneList_POST(@Context HttpServletRequest req, @FormParam("pnu") final String pnu) {
		return getUseZoneList(req, pnu);
	}

	private Response getUseZoneList(HttpServletRequest req, final String pnu) {
		String rst = "";

		GetUseZoneList svc = new GetUseZoneList();
		rst = appendXmlDcl(svc.getData(pnu));
		
		return Response.ok(rst, MediaType.APPLICATION_XML).build();
	}

	
	
	/**
	 * 건축물
	 */

	@GET
	@Path("/GetBldgInfo")
	public Response getBldgInfo_GET(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu) {
		return getBldgInfo(req, pnu);
	}
	@POST
	@Path("/GetBldgInfo")
	public Response getBldgInfo_POST(@Context HttpServletRequest req, @FormParam("pnu") final String pnu) {
		return getBldgInfo(req, pnu);
	}

	private Response getBldgInfo(HttpServletRequest req, final String pnu) {
		String rst = "";

		GetBldgInfo svc = new GetBldgInfo();
		rst = appendXmlDcl(svc.getData(pnu));
		
		return Response.ok(rst, MediaType.APPLICATION_XML).build();
	}

	
	
	@GET
	@Path("/GetBldgList")
	public Response getBldgList_GET(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu) {
		return getBldgList(req, pnu);
	}
	@POST
	@Path("/GetBldgList")
	public Response getBldgList_POST(@Context HttpServletRequest req, @FormParam("pnu") final String pnu) {
		return getBldgList(req, pnu);
	}

	private Response getBldgList(HttpServletRequest req, final String pnu) {
		String rst = "";

		GetBldgList svc = new GetBldgList();
		rst = appendXmlDcl(svc.getData(pnu));
		
		return Response.ok(rst, MediaType.APPLICATION_XML).build();
	}

	
	
	@GET
	@Path("/GetDjyrecaptitle")
	public Response getDjyrecaptitle_GET(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu) {
		return getDjyrecaptitle(req, pnu);
	}
	@POST
	@Path("/GetDjyrecaptitle")
	public Response getDjyrecaptitle_POST(@Context HttpServletRequest req, @FormParam("pnu") final String pnu) {
		return getDjyrecaptitle(req, pnu);
	}
	
	private Response getDjyrecaptitle(HttpServletRequest req, final String pnu) {
		String rst = "";

		GetDjyrecaptitle svc = new GetDjyrecaptitle();
		rst = appendXmlDcl(svc.getData(pnu));
		
		return Response.ok(rst, MediaType.APPLICATION_XML).build();
	}

	
	
	@GET
	@Path("/GetDjytitle")
	public Response getDjytitle_GET(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu, @QueryParam("bno") final String bno) {
		return getDjytitle(req, pnu, bno);
	}
	@POST
	@Path("/GetDjytitle")
	public Response getDjytitle_POST(@Context HttpServletRequest req, @FormParam("pnu") final String pnu, @FormParam("bno") final String bno) {
		return getDjytitle(req, pnu, bno);
	}

	private Response getDjytitle(HttpServletRequest req, final String pnu, final String bno) {
		String rst = "";

		GetDjytitle svc = new GetDjytitle();
		rst = appendXmlDcl(svc.getData(pnu, bno));
		
		return Response.ok(rst, MediaType.APPLICATION_XML).build();
	}

	
	
	@GET
	@Path("/GetJeonyubldg")
	public Response getJeonyubldg_GET(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu, @QueryParam("bno") final String bno) {
		return getJeonyubldg(req, pnu, bno);
	}
	@POST
	@Path("/GetJeonyubldg")
	public Response getJeonyubldg_POST(@Context HttpServletRequest req, @FormParam("pnu") final String pnu, @FormParam("bno") final String bno) {
		return getJeonyubldg(req, pnu, bno);
	}

	private Response getJeonyubldg(HttpServletRequest req, final String pnu, final String bno) {
		String rst = "";

		GetJeonyubldg svc = new GetJeonyubldg();
		rst = appendXmlDcl(svc.getData(pnu, bno));
		
		return Response.ok(rst, MediaType.APPLICATION_XML).build();
	}

	
	
	@GET
	@Path("/GetDjyexpos")
	public Response getDjyexpos_GET(@Context HttpServletRequest req, @QueryParam("pnu") final String pnu, @QueryParam("bno") final String bno) {
		return getDjyexpos(req, pnu, bno);
	}
	@POST
	@Path("/GetDjyexpos")
	public Response getDjyexpos_POST(@Context HttpServletRequest req, @FormParam("pnu") final String pnu, @FormParam("bno") final String bno) {
		return getDjyexpos(req, pnu, bno);
	}

	private Response getDjyexpos(HttpServletRequest req, final String pnu, final String bno) {
		String rst = "";

		GetDjyexpos svc = new GetDjyexpos();
		rst = appendXmlDcl(svc.getData(pnu, bno));
		
		return Response.ok(rst, MediaType.APPLICATION_XML).build();
	}

	
	
	
	private String appendXmlDcl(String xml) {
		return ( "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n" + xml );
	}
}
