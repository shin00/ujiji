package geomex.kras.gmx.svc;

import geomex.kras.common.*;
import geomex.kras.gmx.vo.DjyrecaptitleSet;
import geomex.kras.ivo.*;
import geomex.kras.vo.*;
import geomex.kras.bldg.*;

import java.io.StringWriter;
import java.util.ArrayList;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;


/**
 * 총괄표제부
 */
public class GetDjyrecaptitle {

	private BldgLedgGenHdsInfoService bldgLedgGenHdsInfoSvc = new BldgLedgGenHdsInfoService();
	private BldgDongInfoService bldgDongInfoSvc = new BldgDongInfoService();
	private CbldgHdsInfoService cbldgHdsInfoSvc = new CbldgHdsInfoService();

	
	public String getData(String pnu) {

		StringBuilder sb = new StringBuilder();
		
		BldgLedgGenHdsInfoDataSet res1 = bldgLedgGenHdsInfoSvc.getData(pnu);
		BldgLedgGenHdsInfo blghInfo = new BldgLedgGenHdsInfo();
		if ( res1 != null && res1.getBody() != null ) blghInfo = res1.getBody().getBldgLedgGenHdsInfo();


		BldgDongInfoDataSet res2 = bldgDongInfoSvc.getData(pnu);
		ArrayList<BldgDongInfo> bdList = new ArrayList<BldgDongInfo>();
		if ( res2 != null && res2.getBody() != null ) bdList = res2.getBody().getBldgDongInfoList(); 

		
		DjyrecaptitleSet rct = new DjyrecaptitleSet();
		
		ArrayList<DjyrecaptitleSet.Djytitle> titList;
		DjyrecaptitleSet.Djytitle tit;

		
		String jibunDesc = PnuUtils.toJibunString(pnu);
		if ( !( blghInfo.getLandCnt().getVal().equals("") || blghInfo.getLandCnt().getVal().equals("0") ) ) jibunDesc += ( "외 " + blghInfo.getLandCnt() + " 필지" );

		String hoCnt = ColUtils.formatNumber(blghInfo.getTotHehdCnt()) + "세대/ ";
		hoCnt += ( ColUtils.formatNumber(blghInfo.getTotHoCnt()) + "호/ " );
		hoCnt += ( ColUtils.formatNumber(blghInfo.getTotFmlyCnt()) + "가구" );
		
		String atchBld = ( ColUtils.formatNumber(blghInfo.getSubBldgCnt()) + "동 " + ColUtils.formatNumber(blghInfo.getSubBldgArea()) + "㎡" );


		rct.setDaejiPosition(Code.getJibunAddr(pnu)+" "+Code.pnuToJimok(pnu));
		rct.setJibunDesc(jibunDesc);
		rct.setDjyDongNm(blghInfo.getBldgNm().getVal());
		rct.setPlatArea(ColUtils.formatNumber(blghInfo.getLarea())+"㎡");
		rct.setTotArea(ColUtils.formatNumber(blghInfo.getGarea())+"㎡");
		rct.setMainBldCnt(blghInfo.getTotMainBldgCnt().getVal());
		rct.setArchArea(ColUtils.formatNumber(blghInfo.getBarea())+"㎡");
		rct.setVlRatEstmTotarea(ColUtils.formatNumber(blghInfo.getFsiCalcGarea())+"㎡");
		rct.setHoCnt(hoCnt);
		rct.setBcRat(ColUtils.formatNumber(blghInfo.getBlr())+"%");
		rct.setVlRat(ColUtils.formatNumber(blghInfo.getFsi())+"%");
		rct.setTotPkngCnt(ColUtils.formatNumber(blghInfo.getTotParkCnt()));
		rct.setMainPurpsCdNm(blghInfo.getMainUseNm().getVal());
		rct.setAtchBld(atchBld);
		rct.setSpCmt(blghInfo.getSpcItem().getVal());
		
		//동별현황리스트
		if ( bdList.size() > 0 ) {
			titList = new ArrayList<DjyrecaptitleSet.Djytitle>();
			
			for( int i = 0; i < bdList.size(); i++ ) {
				// 총괄 아닌 목록만 출력
				if ( !bdList.get(i).getBldgKindCd().getVal().equals("1") ) {
					BldgHdsInfoDataSet respo = cbldgHdsInfoSvc.getData(pnu, bdList.get(i).getBldgGbnNo().getVal());
					BldgHdsInfo bhInfo = new BldgHdsInfo();
					if ( respo != null && respo.getBody() != null ) bhInfo = respo.getBody().getBldgHdsInfoSet().getBldgHdsInfo();

					int flrCnt = 0;
					if ( bhInfo.getFloorInfoList() != null ) flrCnt = bhInfo.getFloorInfoList().size();
					
					tit = new DjyrecaptitleSet.Djytitle();
					
					tit.setMainAtchGbCdNm(bhInfo.getMainSubGbnNm().getVal());
					tit.setDongNm(bhInfo.getDong().getVal());
					tit.setStrctCdNm(bhInfo.getStruNm().getVal());
					tit.setRoofCdNm(bhInfo.getRoofNm().getVal());
					tit.setFlrCnt(flrCnt+"층");
					tit.setMainPurpsCdNm(bhInfo.getMainUseNm().getVal());
					tit.setTotarea(ColUtils.formatNumber(bhInfo.getGarea())+"㎡");
					
					titList.add(tit);
				}
			}
			rct.setDjytitleList(titList);
		}

/*
		sb.append("<총괄표제부>");

			sb.append("<대지위치>").append(Code.getJibunAddr(pnu)).append(" ").append(Code.pnuToJimok(pnu)).append("</대지위치>");
			sb.append("<지번>").append(PnuUtils.toJibunString(pnu));
				if ( !( blghInfo.getLandCnt().getVal().equals("") || blghInfo.getLandCnt().getVal().equals("0") ) ) sb.append("외 ").append(blghInfo.getLandCnt()).append(" 필지");
			sb.append("</지번>");
			sb.append("<명칭및번호>").append(blghInfo.getBldgNm()).append("</명칭및번호>");
			sb.append("<대지면적>").append(ColUtils.formatNumber(blghInfo.getLarea())).append("㎡").append("</대지면적>");
			sb.append("<연면적>").append(ColUtils.formatNumber(blghInfo.getGarea())).append("㎡").append("</연면적>");
			sb.append("<건축물수>").append(ColUtils.formatNumber(blghInfo.getTotMainBldgCnt())).append("</건축물수>");
			sb.append("<건축면적>").append(ColUtils.formatNumber(blghInfo.getBarea())).append("㎡").append("</건축면적>");
			sb.append("<용적률산정연면적>").append(ColUtils.formatNumber(blghInfo.getFsiCalcGarea())).append("㎡").append("</용적률산정연면적>");
			sb.append("<총호수>").append(ColUtils.formatNumber(blghInfo.getTotHehdCnt())).append("세대/ ")
				.append(ColUtils.formatNumber(blghInfo.getTotHoCnt())).append("호/ ")
				.append(ColUtils.formatNumber(blghInfo.getTotFmlyCnt())).append("가구").append("</총호수>");
			sb.append("<건폐율>").append(ColUtils.formatNumber(blghInfo.getBlr())).append("%").append("</건폐율>");
			sb.append("<용적율>").append(ColUtils.formatNumber(blghInfo.getFsi())).append("%").append("</용적율>");
			sb.append("<총주차대수>").append(ColUtils.formatNumber(blghInfo.getTotParkCnt())).append("</총주차대수>");
			sb.append("<주용도>").append(blghInfo.getMainUseNm()).append("</주용도>");
			sb.append("<부속건축물>").append(ColUtils.formatNumber(blghInfo.getSubBldgCnt())).append("동 ")
				.append(ColUtils.formatNumber(blghInfo.getSubBldgArea())).append("㎡").append("</부속건축물>");
			sb.append("<특이사항>").append(blghInfo.getSpcItem()).append("</특이사항>");

			if ( bdList.size() > 0 ) {
				sb.append("<동별현황리스트>");
				for( int i = 0; i < bdList.size(); i++ ) {
					// 총괄 아닌 목록만 출력
					if ( !bdList.get(i).getBldgKindCd().getVal().equals("1") ) {
						BldgHdsInfoDataSet respo = cbldgHdsInfoSvc.getData(pnu, bdList.get(i).getBldgGbnNo().getVal());
						BldgHdsInfo bhInfo = new BldgHdsInfo();
						if ( respo != null && respo.getBody() != null ) bhInfo = respo.getBody().getBldgHdsInfoSet().getBldgHdsInfo();

						int flr = 0;
						if ( bhInfo.getFloorInfoList() != null ) flr = bhInfo.getFloorInfoList().size();
						sb.append("<동별현황>");
					 		sb.append("<구분>").append(bhInfo.getMainSubGbnNm()).append("</구분>");
					 		sb.append("<건축물명칭>").append(bhInfo.getDong()).append("</건축물명칭>");
							sb.append("<구조>").append(bhInfo.getStruNm()).append("</구조>");
							sb.append("<지붕>").append(bhInfo.getRoofNm()).append("</지붕>");
							sb.append("<층수>").append(flr).append("층").append("</층수>");
							sb.append("<용도>").append(bhInfo.getMainUseNm()).append("</용도>");
							sb.append("<면적>").append(ColUtils.formatNumber(bhInfo.getGarea())).append("㎡").append("</면적>");
						sb.append("</동별현황>");
					}
				}
				sb.append("</동별현황리스트>");
			}

			sb.append("<옥내_기계식_대수>").append("").append("</옥내_기계식_대수>");
			sb.append("<옥내_기계식_면적>").append("").append("</옥내_기계식_면적>");
			sb.append("<옥외_기계식_대수>").append("").append("</옥외_기계식_대수>");
			sb.append("<옥외_기계식_면적>").append("").append("</옥외_기계식_면적>");
			sb.append("<옥내_자주식_대수>").append("").append("</옥내_자주식_대수>");
			sb.append("<옥내_자주식_면적>").append("").append("</옥내_자주식_면적>");
			sb.append("<옥외_자주식_대수>").append("").append("</옥외_자주식_대수>");
			sb.append("<옥외_자주식_면적>").append("").append("</옥외_자주식_면적>");
			sb.append("<에너지효율_등급>").append("").append("</에너지효율_등급>");
			sb.append("<에너지효율_절감율>").append("").append("</에너지효율_절감율>");
			sb.append("<에너지성능지표_점>").append("").append("</에너지성능지표_점>");
			sb.append("<친환경건축물인증_등급>").append("").append("</친환경건축물인증_등급>");
			sb.append("<친환경건축물인증_점>").append("").append("</친환경건축물인증_점>");
			sb.append("<지능형건축물인증_등급>").append("").append("</지능형건축물인증_등급>");
			sb.append("<지능형건축물인증_점>").append("").append("</지능형건축물인증_점>");

		sb.append("</총괄표제부>");
*/

        StringWriter sw = new StringWriter();
		try {

	        JAXBContext jc = JAXBContext.newInstance(DjyrecaptitleSet.class);

	        Marshaller marshaller = jc.createMarshaller();
	        marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
	        marshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
	        marshaller.marshal(rct, sw);
	        
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}

        sb.append(sw.toString());

		return sb.toString();
	
	}

}
