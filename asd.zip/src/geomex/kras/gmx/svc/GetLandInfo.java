package geomex.kras.gmx.svc;

import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import org.apache.commons.lang3.StringUtils;

import geomex.kras.common.*;
import geomex.kras.gmx.vo.LandInfoSet;
import geomex.kras.ivo.*;
import geomex.kras.vo.*;
import geomex.kras.land.*;


/**
 * 토지 기본정보
 */
public class GetLandInfo {

	private LandInfoService landInfoSvc = new LandInfoService();

	
	public String getData(String pnu) {

		StringBuilder sb = new StringBuilder();
		
		LandInfoDataSet res = landInfoSvc.getData(pnu);
		
		LandInfo li = new LandInfo();
		if ( res != null && res.getBody() != null ) li = res.getBody().getLandInfo(); 
		
		String ownGbn = StringUtils.trimToEmpty(li.getOwnGbn().getVal());
		if ( ownGbn.length() > 1 ) ownGbn = ownGbn.substring(1);
		
		LandInfoSet liSet = new LandInfoSet();
		
		LandInfoSet.LandInfo oli = liSet.getLandInfo();
		
		oli.setMapNoBono(li.getDoho().getVal());
		oli.setMapNoBuno("");
		oli.setScaleCode(li.getScale().getVal());
		oli.setScaleNm(li.getScaleNm().getVal());
		oli.setJimk(li.getJimok().getVal());
		oli.setJimkNm(li.getJimokNm().getVal());
		oli.setArea(li.getParea().getVal());
		oli.setLandMoveWhyCode(li.getLandMovRsnCd().getVal());
		oli.setLandMoveWhyCodeNm(li.getLandMovRsnCdNm().getVal());
		oli.setLandMoveYmd(li.getLandMovYmd().getVal());
		oli.setLandMoveRellJibn(li.getLandMoveRellJibn().getVal());
		oli.setBsinEnfNtGbn(li.getBizActNtcGbn().getVal());
		oli.setOwnspChCauGbn(li.getOwnRgtChgRsnCd().getVal());
		oli.setOwnspChCauGbnNm(li.getOwnRgtChgRsnCdNm().getVal());
		oli.setOwnrRegNo(li.getDregno().getVal());
		oli.setOwnrRegSno("");
		oli.setOwnGbn(ownGbn);
		oli.setOwnGbnNm(li.getOwnGbnNm().getVal());
		oli.setShapNum(li.getShrCnt().getVal());
		oli.setOwnrNm(li.getOwnerNm().getVal());
		oli.setOwnrAddr(li.getOwnerAddr().getVal());
		oli.setLandLastOrd(li.getLandLastHistOdrno().getVal());
		oli.setOwnspChHistLastOrd(li.getOwnRgtLastHistOdrno().getVal());
		oli.setRellCoBdngSno(li.getBldgGbnNo().getVal());
		oli.setLv(li.getGrd().getVal());
		oli.setLvChYmd(ColUtils.formatDate(li.getGrdYmd()));
		
		liSet.setJiga(ColUtils.formatNumber(li.getPannJiga())+"원 ("+li.getJigaBaseMon()+"기준)");
		liSet.setAddr(Code.getJibunAddr(pnu));
		
		
/*		
        sb.append("<일필지기본목록>");

        	sb.append("<일필지기본>");
				sb.append("<도호>").append(li.getDoho()).append("</도호>");
				sb.append("<도호순번>").append("").append("</도호순번>");
				sb.append("<축척코드>").append(li.getScale()).append("</축척코드>");
				sb.append("<축척명>").append(li.getScaleNm()).append("</축척명>");
				sb.append("<지목>").append(li.getJimok()).append("</지목>");
				sb.append("<지목명>").append(li.getJimokNm()).append("</지목명>");
				sb.append("<면적>").append(li.getParea()).append("</면적>");
				sb.append("<최종토지이동사유코드>").append(li.getLandMovRsnCd()).append("</최종토지이동사유코드>");
				sb.append("<최종토지이동사유>").append(li.getLandMovRsnCdNm()).append("</최종토지이동사유>");
				sb.append("<최종토지이동일자>").append(li.getLandMovYmd()).append("</최종토지이동일자>");
				sb.append("<토지이동관련지번>").append(li.getLandMoveRellJibn()).append("</토지이동관련지번>");
				sb.append("<사업시행신고구분>").append(li.getBizActNtcGbn()).append("</사업시행신고구분>");
				sb.append("<최종소유권변동사유코드>").append(li.getOwnRgtChgRsnCd()).append("</최종소유권변동사유코드>");
				sb.append("<최종소유권변동사유>").append(li.getOwnRgtChgRsnCdNm()).append("</최종소유권변동사유>");
				sb.append("<최종소유권변동일자>").append(li.getOwndymd()).append("</최종소유권변동일자>");
				sb.append("<소유자등록번호>").append(li.getDregno()).append("</소유자등록번호>");
				sb.append("<소유자등록일련번호>").append("").append("</소유자등록일련번호>");
				sb.append("<소유구분코드>").append(li.getOwnGbn().getVal().substring(1)).append("</소유구분코드>");
				sb.append("<소유구분명>").append(li.getOwnGbnNm()).append("</소유구분명>");
				sb.append("<공유인수>").append(ColUtils.formatNumber(li.getShrCnt())).append("</공유인수>");
				sb.append("<소유자명>").append(li.getOwnerNm()).append("</소유자명>");
				sb.append("<소유자주소>").append(li.getOwnerAddr()).append("</소유자주소>");
				sb.append("<최종토지이동연혁순번>").append(li.getLandLastHistOdrno()).append("</최종토지이동연혁순번>");
				sb.append("<최종소유권변동연혁순번>").append(li.getOwnRgtLastHistOdrno()).append("</최종소유권변동연혁순번>");
				sb.append("<관련집합건물>").append(li.getBldgGbnNo()).append("</관련집합건물>");
				sb.append("<토지등급>").append(li.getGrd()).append("</토지등급>");
				sb.append("<토지등급변동일자>").append(ColUtils.formatDate(li.getGrdYmd())).append("</토지등급변동일자>");
			sb.append("</일필지기본>");
			sb.append("<공시지가>").append(ColUtils.formatNumber(li.getPannJiga())).append("원 (").append(li.getJigaBaseMon()).append("기준)").append("</공시지가>");
			sb.append("<소재지>").append(Code.getJibunAddr(pnu)).append("</소재지>");

	    sb.append("</일필지기본목록>");
*/
		
        StringWriter sw = new StringWriter();
		try {

	        JAXBContext jc = JAXBContext.newInstance(LandInfoSet.class);

	        Marshaller marshaller = jc.createMarshaller();
	        marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
	        marshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
	        marshaller.marshal(liSet, sw);
	        
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}

        sb.append(sw.toString());

		return sb.toString();
	
	}

}
