package geomex.kras.gmx.svc;

import geomex.kras.common.*;
import geomex.kras.gmx.vo.UseZoneList;
import geomex.kras.ivo.*;
import geomex.kras.vo.*;
import geomex.kras.land.*;

import java.io.StringWriter;
import java.util.ArrayList;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;


/**
 * 용도지역지구목록
 */
public class GetUseZoneList {

	private LandUsePlanAttrService landUsePlanAttrSvc = new LandUsePlanAttrService();
	
	
	public String getData(String pnu) {

		StringBuilder sb = new StringBuilder();
		
		LandUsePlanAttrDataSet res = landUsePlanAttrSvc.getData(pnu);
		
		ArrayList<LandUsePlanAttr> lupList = new ArrayList<LandUsePlanAttr>();
		if ( res != null && res.getBody() != null ) lupList = res.getBody().getLandUsePlanAttrList(); 


		UseZoneList uzl = new UseZoneList();

		ArrayList<UseZoneList.UseZoneInfo> uziList = new ArrayList<UseZoneList.UseZoneInfo>();
		UseZoneList.UseZoneInfo uzi;
		for( int i = 0; i < lupList.size(); i++ ) {
			
			uzi = new UseZoneList.UseZoneInfo();

			uzi.setUcode(lupList.get(i).getUcode().getVal());
			uzi.setDivno(lupList.get(i).getDivno().getVal());
			uzi.setGubun(lupList.get(i).getGubun().getVal());
			uzi.setCtype(lupList.get(i).getCtype().getVal());
			uzi.setUnm(lupList.get(i).getUnm().getVal());
			uzi.setSeq(lupList.get(i).getSeq().getVal());
			uzi.setLawNm(lupList.get(i).getLawnm().getVal());
			uzi.setUname(lupList.get(i).getUname().getVal());
			
			uziList.add(uzi);
		}
		uzl.setAllPlanList(uziList);

		
		
        StringWriter sw = new StringWriter();
		try {

	        JAXBContext jc = JAXBContext.newInstance(UseZoneList.class);

	        Marshaller marshaller = jc.createMarshaller();
	        marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
	        marshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
	        marshaller.marshal(uzl, sw);
	        
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}

        sb.append(sw.toString());

		
		return sb.toString();
	
	}

}
