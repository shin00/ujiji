﻿package geomex.kras.gmx.svc;

import geomex.kras.land.LandBldgCheckService;;


/**
 * 토지,건물 존재 여부
 */
public class GetLandBldgChk {
	
	LandBldgCheckService svc = new LandBldgCheckService();

	/**
	 * @param pnu
	 * @return
	 *         -1 : 토지없음
	 *          1 : 토지있음
	 *          2 : 토지,건물있음 
	 */
	public int getStat(String pnu) {

		return svc.getStat(pnu);
	
	}
}
