package geomex.kras.gmx.svc;

import geomex.kras.common.*;
import geomex.kras.gmx.vo.DjytitleSet;
import geomex.kras.ivo.*;
import geomex.kras.vo.*;
import geomex.kras.bldg.*;

import java.io.StringWriter;
import java.util.ArrayList;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;


/**
 * 표제부를 정보를 가지고온다.
 */
public class GetDjytitle {

	private BldgHdsInfoService bldgHdsInfoSvc = new BldgHdsInfoService();
	private CbldgHdsInfoService cbldgHdsInfoSvc = new CbldgHdsInfoService();

	
	public String getData(String pnu, String bno) {

		StringBuilder sb = new StringBuilder();
		
		/**
		 * 건물종류
		 *  2 : 일반건축물
		 *  3 : 집합건축물(표제부)
		 */
		String bldgKind = "";
		
		BldgHdsInfo bhInfo = new BldgHdsInfo();

		BldgHdsInfoDataSet res = bldgHdsInfoSvc.getData(pnu, bno);
		if ( res != null && res.getBody() != null ) {

			bhInfo = res.getBody().getBldgHdsInfoSet().getBldgHdsInfo();

			if ( "2".equals(bhInfo.getBldgKindCd().getVal()) ) {
				//일반건축물
				bldgKind = "2";

			} else {
				res = cbldgHdsInfoSvc.getData(pnu, bno);
				if ( res != null && res.getBody() != null ) {
					//집합건축물(표제부)
					bldgKind = "3";
					bhInfo = res.getBody().getBldgHdsInfoSet().getBldgHdsInfo();
				}
			}
		}

		int flrCnt = 0;
		
		DjytitleSet tit = new DjytitleSet();
		
		
		tit.setKindName(Code.getBldgKindNm(bldgKind));	// "일반건축물" or "표제부"
		tit.setDaejiPosition(Code.getJibunAddr(pnu)+" "+Code.pnuToJimok(pnu));
		tit.setJibun(PnuUtils.toJibunString(pnu)+"외 "+bhInfo.getLandCnt().getVal()+"필지");
		tit.setDjyDongNm(bhInfo.getDong().getVal());
		tit.setPlatArea(ColUtils.formatNumber(bhInfo.getLarea())+"㎡");
		tit.setTotArea(ColUtils.formatNumber(bhInfo.getGarea())+"㎡");
		tit.setHoCnt(bhInfo.getHoCnt().getVal());
		tit.setArchArea(ColUtils.formatNumber(bhInfo.getBarea())+"㎡");
		tit.setVlRatEstmTotarea(ColUtils.formatNumber(bhInfo.getFsiCalcGarea())+"㎡");
		//tit.setFlrCnt(flrCnt+"층");
		tit.setBcRat(ColUtils.formatNumber(bhInfo.getDongBlr())+"%");
		tit.setVlRat(ColUtils.formatNumber(bhInfo.getFsi())+"%");
		tit.setHeit(ColUtils.formatNumber(bhInfo.getHgt())+"m");
		tit.setMainPurpsCdNm(bhInfo.getMainUseNm().getVal());
		tit.setAtchBld(ColUtils.formatNumber(bhInfo.getSubBldgCnt())+"동 "+ColUtils.formatNumber(bhInfo.getSubBldgArea())+"㎡");
		tit.setStrctCdNm(bhInfo.getStruNm().getVal());
		tit.setRoofCdNm(bhInfo.getRoofNm().getVal());
		tit.setPmsDay("");
		tit.setStcnsDay("");
		tit.setUseaprDay("");
		
		
		//층별현황리스트
		ArrayList<DjytitleSet.Djyflrouln> flrList;
		DjytitleSet.Djyflrouln flr;
		if ( bhInfo.getFloorInfoList() != null && bhInfo.getFloorInfoList().size() > 0 ) {
			BldgHdsInfo.FloorInfoList flrInfo;
			
			flrCnt = bhInfo.getFloorInfoList().size();
			tit.setFlrCnt(flrCnt+"층");

		 	flrList = new ArrayList<DjytitleSet.Djyflrouln>();
		 	
			for ( int i = 0; i < bhInfo.getFloorInfoList().size(); i++ ) {
				flrInfo = bhInfo.getFloorInfoList().get(i);
				
				flr = new DjytitleSet.Djyflrouln();
				
				flr.setFlrGbCdNm(flrInfo.getMainSubGbnNm().getVal().substring(0, 1)+flrInfo.getMainSubSeqno().getVal());
				flr.setFlrNoNm(flrInfo.getFlr().getVal());
				flr.setStrctCdNm(flrInfo.getEtcStru().getVal());
				flr.setEtcPurps(flrInfo.getEtcUse().getVal());
				flr.setArea(ColUtils.formatNumber(flrInfo.getBtmArea())+"㎡");

				flrList.add(flr);
			}
			
			tit.setDjyflroulnList(flrList);
		}
		
		//소유자현황리스트
		ArrayList<DjytitleSet.OwnerInfo> ownList;
		DjytitleSet.OwnerInfo own;
		if ( bhInfo.getUserInfoList() != null && bhInfo.getUserInfoList().size() > 0 && bldgKind.equals("2") ) {
			BldgHdsInfo.UserInfoList userInfo;
			
			ownList = new ArrayList<DjytitleSet.OwnerInfo>();
			
			for ( int i = 0; i < bhInfo.getUserInfoList().size(); i++ ) {
				userInfo = bhInfo.getUserInfoList().get(i);
				
				own = new DjytitleSet.OwnerInfo();
				
				own.setChgYmd(userInfo.getChgYmd().getVal());
				own.setOwnerNm(userInfo.getOwnerNm().getVal());
				own.setDregno(userInfo.getDregno().getVal());
				own.setDetlAddr(userInfo.getDetlAddr().getVal());
				own.setLastYn(userInfo.getLastYn().getVal());
				own.setChgRsnNm(userInfo.getChgRsnNm().getVal());
				own.setOwnGbnNm(userInfo.getOwnGbnNm().getVal());
				own.setResGbnNm(userInfo.getResGbnNm().getVal());
				own.setRegtYn(userInfo.getRegtYn().getVal());
				own.setJibunDesc(userInfo.getJibunDesc().getVal());

				ownList.add(own);
			}
			
			tit.setOwnerInfoList(ownList);
		}
		
		
/*		
		sb.append("<표제부>");

			sb.append("<표제부_일반건축물>").append(Code.getBldgKindNm(bldgKind)).append("</표제부_일반건축물>");	// "일반건축물" or "표제부"
			sb.append("<대지위치>").append(Code.getJibunAddr(pnu)).append(" ").append(Code.pnuToJimok(pnu)).append("</대지위치>");
			sb.append("<명칭및번호>").append(bhInfo.getDong()).append("</명칭및번호>");
			sb.append("<대지면적>").append(ColUtils.formatNumber(bhInfo.getLarea())).append("㎡").append("</대지면적>");
			sb.append("<연면적>").append(ColUtils.formatNumber(bhInfo.getGarea())).append("㎡").append("</연면적>");
			sb.append("<호수>").append(bhInfo.getHoCnt()).append("</호수>");
			sb.append("<건축면적>").append(ColUtils.formatNumber(bhInfo.getBarea())).append("㎡").append("</건축면적>");
			sb.append("<용적률산정용연면적>").append(ColUtils.formatNumber(bhInfo.getFsiCalcGarea())).append("㎡").append("</용적률산정용연면적>");
			
			//sb.append("<층수>").append("지하 ").append("").append("층/ 지상 ").append("").append("층").append("</층수>");
			if ( bhInfo.getFloorInfoList() != null ) flrCnt = bhInfo.getFloorInfoList().size();
			sb.append("<층수>").append(flrCnt).append("층").append("</층수>");

			sb.append("<건폐율>").append(ColUtils.formatNumber(bhInfo.getDongBlr())).append("%").append("</건폐율>");
			sb.append("<용적율>").append(ColUtils.formatNumber(bhInfo.getFsi())).append("%").append("</용적율>");
			sb.append("<높이>").append(ColUtils.formatNumber(bhInfo.getHgt())).append("m").append("</높이>");
			sb.append("<주용도>").append(bhInfo.getMainUseNm()).append("</주용도>");
			sb.append("<부속건축물>").append(ColUtils.formatNumber(bhInfo.getSubBldgCnt())).append("동 ")
				.append(ColUtils.formatNumber(bhInfo.getSubBldgArea())).append("㎡").append("</부속건축물>");
			sb.append("<주구조>").append(bhInfo.getStruNm()).append("</주구조>");
			sb.append("<지붕구조>").append(bhInfo.getRoofNm()).append("</지붕구조>");
			sb.append("<허가일자>").append("").append("</허가일자>");
			sb.append("<착공일자>").append("").append("</착공일자>");
			sb.append("<사용승인일자>").append("").append("</사용승인일자>");

			if ( bhInfo.getFloorInfoList() != null && bhInfo.getFloorInfoList().size() > 0 ) {
			 	sb.append("<층별현황리스트>");
				for ( int i = 0; i < bhInfo.getFloorInfoList().size(); i++ ) {
					BldgHdsInfo.FloorInfoList flrInfo = bhInfo.getFloorInfoList().get(i);
					sb.append("<층별현황>");
				 		sb.append("<구분>").append(flrInfo.getFlrGbnCd()).append("</구분>");
				 		sb.append("<층별>").append(flrInfo.getFlr()).append("</층별>");
				 		sb.append("<구조>").append(flrInfo.getStruNm()).append("</구조>");
				 		sb.append("<용도>").append(flrInfo.getMainUseNm()).append("</용도>");
				 		sb.append("<면적>").append(ColUtils.formatNumber(flrInfo.getBtmArea())).append("㎡").append("</면적>");
					sb.append("</층별현황>");
				}
				sb.append("</층별현황리스트>");
			}
			
			sb.append("<옥내_기계식_대수>").append("").append("</옥내_기계식_대수>");
			sb.append("<옥내_기계식_면적>").append("").append("</옥내_기계식_면적>");
			sb.append("<옥외_기계식_대수>").append("").append("</옥외_기계식_대수>");
			sb.append("<옥외_기계식_면적>").append("").append("</옥외_기계식_면적>");
			sb.append("<옥내_자주식_대수>").append("").append("</옥내_자주식_대수>");
			sb.append("<옥내_자주식_면적>").append("").append("</옥내_자주식_면적>");
			sb.append("<옥외_자주식_대수>").append("").append("</옥외_자주식_대수>");
			sb.append("<옥외_자주식_면적>").append("").append("</옥외_자주식_면적>");
			sb.append("<승용>").append("").append("대").append("</승용>");
			sb.append("<비상용>").append("").append("대").append("</비상용>");
			sb.append("<에너지효율_등급>").append("").append("</에너지효율_등급>");
			sb.append("<에너지효율_절감율>").append("").append("</에너지효율_절감율>");
			sb.append("<에너지성능지표_점>").append("").append("</에너지성능지표_점>");
			sb.append("<친환경건축물인증_등급>").append("").append("</친환경건축물인증_등급>");
			sb.append("<친환경건축물인증_점>").append("").append("</친환경건축물인증_점>");
			sb.append("<지능형건축물인증_등급>").append("").append("</지능형건축물인증_등급>");
			sb.append("<지능형건축물인증_점>").append("").append("</지능형건축물인증_점>");
	 	
		sb.append("</표제부>");
*/	

        StringWriter sw = new StringWriter();
		try {

	        JAXBContext jc = JAXBContext.newInstance(DjytitleSet.class);

	        Marshaller marshaller = jc.createMarshaller();
	        marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
	        marshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
	        marshaller.marshal(tit, sw);
	        
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}

        sb.append(sw.toString());

		return sb.toString();
	
	}
}
