package geomex.kras.gmx.svc;

import java.io.StringWriter;
import java.util.ArrayList;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import geomex.kras.common.*;
import geomex.kras.gmx.vo.*;
import geomex.kras.ivo.*;
import geomex.kras.vo.*;
import geomex.kras.land.*;


/**
 * 토지대장 프린트 2
 */
public class GetTojiDaejangPrint2 {

	private LandInfoService landInfoSvc = new LandInfoService();
	private LandMovHistService landMovHistSvc = new LandMovHistService();
	private OwnRgtHistService ownRgtHistSvc = new OwnRgtHistService();
	private LandJigaService landJigaSvc = new LandJigaService();
	private ShrYmbService shrYmbSvc = new ShrYmbService();

	String lastJimok = "";
	String lastArea = "";
	String lastMoveWhyCode = "";
	String lastMoveYmd = "";
	
	public String getData(String pnu, String user) {

		StringBuilder sb = new StringBuilder();
		
		String[] punArr = PnuUtils.splitArr(pnu);
		
		LandInfoDataSet res1 = landInfoSvc.getData(pnu);
		LandInfo li = new LandInfo();
		if ( res1 != null && res1.getBody() != null ) li = res1.getBody().getLandInfo(); 

		
		LandMovHistDataSet res2 = landMovHistSvc.getData(pnu);
		ArrayList<LandMovHist> lmhList = new ArrayList<LandMovHist>(); 
		if ( res2 != null && res2.getBody() != null ) lmhList = res2.getBody().getLandMovHistList();
		

		OwnRgtHistDataSet res3 = ownRgtHistSvc.getData(pnu);
		ArrayList<OwnRgtHist> orhList = new ArrayList<OwnRgtHist>(); 
		if ( res3 != null && res3.getBody() != null ) orhList = res3.getBody().getOwnRgtHistList();
		
		
		LandJigaDataSet res4 = landJigaSvc.getData(pnu);
		ArrayList<LandJiga.JigaList> ljList = new ArrayList<LandJiga.JigaList>(); 
		if ( res4 != null && res4.getBody() != null ) ljList = res4.getBody().getLandJiga().getJigaList();

		
		ShrYmbDataSet res5 = shrYmbSvc.getData(pnu);
		ArrayList<ShrYmb> syList = new ArrayList<ShrYmb>();
		if ( res5 != null && res5.getBody() != null ) syList = res5.getBody().getShrYmbList(); 


		TojiDaejang2Set tds = new TojiDaejang2Set();

		//토지이동연혁
		if ( lmhList.get(0) != null ) {
			lastJimok = lmhList.get(0).getJimok().getVal();
			lastArea = lmhList.get(0).getParea().getVal();
			lastMoveWhyCode = lmhList.get(0).getLandMovRsnCd().getVal();
			lastMoveYmd = lmhList.get(0).getDymd().getVal();

			setLandMovHist(tds.getLandMovHist(), lmhList.get(0));
		}
		
		//토지이동연혁목록
		LandMovHistList lmhl = new LandMovHistList();
		ArrayList<LandMovHistList.LandMovHist> oLmhList = lmhl.getLandMovHistList();
		LandMovHistList.LandMovHist lmh;
		for ( int i = 0; i < lmhList.size(); i++ ) {
	 		
			lmh = new LandMovHistList.LandMovHist();

			setLandMovHist(lmh, lmhList.get(i));
			
			oLmhList.add(lmh);
		}
		tds.setLandMovHistList(lmhl);

		//소유권변동연혁목록
		OwnHistList ohl = new OwnHistList();
		ArrayList<OwnHistList.OwnHist> oOhList = ohl.getOwnHistList();
		OwnHistList.OwnHist oh;
		for ( int i = 0; i < orhList.size(); i++ ) {
	 		
			oh = new OwnHistList.OwnHist();

			setOwnHist(oh, orhList.get(i));
			
			if ( i == 0 ) oh.setOwnrAddr(li.getOwnerAddr().getVal());
			
			oOhList.add(oh);
		}
		tds.setOwnHistList(ohl);
		
		//개별공시지가목록
		JigaInfoList2 jgl = new JigaInfoList2();
		ArrayList<JigaInfoList2.JigaInfo> oJgList = jgl.getJigaList();
		JigaInfoList2.JigaInfo jg;
		for ( int i = 0; i < ljList.size(); i++ ) {
			jg = new JigaInfoList2.JigaInfo();
			
			jg.setBaseYear(ljList.get(i).getBaseYear().getVal());
			jg.setJiga(ljList.get(i).getPannJiga().getVal());
			
			oJgList.add(jg);
		}
		tds.setJigaList(jgl);
		
		//공유지연명부목록
		ShareInfoList sil = new ShareInfoList(); 
		ArrayList<ShareInfoList.ShareInfo> oSiList = sil.getShareInfoList();
		ShareInfoList.ShareInfo si;
		for ( int i = 0; i < syList.size(); i++ ) {
			si = new ShareInfoList.ShareInfo();

			setShareInfo(si, syList.get(i));

			oSiList.add(si);
		}
		tds.setShareInfoList(sil);
		
		
        StringWriter sw = new StringWriter();
		try {

	        JAXBContext jc = JAXBContext.newInstance(TojiDaejang2Set.class);

	        Marshaller marshaller = jc.createMarshaller();
	        marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
	        marshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
	        marshaller.marshal(tds, sw);
	        
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}

        sb.append(sw.toString());

		
		return sb.toString();
	
	}
	
	
	private void setLandMovHist(LandMovHistList.LandMovHist des, LandMovHist src) {
		des.setMapNoBono(src.getDoho().getVal());
		des.setMapNoBuno("");
		des.setScaleCode(src.getScale().getVal());
		des.setScaleCodeNm(src.getScaleNm().getVal());
		des.setJimkCode(lastJimok);
		des.setArea(lastArea);
		des.setLandMoveWhyCode(lastMoveWhyCode);
		des.setLandMoveYmd(lastMoveYmd);
		des.setLandHistOrd(src.getLandHistOdrno().getVal());
		des.setJimkCode1(src.getJimok().getVal());
		des.setJimkNm1(src.getJimokNm().getVal());
		des.setArea1(src.getParea().getVal());
		des.setLandMoveWhyCode1(src.getLandMovRsnCd().getVal());
		des.setLandMoveWhyNm1(src.getLandMovRsnCdNm().getVal());
		des.setLandMoveYmd1(src.getDymd().getVal());
		
		StringBuilder relJibun = new StringBuilder();
		for ( int i = 0; i < src.getJibun().size(); i++ ) {
			if ( i > 0 ) relJibun.append(", ");
			relJibun.append(src.getJibun().get(i).getVal());
		}
		des.setLandMoveRellJibn(relJibun.toString());
		
	}
	
	private void setOwnHist(OwnHistList.OwnHist des, OwnRgtHist src) {
		des.setOwnspChHistOrd(src.getDodrno().getVal());
		des.setOwnspChCauGbn(src.getOwnRgtChgRsnCd().getVal());
		des.setOwnspChCauGbnNm(src.getOwnRgtChgRsnCdNm().getVal());
		des.setOwnspChYmd(src.getDymd().getVal());
		des.setOwnrRegSno(src.getDregno().getVal());
		des.setOwnrNm(src.getOwnerNm().getVal());
		des.setOwnrAddr("");
		des.setOwnGbn(src.getOwnGbn().getVal());
		des.setOwnGbnNm(src.getOwnGbnNm().getVal());
		des.setShapNum(src.getShrCnt().getVal());
		des.setOwnspChrNo(src.getOwnRgtChgChrgManId().getVal());
		des.setTransYmd("");
	}
	
	private void setShareInfo(ShareInfoList.ShareInfo des, ShrYmb src) {
		des.setShapSno(src.getShrSeqno().getVal());
		des.setOwnspChCauGbn(src.getOwnRgtChgRsnCd().getVal());
		des.setOwnspChCauGbnNm(src.getOwnRgtChgRsnNm().getVal());
		des.setOwnspChYmd(src.getOwnRgtChgYmd().getVal());
		des.setOwnrRegNo(src.getOwnerRegno().getVal());
		des.setOwnrNm(src.getOwnerNm().getVal());
		des.setOwnrAddr(src.getOwnerAddr().getVal());
		des.setOwnspCosm(src.getOwnRgtJibun().getVal());
		des.setTransYmd(src.getOwnRgtChgDelYmd().getVal());
		des.setOwnGbn(src.getOwnGbn().getVal());
		des.setOwnGbnNm(src.getOwnGbnNm().getVal());
	}
}
