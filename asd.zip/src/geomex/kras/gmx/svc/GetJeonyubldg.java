package geomex.kras.gmx.svc;

import geomex.kras.common.*;
import geomex.kras.gmx.vo.JeonyubldgSet;
import geomex.kras.ivo.*;
import geomex.kras.vo.*;
import geomex.kras.bldg.*;

import java.io.StringWriter;
import java.util.ArrayList;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;


/**
 * 전유부의 호명칭과 키값(건물번호)을 가지고온다.
 */
public class GetJeonyubldg {

	private BldgHoInfoService bldgHoInfoSvc = new BldgHoInfoService();

	
	public String getData(String pnu, String bno) {

		StringBuilder sb = new StringBuilder();
		
		String[] pnuArr = PnuUtils.splitArr(pnu);
		
		ArrayList<BldgHoInfo> hiList = new ArrayList<BldgHoInfo>();
		hiList.add(new BldgHoInfo());

		BldgHoInfoDataSet res = bldgHoInfoSvc.getData(pnu, bno);
		if ( res != null && res.getBody() != null ) hiList = res.getBody().getBldgHoInfoList();


		JeonyubldgSet jbd = new JeonyubldgSet();
		ArrayList<JeonyubldgSet.HoName> hoList = new ArrayList<JeonyubldgSet.HoName>();
		JeonyubldgSet.HoName ho;
		
		
		jbd.setDaejiPosition(Code.getJibunAddr(pnu)+" "+Code.pnuToJimok(pnu));
		jbd.setDongNm(hiList.get(0).getDongNm().getVal());
		jbd.setKey(pnuArr[0]+"-"+bno);
		jbd.setBno(bno);
		
		for ( int i = 0; i < hiList.size(); i++ ) {
			BldgHoInfo hoInfo = hiList.get(i);
			
			ho = new JeonyubldgSet.HoName();
			
			ho.sethKey(pnuArr[0]+"-"+hoInfo.getBldgGbnNo());
			ho.setBno(hoInfo.getBldgGbnNo().getVal());
			ho.setVal(hoInfo.getFlrHoNm().getVal());
			
			hoList.add(ho);
		}
		jbd.setHoNameList(hoList);
		
/*		
		sb.append("<전유부>");
		
			sb.append("<대지위치>").append(Code.getJibunAddr(pnu)).append(" ").append(Code.pnuToJimok(pnu)).append("</대지위치>");
			sb.append("<명칭및번호>").append(hiList.get(0).getDongNm()).append("</명칭및번호>");
			sb.append("<KEY>").append(pnuArr[0]).append("-").append(bno).append("</KEY>");
			sb.append("<호명칭리스트>");	
			for ( int i = 0; i < hiList.size(); i++ ) {
				BldgHoInfo hoInfo = hiList.get(i);
				sb.append("<호명칭 H_KEY=\"").append(pnuArr[0]).append("-").append(hoInfo.getBldgGbnNo())
					.append("\" bno=\"").append(hoInfo.getBldgGbnNo()).append("\">")
					.append(hoInfo.getFlrHoNm()).append("</호명칭>");	 	
			}
			sb.append("</호명칭리스트>");
			
		sb.append("</전유부>");
*/
		
        StringWriter sw = new StringWriter();
		try {

	        JAXBContext jc = JAXBContext.newInstance(JeonyubldgSet.class);

	        Marshaller marshaller = jc.createMarshaller();
	        marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
	        marshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
	        marshaller.marshal(jbd, sw);
	        
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}

        sb.append(sw.toString());
		
		return sb.toString();
	
	}

}
