package geomex.kras.gmx.svc;

import geomex.kras.common.*;
import geomex.kras.gmx.vo.BldgInfoSet;
import geomex.kras.ivo.*;
import geomex.kras.vo.*;
import geomex.kras.bldg.*;

import java.io.StringWriter;
import java.util.ArrayList;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;


/**
 * 건축물 간략정보
 */
public class GetBldgInfo {

	private BldgDongInfoService dongInfoSvc = new BldgDongInfoService();
	
	
	public String getData(String pnu) {

		StringBuilder sb = new StringBuilder();
		
		BldgDongInfoDataSet res = dongInfoSvc.getData(pnu);
		
		ArrayList<BldgDongInfo> bdiList = new ArrayList<BldgDongInfo>();
		bdiList.add(new BldgDongInfo());
		if ( res != null && res.getBody() != null ) bdiList = res.getBody().getBldgDongInfoList(); 

		BldgDongInfo bdi = bdiList.get(0);
		String bno = bdi.getBldgGbnNo().getVal();
		
		BldgInfoSet bis = new BldgInfoSet();
		
		if ( bdi.getBldgKindCd().getVal().equals("1") ) {
			// 총괄표제부
			BldgLedgGenHdsInfoService svc = new BldgLedgGenHdsInfoService();
			BldgLedgGenHdsInfoDataSet resp = svc.getData(pnu);
			BldgLedgGenHdsInfo ds = new BldgLedgGenHdsInfo();
			if ( resp != null && resp.getBody() != null ) ds = resp.getBody().getBldgLedgGenHdsInfo();
			setBldgLedgGenHdsInfo(bis, ds);

		} else if ( bdi.getBldgKindCd().getVal().equals("2") ) {
			// 일반건축물
			BldgHdsInfoService svc = new BldgHdsInfoService();
			BldgHdsInfoDataSet resp = svc.getData(pnu, bno);
			BldgHdsInfo ds = new BldgHdsInfo();
			if ( resp != null && resp.getBody() != null ) ds = resp.getBody().getBldgHdsInfoSet().getBldgHdsInfo();
			setBldgHdsInfo(bis, ds);
			
		} else if ( bdi.getBldgKindCd().getVal().equals("3") ) {
			// 집합건축물(표제부)
			CbldgHdsInfoService svc = new CbldgHdsInfoService();
			BldgHdsInfoDataSet resp = svc.getData(pnu, bno);
			BldgHdsInfo ds = new BldgHdsInfo();
			if ( resp != null && resp.getBody() != null ) ds = resp.getBody().getBldgHdsInfoSet().getBldgHdsInfo();
			setBldgHdsInfo(bis, ds);
			
		}		
		bis.setJibunAddr(Code.getJibunAddr(pnu));
		bis.setDoroAddr(Code.getDoroAddr(pnu));

		
        StringWriter sw = new StringWriter();
		try {

	        JAXBContext jc = JAXBContext.newInstance(BldgInfoSet.class);

	        Marshaller marshaller = jc.createMarshaller();
	        marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
	        marshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
	        marshaller.marshal(bis, sw);
	        
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}

		sb.append("<bldg-list>");
        sb.append(sw.toString());
		sb.append("</bldg-list>");	

		
		return sb.toString();
	
	}

	private void setBldgLedgGenHdsInfo(BldgInfoSet des, BldgLedgGenHdsInfo src) {
		des.setMainUseNm(src.getMainUseNm().getVal());
		des.setTotMainBldgCnt(ColUtils.formatNumber(src.getTotMainBldgCnt()));
		des.setLarea((ColUtils.formatNumber(src.getLarea()) + "㎡"));
		des.setBarea((ColUtils.formatNumber(src.getBarea()) + "㎡"));
		des.setGarea((ColUtils.formatNumber(src.getGarea()) + "㎡"));
		des.setBlr((ColUtils.formatNumber(src.getBlr()) + "%"));
		des.setFsi((ColUtils.formatNumber(src.getFsi()) + "%"));
	}
	
	private void setBldgHdsInfo(BldgInfoSet des, BldgHdsInfo src) {
		des.setMainUseNm(src.getMainUseNm().getVal());
		des.setTotMainBldgCnt("0");
		des.setLarea((ColUtils.formatNumber(src.getLarea()) + "㎡"));
		des.setBarea((ColUtils.formatNumber(src.getBarea()) + "㎡"));
		des.setGarea((ColUtils.formatNumber(src.getGarea()) + "㎡"));
		des.setBlr((ColUtils.formatNumber(src.getDongBlr()) + "%"));
		des.setFsi((ColUtils.formatNumber(src.getFsi()) + "%"));
	}

}
