package geomex.kras.gmx.svc;

import geomex.kras.common.*;
import geomex.kras.gmx.vo.DjyexposSet;
import geomex.kras.ivo.*;
import geomex.kras.vo.*;
import geomex.kras.bldg.*;

import java.io.StringWriter;
import java.util.ArrayList;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;


/**
 * 전유부의 정보
 */
public class GetDjyexpos {

	private CbldgDfhsInfoService cbldgDfhsInfoSvc = new CbldgDfhsInfoService();

	
	public String getData(String pnu, String bno) {

		StringBuilder sb = new StringBuilder();

		CbldgDfhsInfo cbdInfo = new CbldgDfhsInfo();

		ArrayList<CbldgDfhsInfo.MonoAll> maList = new ArrayList<CbldgDfhsInfo.MonoAll>();
		ArrayList<CbldgDfhsInfo.UserInfom> uiList = new ArrayList<CbldgDfhsInfo.UserInfom>();
		
		CbldgDfhsInfoDataSet res = cbldgDfhsInfoSvc.getData(pnu, bno);
		if ( res != null && res.getBody() != null ) cbdInfo = res.getBody().getCbldgDfhsInfoSet().getCbldgDfhsInfo();

		if ( cbdInfo.getMonoAll() != null ) maList = cbdInfo.getMonoAll();
		if ( cbdInfo.getUserInfom() != null ) uiList = cbdInfo.getUserInfom();
		
		
		DjyexposSet exp = new DjyexposSet();
		
		ArrayList<DjyexposSet.Djyflrouln> flrList;
		DjyexposSet.Djyflrouln flr;
		if ( maList.size() > 0 ) {
			flrList = new ArrayList<DjyexposSet.Djyflrouln>();

			CbldgDfhsInfo.MonoAll ma;
			for ( int i = 0; i < maList.size(); i++ ) {
				ma = maList.get(i);

				flr = new DjyexposSet.Djyflrouln();
				
				flr.setMainAtchGbCdNm(ma.getMainSubGbnNm().getVal());
				flr.setFlrNoNm(ma.getFlr().getVal());
				flr.setStrctCdNm(ma.getStruNm().getVal());
				flr.setMainPurpsCdNm(ma.getEtcUse().getVal());
				flr.setArea("");
				
				flrList.add(flr);
			}
			exp.setDjyflroulnList(flrList);
		}
		
		ArrayList<DjyexposSet.Djyownr> ownList;
		DjyexposSet.Djyownr own;
		if ( uiList.size() > 0 ) {
			ownList = new ArrayList<DjyexposSet.Djyownr>();
			
			CbldgDfhsInfo.UserInfom ui;
			for ( int i = 0; i < uiList.size(); i++ ) {
				ui = uiList.get(i);

				own = new DjyexposSet.Djyownr();

				own.setChangCausDay(ui.getChgYmd().getVal());
				own.setChangCausCdNm(ui.getChgRsnNm().getVal());
				own.setJibunDesc(ui.getJibunDesc().getVal());
				own.setNm(ui.getOwnerNm().getVal());
				own.setRegNo(ui.getDregno().getVal());
				own.setAddr(ui.getDetlAddr().getVal());
				
				ownList.add(own);
			}
			exp.setDjyownrList(ownList);
		}
		
		

/*		
		sb.append("<전유부>");
		
		if ( maList.size() > 0 ) {
			sb.append("<전유현황리스트>");
			CbldgDfhsInfo.MonoAll ma;
			for ( int i = 0; i < maList.size(); i++ ) {
				ma = maList.get(i);
				sb.append("<전유현황>");
					sb.append("<구분>").append(ma.getMainSubGbnNm()).append("</구분>");
					sb.append("<층별>").append(ma.getFlr()).append("</층별>");
					sb.append("<구조>").append(ma.getStruNm()).append("</구조>");
					sb.append("<용도>").append(ma.getEtcUse()).append("</용도>");
					sb.append("<면적>").append("").append("</면적>");
				sb.append("</전유현황>");
			}
			sb.append("</전유현황리스트>");
		}
		
		if ( uiList.size() > 0 ) {
			sb.append("<소유자현황리스트>");
			CbldgDfhsInfo.UserInfom ui;
			for ( int i = 0; i < uiList.size(); i++ ) {
				ui = uiList.get(i);
				sb.append("<소유자현황>");
					sb.append("<변동일자>").append(ui.getChgYmd()).append("</변동일자>");
					sb.append("<변동원인>").append(ui.getChgRsnNm()).append("</변동원인>");
					sb.append("<지분>").append(ui.getJibunDesc()).append("</지분>");
					sb.append("<성명및명칭>").append(ui.getOwnerNm()).append("</성명및명칭>");
					sb.append("<주민번호>").append(ui.getDregno()).append("</주민번호>");
					sb.append("<주소>").append(ui.getDetlAddr()).append("</주소>");
				sb.append("</소유자현황>");
			}
			sb.append("</소유자현황리스트>");
		}

		sb.append("</전유부>");
*/
		
        StringWriter sw = new StringWriter();
		try {

	        JAXBContext jc = JAXBContext.newInstance(DjyexposSet.class);

	        Marshaller marshaller = jc.createMarshaller();
	        marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
	        marshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
	        marshaller.marshal(exp, sw);
	        
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}

        sb.append(sw.toString());
		
		return sb.toString();
	
	}

}
