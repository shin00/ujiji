package geomex.kras.gmx.svc;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collections;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import geomex.kras.common.*;
import geomex.kras.gmx.vo.TojiDaejangSet;
import geomex.kras.ivo.*;
import geomex.kras.vo.*;
import geomex.kras.land.*;
import geomex.utils.Utils;


/**
 * 토지대장 프린트
 */
public class GetTojiDaejangPrint {

	private LandInfoService landInfoSvc = new LandInfoService();
	private LandMovHistService landMovHistSvc = new LandMovHistService();
	private OwnRgtHistService ownRgtHistSvc = new OwnRgtHistService();
	private LandJigaService landJigaSvc = new LandJigaService();
	private ShrYmbService shrYmbSvc = new ShrYmbService();

	
	public String getData(String pnu, String user) {

		StringBuilder sb = new StringBuilder();
		
		String[] punArr = PnuUtils.splitArr(pnu);
		
		LandInfoDataSet res1 = landInfoSvc.getData(pnu);
		LandInfo li = new LandInfo();
		if ( res1 != null && res1.getBody() != null ) li = res1.getBody().getLandInfo(); 

		
		LandMovHistDataSet res2 = landMovHistSvc.getData(pnu);
		ArrayList<LandMovHist> lmhList = new ArrayList<LandMovHist>(); 
		if ( res2 != null && res2.getBody() != null ) lmhList = res2.getBody().getLandMovHistList();
		

		OwnRgtHistDataSet res3 = ownRgtHistSvc.getData(pnu);
		ArrayList<OwnRgtHist> orhList = new ArrayList<OwnRgtHist>(); 
		if ( res3 != null && res3.getBody() != null ) orhList = res3.getBody().getOwnRgtHistList();
		
		
		LandJigaDataSet res4 = landJigaSvc.getData(pnu);
		ArrayList<LandJiga.JigaList> ljList = new ArrayList<LandJiga.JigaList>(); 
		if ( res4 != null && res4.getBody() != null ) ljList = res4.getBody().getLandJiga().getJigaList();

		
		ShrYmbDataSet res5 = shrYmbSvc.getData(pnu);
		ArrayList<ShrYmb> syList = new ArrayList<ShrYmb>();
		if ( res5 != null && res5.getBody() != null ) syList = res5.getBody().getShrYmbList(); 

		
		TojiDaejangSet tds = new TojiDaejangSet();
		
		//기본정보
		TojiDaejangSet.Base base = tds.getBase();
		base.setGouNum(PnuUtils.genLandSerial(pnu));
		base.setMapNoBono(li.getDoho().getVal());
		base.setIssNo(Utils.getStrSec());
		base.setTojiAddr(Code.getJibunAddr(pnu, true, false));
		base.setProcTime(Utils.formatTxtHMS(Utils.getStrSec()));
		base.setJibun(punArr[3]+"-"+punArr[4]);
		base.setScaleNm(li.getScaleNm().getVal());
		base.setNote("-");
		base.setUser(user);
		

		//토지표시_소유자

		////토지이동연혁
		ArrayList<TojiDaejangSet.LandMovOwnHist.LandMov> lmList = new ArrayList<TojiDaejangSet.LandMovOwnHist.LandMov>();
		TojiDaejangSet.LandMovOwnHist.LandMov lm;
		for ( int i = 0; i < lmhList.size(); i++ ) {
	 		
			String JIMOK_CODE = lmhList.get(i).getJimok().getVal();
			String JIMOK = lmhList.get(i).getJimokNm().getVal();
			String AREA_2 = (lmhList.get(i).getParea().getVal() + "㎡");
			String SAYOU_YEAR = lmhList.get(i).getDymd().getVal().trim();
			if ( SAYOU_YEAR.length() == 8 ) {
				SAYOU_YEAR = ("("+lmhList.get(i).getLandMovRsnCd().getVal()+") "+Utils.formatTxtYMD(SAYOU_YEAR));
			}else{
				SAYOU_YEAR = ("("+lmhList.get(i).getLandMovRsnCd().getVal()+") "+SAYOU_YEAR);
			}
			String LAND_MOVE_WHY = lmhList.get(i).getLandMovRsnCdNm().getVal();
			
			lm = new TojiDaejangSet.LandMovOwnHist.LandMov();
			
			lm.setJimokCode(JIMOK_CODE);
			lm.setJimok(JIMOK);
			lm.setArea(AREA_2);
			lm.setSayouYear(SAYOU_YEAR);
			lm.setLandMoveWhy(LAND_MOVE_WHY);
			
			lmList.add(lm);
		}
		Collections.reverse(lmList);
		tds.getLandMovOwnHist().setLandMovList(lmList);

		
	 	////소유권변동연혁
		ArrayList<TojiDaejangSet.LandMovOwnHist.Own> ownList = new ArrayList<TojiDaejangSet.LandMovOwnHist.Own>();
		TojiDaejangSet.LandMovOwnHist.Own own;
		for ( int i = 0; i < orhList.size(); i++ ) {
	 		
	 		String OWNR_ADDR = ""; //소유자 주소 없음
	 		if ( i == 0 ) OWNR_ADDR = li.getOwnerAddr().getVal();
			String OWNR_NM = orhList.get(i).getOwnerNm().getVal(); //소유자 명
			String OWNSP_CH_YMD = Utils.formatTxtYMD(orhList.get(i).getDymd().getVal()); //변동일자
			String OWNSP_CH_CAU_GBN_NM = ( "(" + orhList.get(i).getOwnRgtChgRsnCd().getVal() + ") " + orhList.get(i).getOwnRgtChgRsnCdNm().getVal()); //변동원인
			String OWNR_REG_SNO = orhList.get(i).getDregno().getVal(); //등록번호
			String OWN_GBN = orhList.get(i).getOwnGbn().getVal();
			String SHR_CNT = orhList.get(i).getShrCnt().getVal();
				    		
			own = new TojiDaejangSet.LandMovOwnHist.Own();
			
			own.setOwnspChYmd(OWNSP_CH_YMD);
			own.setOwnrAddr(OWNR_ADDR);
			own.setOwnspChCauGbnNm(OWNSP_CH_CAU_GBN_NM);
			own.setOwnrNm(OWNR_NM);
			own.setOwnrRegSno(OWNR_REG_SNO);
			own.setShrCnt(SHR_CNT);
			
	    	ownList.add(own);
		}
		Collections.reverse(ownList);
		tds.getLandMovOwnHist().setOwnList(ownList);
		
		
		//개별공시지가기준일
		ArrayList<TojiDaejangSet.JigaInfo> jgList = new ArrayList<TojiDaejangSet.JigaInfo>();
		TojiDaejangSet.JigaInfo jg;
		int maxSize = 5;
		if ( ljList.size() < 5 ) maxSize = ljList.size();
		for ( int i = 0; i < maxSize; i++ ) {
			jg = new TojiDaejangSet.JigaInfo();
			
			jg.setBaseYear(ljList.get(i).getBaseYear().getVal());
			jg.setJiga(ljList.get(i).getPannJiga().getVal());
			
    		jgList.add(jg);
		}
		Collections.reverse(jgList);
		tds.setJigaList(jgList);
		
		
		//공유지연명부
		ArrayList<TojiDaejangSet.ShareInfo> siList = new ArrayList<TojiDaejangSet.ShareInfo>();
		TojiDaejangSet.ShareInfo si;
		for ( int i = 0; i < syList.size(); i++ ) {
			 	
		 	String SHAP_SNO = syList.get(i).getShrSeqno().getVal(); //공유인 일련번호
			String OWNSP_CH_YMD = ColUtils.formatDate(syList.get(i).getOwnRgtChgYmd()); //변동일자
			String OWNSP_COSM = syList.get(i).getOwnRgtJibun().getVal(); //공유지분
			String OWNR_ADDR = syList.get(i).getOwnerAddr().getVal(); //주소
			String OWNR_REG_NO = syList.get(i).getOwnerRegno().getVal(); //소유자 등록번호
			String OWNSP_CH_CAU_GBN_TXT = ("("+syList.get(i).getOwnRgtChgRsnCd().getVal()+") "+syList.get(i).getOwnRgtChgRsnNm().getVal()); //소유권 변동사유합침
			String OWNR_NM = syList.get(i).getOwnerNm().getVal(); //소유자명
			String TRANS_YMD = ColUtils.formatDate(syList.get(i).getOwnRgtChgDelYmd());
			
			si = new TojiDaejangSet.ShareInfo();
			
			si.setShapSno(SHAP_SNO);
			si.setOwnspChYmd(OWNSP_CH_YMD);
			si.setOwnspCosm(OWNSP_COSM);
			si.setOwnrAddr(OWNR_ADDR);
			si.setOwnrRegNo(OWNR_REG_NO);
			si.setOwnspChCauGbnTxt(OWNSP_CH_CAU_GBN_TXT);
			si.setOwnrNm(OWNR_NM);
			si.setTransYmd(TRANS_YMD);
			
			siList.add(si);
		}
		tds.setShareInfoList(siList);
		

/*		
		sb.append("<토지대장>");

			sb.append("<기본정보>");
	    		sb.append("<고유번호>").append(PnuUtils.genLandSerial(pnu)).append("</고유번호>");
	    		sb.append("<도면번호>").append(li.getDoho()).append("</도면번호>");
	    		sb.append("<발급번호>").append(Utils.getStrSec()).append("</발급번호>");
	    		sb.append("<토지소재>").append(Code.getJibunAddr(pnu, true, false)).append("</토지소재>");
	    		sb.append("<처리시각>").append(Utils.formatTxtHMS(Utils.getStrSec())).append("</처리시각>");
	    		sb.append("<지번>").append(punArr[3]+"-"+punArr[4]).append("</지번>");
	    		sb.append("<축척>").append(li.getScaleNm()).append("</축척>");
	    		sb.append("<비고>").append("-").append("</비고>");
	    		sb.append("<작성자>").append(user).append("</작성자>");
			sb.append("</기본정보>");

			sb.append("<토지표시_소유자>");

			//토지이동연혁
			for ( int i = 0; i < lmhList.size(); i++ ) {
		 		
				String JIMOK_CODE = lmhList.get(i).getJimok().getVal();
				String JIMOK = lmhList.get(i).getJimokNm().getVal();
				String AREA_2 = (lmhList.get(i).getParea().getVal() + "㎡");
				String SAYOU_YEAR = lmhList.get(i).getDymd().getVal().trim();
				if ( SAYOU_YEAR.length() == 8 ) {
					SAYOU_YEAR = ("("+lmhList.get(i).getLandMovRsnCd().getVal()+") "+Utils.formatTxtYMD(SAYOU_YEAR));
				}else{
					SAYOU_YEAR = ("("+lmhList.get(i).getLandMovRsnCd().getVal()+") "+SAYOU_YEAR);
				}
				String LAND_MOVE_WHY = lmhList.get(i).getLandMovRsnCdNm().getVal();
					
				sb.append("<토지표시>");
					sb.append("<지목코드>").append(JIMOK_CODE).append("</지목코드>");
					sb.append("<지목>").append(JIMOK).append("</지목>");
					sb.append("<면적>").append(AREA_2).append("</면적>");
					sb.append("<사유년도>").append(SAYOU_YEAR).append("</사유년도>");
					sb.append("<사유>").append(LAND_MOVE_WHY).append("</사유>");
		    	sb.append("</토지표시>");	
			}
			
		 	//소유권변동연혁
			for ( int i = 0; i < orhList.size(); i++ ) {
		 		
		 		String OWNR_ADDR = ""; //소유자 주소 없음
				String OWNR_NM = orhList.get(i).getOwnerNm().getVal(); //소유자 명
				String OWNSP_CH_YMD = Utils.formatTxtYMD(orhList.get(i).getDymd().getVal()); //변동일자
				String OWNSP_CH_CAU_GBN_NM = ( "(" + orhList.get(i).getOwnRgtChgRsnCd().getVal() + ") " + orhList.get(i).getOwnRgtChgRsnCdNm().getVal()); //변동원인
				String OWNR_REG_SNO = orhList.get(i).getDregno().getVal(); //등록번호
				String OWN_GBN = orhList.get(i).getOwnGbn().getVal();
				String SHR_CNT = orhList.get(i).getShrCnt().getVal();
					    		 		
		    	sb.append("<소유자>");
		    		sb.append("<변동일자>").append(OWNSP_CH_YMD).append("</변동일자>");
		    		sb.append("<주소>").append(OWNR_ADDR).append("</주소>");
		    		sb.append("<변동원인>").append(OWNSP_CH_CAU_GBN_NM).append("</변동원인>");
		    		sb.append("<성명또는명칭>").append(OWNR_NM).append("</성명또는명칭>");
		    		sb.append("<등록번호>").append(OWNR_REG_SNO).append("</등록번호>");
		    		sb.append("<공유인수>").append(SHR_CNT).append("</공유인수>");
	    		sb.append("</소유자>");
			}

			sb.append("</토지표시_소유자>");

			sb.append("<개별공시지가기준일>");
			for ( int i = 0; i < ljList.size(); i++ ) {
	    		sb.append("<개별공시지가>");
		    		sb.append("<년도>").append(ljList.get(i).getBaseYear()).append("</년도>");
		    		sb.append("<공시지가>").append(ljList.get(i).getPannJiga()).append("</공시지가>");
	    		sb.append("</개별공시지가>");
			}
			sb.append("</개별공시지가기준일>");
			
			sb.append("<공유지연명부>");
			for ( int i = 0; i < syList.size(); i++ ) {
				 	
				 	String SHAP_SNO = syList.get(i).getShrSeqno().getVal(); //공유인 일련번호
					String OWNSP_CH_YMD = ColUtils.formatDate(syList.get(i).getOwnRgtChgYmd()); //변동일자
					String OWNSP_COSM = syList.get(i).getOwnRgtJibun().getVal(); //공유지분
					String OWNR_ADDR = syList.get(i).getOwnerAddr().getVal(); //주소
					String OWNR_REG_NO = syList.get(i).getOwnerRegno().getVal(); //소유자 등록번호
					String OWNSP_CH_CAU_GBN_TXT = ("("+syList.get(i).getOwnRgtChgRsnCd().getVal()+") "+syList.get(i).getOwnRgtChgRsnNm().getVal()); //소유권 변동사유합침
					String OWNR_NM = syList.get(i).getOwnerNm().getVal(); //소유자명
					String TRANS_YMD = ColUtils.formatDate(syList.get(i).getOwnRgtChgDelYmd());
					
	    		sb.append("<공유지>");
		    		sb.append("<순번>").append(SHAP_SNO).append("</순번>");
		    		sb.append("<변동일자>").append(OWNSP_CH_YMD).append("</변동일자>");
		    		sb.append("<소유권지분>").append(OWNSP_COSM).append("</소유권지분>");
		    		sb.append("<주소>").append(OWNR_ADDR).append("</주소>");
		    		sb.append("<등록번호>").append(OWNR_REG_NO).append("</등록번호>");
		    		sb.append("<변동원인>").append(OWNSP_CH_CAU_GBN_TXT).append("</변동원인>");
		    		sb.append("<성명또는명칭>").append(OWNR_NM).append("</성명또는명칭>");
		    		sb.append("<말소일자>").append(TRANS_YMD).append("</말소일자>");
	    		sb.append("</공유지>");
			}
			sb.append("</공유지연명부>");

		sb.append("</토지대장>");
*/

	 
        StringWriter sw = new StringWriter();
		try {

	        JAXBContext jc = JAXBContext.newInstance(TojiDaejangSet.class);

	        Marshaller marshaller = jc.createMarshaller();
	        marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
	        marshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
	        marshaller.marshal(tds, sw);
	        
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}

        sb.append(sw.toString());
	 
		return sb.toString();
	
	}

}
