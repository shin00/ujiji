package geomex.kras.gmx.svc;

import geomex.kras.common.*;
import geomex.kras.gmx.vo.BldgList;
import geomex.kras.ivo.*;
import geomex.kras.vo.*;
import geomex.kras.bldg.*;

import java.io.StringWriter;
import java.util.ArrayList;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;


/**
 * 건축물대장 리스트
 */
public class GetBldgList {

	private BldgDongInfoService bldgDongInfoSvc = new BldgDongInfoService();

	
	public String getData(String pnu) {

		StringBuilder sb = new StringBuilder();
		
		BldgDongInfoDataSet res = bldgDongInfoSvc.getData(pnu);
		
		ArrayList<BldgDongInfo> bdList = new ArrayList<BldgDongInfo>();
		bdList.add(new BldgDongInfo());
		if ( res != null && res.getBody() != null ) bdList = res.getBody().getBldgDongInfoList(); 

		String bldgGbn = bdList.get(0).getBldgKindCd().getVal();
		if ( bdList.get(0).getBldgKindCd().getVal().equals("1") ) bldgGbn = bdList.get(1).getBldgKindCd().getVal();
		
		BldgDongInfo bdInfo;

		
		BldgList bl = new BldgList();
		
		bl.setSerialNo(PnuUtils.genBldgSerial(pnu, bldgGbn));

		ArrayList<BldgList.BldgInfo> biList = new ArrayList<BldgList.BldgInfo>(); 
		BldgList.BldgInfo bi;
		for( int i = 0; i < bdList.size(); i++ ) {
			bdInfo = bdList.get(i);
			
			bi = new BldgList.BldgInfo();

			bi.setBldgGbn(new BldgList.BldgInfo.BldgGbn());

			bi.getBldgGbn().setKey(PnuUtils.splitArr(pnu)[0]+"-"+bdInfo.getBldgGbnNo());
			bi.getBldgGbn().setBno(bdInfo.getBldgGbnNo().getVal());
			bi.getBldgGbn().setCode(bdInfo.getBldgKindCd().getVal());
			//bi.getBldgGbn().setVal(bdInfo.getBldgKindNm().getVal());
			bi.getBldgGbn().setVal(Code.getBldgKindNm(bdInfo.getBldgKindCd().getVal()));
	    	if( bdInfo.getBldgKindCd().getVal().equals("3") ){
	    		bi.setExclPoss(new BldgList.BldgInfo.ExclPoss());
	    		
	    		bi.getExclPoss().setjKey(PnuUtils.splitArr(pnu)[0]+"-"+bdInfo.getBldgGbnNo());
	    		bi.getExclPoss().setBno(bdInfo.getBldgGbnNo().getVal());
	    	}
	    	bi.setDongNm(bdInfo.getDongNm().getVal());
	    	bi.setMainUse("");
	    	bi.setGarea(ColUtils.formatNumber(bdInfo.getGarea())+"㎡");
			
			biList.add(bi);
		}
		bl.setBldgInfoList(biList);
		
		
/*
		sb.append("<건축물대장>");

			sb.append("<고유번호>").append(PnuUtils.genBldgSerial(pnu, bldgGbn)).append("</고유번호>");
	
			for( int i = 0; i < bdList.size(); i++ ) {
				
				bdInfo = bdList.get(i);
				
		        sb.append("<건축물리스트>");
			    	sb.append("<대장종류 KEY=\"").append(PnuUtils.splitArr(pnu)[0]).append("-").append(bdInfo.getBldgGbnNo())
			    		.append("\" bno=\"").append(bdInfo.getBldgGbnNo()).append("\">").append(bdInfo.getBldgKindNm()).append("</대장종류>");
			    	if( bdInfo.getBldgKindCd().getVal().equals("3") ){
			    		sb.append("<전유부 J_KEY=\"").append(PnuUtils.splitArr(pnu)[0]).append("-").append(bdInfo.getBldgGbnNo())
			    			.append("\" bno=\"").append(bdInfo.getBldgGbnNo()).append("\">").append("전유부").append("</전유부>");
			    	}
			    	sb.append("<명칭및번호>").append(bdInfo.getDongNm()).append("</명칭및번호>");
			    	sb.append("<주용도>").append("").append("</주용도>");
			    	sb.append("<연면적>").append(ColUtils.formatNumber(bdInfo.getGarea())).append("㎡").append("</연면적>");
		    	sb.append("</건축물리스트>");
			}
    	
    	sb.append("</건축물대장>");
*/

		
        StringWriter sw = new StringWriter();
		try {

	        JAXBContext jc = JAXBContext.newInstance(BldgList.class);

	        Marshaller marshaller = jc.createMarshaller();
	        marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
	        marshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
	        marshaller.marshal(bl, sw);
	        
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}

        sb.append(sw.toString());
		
		return sb.toString();
	
	}

}
