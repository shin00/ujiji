package geomex.kras.gmx.svc;

import java.io.StringWriter;
import java.util.ArrayList;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import geomex.kras.common.*;
import geomex.kras.gmx.vo.ShareInfoList;
import geomex.kras.ivo.*;
import geomex.kras.vo.*;
import geomex.kras.land.*;


/**
 * 공유지연명부 목록
 */
public class GetShareInfo {

	private ShrYmbService shrYmbSvc = new ShrYmbService();

	
	public String getData(String pnu) {

		StringBuilder sb = new StringBuilder();
		
		ShrYmbDataSet res = shrYmbSvc.getData(pnu);
		
		ArrayList<ShrYmb> syList = new ArrayList<ShrYmb>();
		if ( res != null && res.getBody() != null ) syList = res.getBody().getShrYmbList(); 

		ShareInfoList sil = new ShareInfoList();
		
		ArrayList<ShareInfoList.ShareInfo> siList = new ArrayList<ShareInfoList.ShareInfo>();
		ShareInfoList.ShareInfo si;
		
		for( int i = 0; i < syList.size(); i++ ) {
			ShrYmb sy = syList.get(i);
			
			si = new ShareInfoList.ShareInfo();
			
			si.setShapSno(sy.getShrSeqno().getVal());
			si.setOwnspChCauGbn(sy.getOwnRgtChgRsnCd().getVal());
			si.setOwnspChCauGbnNm(sy.getOwnRgtChgRsnNm().getVal());
			si.setOwnspChYmd(sy.getOwnRgtChgYmd().getVal());
			si.setOwnrRegNo(sy.getOwnerRegno().getVal());
			si.setOwnrNm(sy.getOwnerNm().getVal());
			si.setOwnrAddr(sy.getOwnerAddr().getVal());
			si.setOwnspCosm(sy.getOwnRgtJibun().getVal());
			si.setTransYmd(sy.getOwnRgtChgDelYmd().getVal());
			si.setOwnGbn(sy.getOwnGbn().getVal());
			si.setOwnGbnNm(sy.getOwnGbnNm().getVal());

			siList.add(si);
		}
		sil.setShareInfoList(siList);
		
/*		
        sb.append("<공유지연명부목록>");
		for( int i = 0; i < syList.size(); i++ ) {
			ShrYmb sy = syList.get(i);
	        sb.append("<공유지연명부>");
		        sb.append("<공유인일련번호>").append(sy.getShrSeqno()).append("</공유인일련번호>");
		        sb.append("<소유권변동사유코드>").append(sy.getOwnRgtChgRsnCd()).append("</소유권변동사유코드>");
		        sb.append("<소유권변동사유>").append(sy.getOwnRgtChgRsnNm()).append("</소유권변동사유>");
		        sb.append("<소유권변동일자>").append(sy.getOwnRgtChgYmd()).append("</소유권변동일자>");
		        sb.append("<소유자등록번호>").append(sy.getOwnerRegno()).append("</소유자등록번호>");
		        sb.append("<소유자명>").append(sy.getOwnerNm()).append("</소유자명>");
		        sb.append("<소유자주소>").append(sy.getOwnerAddr()).append("</소유자주소>");
		        sb.append("<공유지분>").append(sy.getOwnRgtJibun()).append("</공유지분>");
		        sb.append("<말소일자>").append(sy.getOwnRgtChgDelYmd()).append("</말소일자>");
		        sb.append("<소유구분코드>").append(sy.getOwnGbn()).append("</소유구분코드>");
		        sb.append("<소유구분>").append(sy.getOwnGbnNm()).append("</소유구분>");
	        sb.append("</공유지연명부>");
		}
        sb.append("</공유지연명부목록>");
*/

        StringWriter sw = new StringWriter();
		try {

	        JAXBContext jc = JAXBContext.newInstance(ShareInfoList.class);

	        Marshaller marshaller = jc.createMarshaller();
	        marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
	        marshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
	        marshaller.marshal(sil, sw);
	        
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}

        sb.append(sw.toString());

		return sb.toString();
	
	}

}
