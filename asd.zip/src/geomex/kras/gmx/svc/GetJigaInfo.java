package geomex.kras.gmx.svc;

import java.util.ArrayList;

import geomex.kras.common.*;
import geomex.kras.ivo.*;
import geomex.kras.vo.*;
import geomex.kras.land.*;


/**
 * 공시지가 정보
 */
public class GetJigaInfo {

	private LandJigaService landJigaSvc = new LandJigaService();

	
	public String getData(String pnu) {

		StringBuilder sb = new StringBuilder();
		
		LandJigaDataSet res = landJigaSvc.getData(pnu);
		
		ArrayList<LandJiga.JigaList> jgList = new ArrayList<LandJiga.JigaList>();
		if ( res != null && res.getBody() != null ) jgList = res.getBody().getLandJiga().getJigaList(); 

		sb.append("<공시지가>");
		for( int i = 0; i < jgList.size(); i++ ) {
			LandJiga.JigaList jg = jgList.get(i);
			sb.append("<기준년월일>").append(jg.getBaseYear()).append("년 ").append(jg.getBaseMon()).append("월").append("</기준년월일>");
			sb.append("<개별공시지가>").append(ColUtils.formatNumber(jg.getPannJiga())).append("원").append("</개별공시지가>");
		}
		sb.append("</공시지가>");	

		
		return sb.toString();
	
	}

}
