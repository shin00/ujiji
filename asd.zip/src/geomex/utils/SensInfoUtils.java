package geomex.utils;

import org.apache.commons.lang3.StringUtils;


/**
 * <PRE>
 * 파일명   : SensInfoUtils.java
 * 파일설명 : 
 * 수정이력 : 
 *       2015. 6. 19.  이규하  : 최초작성
 * </PRE>
 *
 * @author 이규하
 *
 */
public class SensInfoUtils {

	public static String maskRegNo(String regNo) {
		String rst = "";
		String tmp = regNo.replace(" ", "").replace("-", "");
		int regNoLen = tmp.length();

		if ( regNoLen <  6 ) {
			rst = tmp;
		} else {
			rst = tmp.substring(0, 6);
		}
		if ( regNoLen >= 7 ) rst += ("-" + tmp.substring(6, 7));
		if ( regNoLen >= 8 ) rst += StringUtils.repeat("*", (regNoLen - 7));
		
		return rst;
	}

	public static String maskName(String name) {
		String rst = "";
		String tmp = name.replace(" ", "");
		int nameLen = tmp.length();
		int nonMaskLen = nameLen / 2;
		
		if ( nameLen > 1 ) rst = tmp.substring(0, nonMaskLen);
		if ( nameLen > 0 ) rst += StringUtils.repeat("*", (nameLen - nonMaskLen));
		
		return rst;
	}

}
