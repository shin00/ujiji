package geomex.utils;

import java.util.Map;

/**
 * <PRE>
 * 파일명   : MapUtils.java
 * 파일설명 : 
 * 수정이력 : 
 *       2015. 6. 15.  이규하  : 최초작성
 * </PRE>
 *
 * @author 이규하
 *
 */
public class MapUtils {

	public static String join(Map<String, String> map, String kvSep, String elSep) {
		StringBuilder rVal = new StringBuilder();
		int i = 0;
		for ( String key : map.keySet() ) {
			if ( i > 0 ) rVal.append(elSep);
			rVal.append(key).append(kvSep).append(map.get(key));
			i++;
		}
		return rVal.toString();
	}

}
