package geomex.load;

import geomex.utils.FileLogger;
import geomex.utils.IOUtil;
import geomex.utils.LogManager;
import geomex.utils.Logger;
import geomex.utils.XMLUtil;
import geomex.utils.db.DBPoolManager;
import geomex.utils.db.DBPoolProp;

import java.io.FileInputStream;
import java.io.InputStream;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;


public class DBPool extends HttpServlet {

	private static final long serialVersionUID = -18045061738369697L;
	private static final String DBPOOL_FILE = "/WEB-INF/dbpool.xml";


    public DBPool() {
        super();
    }

    @Override
    public void init(ServletConfig conf) throws ServletException {
        super.init(conf);
        ServletContext context = conf.getServletContext();

        try {
            initDBPool(context.getRealPath(DBPool.DBPOOL_FILE));
            context.log("System file.encoding : " + System.getProperty("file.encoding"));
            context.log("DB Pool Load!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * DBPoolManger설정정보를 읽고 DBPoolManager를 초기화 한다.
     * 
     * @param path dbpool.xml 경로
     * @throws Exception
     */
    private void initDBPool(String path) throws Exception {
        InputStream is = null;
        Element root = null;
        try {
            is = new FileInputStream(path);
            root = XMLUtil.parseDOM(is);
        } catch (Exception e) {
            throw e;
        } finally {
            IOUtil.close(is);
        }
        // Logger를 생성한다.
        Element logRoot = XMLUtil.getElementByName(root, "LoggerList");
        Element loggers[] = XMLUtil.getChildElements(logRoot, "Logger");
        for (Element log : loggers) {
            NamedNodeMap attr = log.getAttributes();
            String name = XMLUtil.getAttrValue(attr, "name");
            LogManager.getManager().addLogger(
                name,
                new FileLogger(XMLUtil.getString(attr, "path"),
                    XMLUtil.getString(attr, "prefix"),
                    Logger.getLevel(XMLUtil.getString(attr, "level")),
                    XMLUtil.getBoolean(attr, "console")));
        }
        // DBPoolManage를 생성한다.
        Element jdbc[] = XMLUtil.getChildElements(root, "JDBCPool");
        DBPoolProp props[] = new DBPoolProp[jdbc.length];
        for (int x = 0; x < jdbc.length; x++) {
            props[x] = new DBPoolProp();
            props[x].setName(XMLUtil.getString(jdbc[x], "NodeName"));
            props[x].setDriver(XMLUtil.getString(jdbc[x], "Driver"));
            props[x].setUrl(XMLUtil.getString(jdbc[x], "Url"));
            props[x].setProperty("user", XMLUtil.getString(jdbc[x], "User"));
            props[x].setProperty("password", XMLUtil.getString(jdbc[x], "Passwd"));
            props[x].setProperty("encoding", XMLUtil.getString(jdbc[x], "Encoding"));
            props[x].setCheckQuery(XMLUtil.getString(jdbc[x], "CheckQuery"));
            props[x].setMinCapacity(XMLUtil.getInt(jdbc[x], "MinCapacity"));
            props[x].setMaxCapacity(XMLUtil.getInt(jdbc[x], "MaxCapacity"));
            props[x].setWaitTimeout(XMLUtil.getInt(jdbc[x], "WaitTimeout"));
            props[x].setCheckTimeout(XMLUtil.getInt(jdbc[x], "CheckTimeout"));
            props[x].setLoggerName(XMLUtil.getString(jdbc[x], "LoggerName"));
            //System.out.println(props[x].toString());
        }
        DBPoolManager.create(props);
    }

    @Override
    public void destroy() {
        try {
            LogManager logger = LogManager.getManager();
            if (logger != null) logger.destroy();
        } catch (Exception e) {}
        try {
            DBPoolManager dbpool = DBPoolManager.getManager();
            if (dbpool != null) dbpool.destroy();
        } catch (Exception e) {}
        super.destroy();
    }

}
